import bpy
import math
import blf
import gpu
from gpu_extras.batch import batch_for_shader


def get_correct_shader_name(name):
    if bpy.app.version<(4,0,0):
        return name
    else:
        return name[name.find('_')+1:]
def draw_Text(context, font_id, font_size, text, alignH='CENTER', alignV='BOTTOM',padding=10,activeKey=None,start_x=None,start_y=None, translate=True):
    text=reversed(text)
    lcolor=0.24, 0.8, 1, 1
    rcolor=1, 1, 1, 1
    scolor=0, 1, 0.5, 1
    hcolor=1, 1, 1, 1
    border_radius=5
    blf.size(font_id, font_size)
    initY = 50
    n_panel=0
    use_floating_text=False
    if not use_floating_text:
        start_x = None
        start_y = None
    
    text=[a for a in text if a]
    n_panel_alignment=None
    for region in bpy.context.area.regions: 
        if region.type == "UI":
            n_panel_alignment=region.alignment
            n_panel = region.width+50#min(region.width,300)
            break
    #n_panel=150 if bpy.context.space_data.show_region_ui else 0

    if alignV != 'BOTTOM':
        initY = context.region.height - (blf.dimensions(font_id, text[0])[1]*(len(text)))-100

    center = 0
    max_dim_x=0
    startX=200000
    dim_y=0
    init_y=initY
    ycopy=initY
    if isinstance(text, str):
        text = {text,}
    actions=[]
    keys=[]
    YWidths=[]
    for t in text:
        YWidths.append(blf.dimensions(font_id, t)[1]+5)
        if ':' in t:
            key,action=t.split(':')
            
            key=key.replace(" ","")
            key=f"[{key}] :"
            
        else:
            action=""
            key=t
        keys.append(key)
        actions.append(action)
    maxYWidth=sum(YWidths)
    maxWidthKey=max(keys, key=len)
    maxWidthAction=max(actions, key=len)
    maxKeyWidth=blf.dimensions(font_id, maxWidthKey)[0]
    # if start_y and preferences().floating_text_location=='ABOVE':
    #     start_y=start_y+maxYWidth+100
    #     start_x=start_x-maxKeyWidth/2
    if alignH == 'LEFT':
            center = 50+(n_panel if n_panel_alignment=='LEFT' else 0)
    elif alignH == 'RIGHT':
        center = min([context.region.width-blf.dimensions(font_id, f"{maxWidthAction}{maxWidthKey}")[0]-30-(n_panel if n_panel_alignment=='RIGHT' else 0) for t in text])
    else :
            #pass
            #center=center/2
            center = min([(context.region.width-blf.dimensions(font_id, f"{maxWidthAction}{maxWidthKey}")[0])/2  for t in text])
    if start_y:
            initY=start_y-maxYWidth-50
            init_y=start_y-maxYWidth-50
    for t in text:
        if ':' in t:
            key,action=t.split(':')
            key=key.rstrip()
            if key and (len(key)<3 or 'SHIFT' in key or 'CTRL' in key or 'ALT' in key or 'TAB' in key or 'X/Y/Z' in key or 'SPACE' in key or 'UP' in key or 'DOWN' in key):
                key=f"[{key}]"
            
        else:
            action=""
            key=t
        if blf.dimensions(font_id, t)[0]>max_dim_x:
                max_dim_x=blf.dimensions(font_id, f"{maxWidthKey} {maxWidthAction}")[0]
        if center< startX:
            startX=center
        if start_x:
            center=start_x
            startX=start_x  
        
        initY += max(YWidths)
    if bpy.context.preferences.view.language in {'zh_CN','ja_JP'}:
        max_dim_x*=1.3
    gpu.state.blend_set("ALPHA") 
    #bgl.glEnable(bgl.GL_LINE_SMOOTH)
    
    dim_y=initY-5
    vertices = (
            (startX-padding, init_y-padding), (startX+max_dim_x+padding, init_y-padding),
            (startX-padding, dim_y+(padding*0.9)), (startX+max_dim_x+padding, dim_y+(0.9*padding)))
    roundedRectangle(startX-padding,init_y-padding,max_dim_x+2*padding,dim_y-init_y+2*padding,border_radius)
    gpu.state.blend_set("NONE") 
    #bgl.glDisable(bgl.GL_LINE_SMOOTH)
    initY=ycopy
    if start_y:
            initY=start_y-maxYWidth-50
    for t in text:
        if ':' in t:
            key,action=t.split(':')
            key=key.rstrip()
            if key and (len(key)<3 or 'SHIFT' in key or 'CTRL' in key or 'ALT' in key or 'TAB' in key or 'X/Y/Z' in key or 'SPACE' in key or 'A/S/D' in key  or 'UP' in key or 'DOWN' in key):
                key=f"[{key}]"
            
        else:
            action=""
            key=t
        if center< startX:
            startX=center
        if start_x:
            center=start_x
            startX=start_x  
        blf.position(font_id, center, initY, 0)
        blf.color(font_id,  lcolor[0], lcolor[1],lcolor[2], lcolor[3])
        if activeKey and (("[" in key and f"[{activeKey.replace(' ','')}]" in key.replace(" ",""))):
            blf.color(font_id, hcolor[0],hcolor[1], hcolor[2],hcolor[3])
        if key!='line':
            blf.draw(font_id, key)
        if key and action :
            blf.position(font_id, center +maxKeyWidth, initY, 0)
            blf.color(font_id,  lcolor[0], lcolor[1],lcolor[2], lcolor[3])
            blf.draw(font_id,":")
        blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id, ":")[0], initY, 0)
        if "(" in action:
            action1=action[:action.index("(")]
            blf.color(font_id, rcolor[0], rcolor[1],rcolor[2], rcolor[3])
            blf.draw(font_id, action1)
            action2=action[action.index("("):action.index(")")+1]
            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id, ":")[0]+blf.dimensions(font_id, action1)[0], initY, 0)
            blf.color(font_id, scolor[0], scolor[1],scolor[2], scolor[3])
            blf.draw(font_id,action2)
            action3=action[action.index(")")+1:]
            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id, ":")[0]+blf.dimensions(font_id, action1)[0]+blf.dimensions(font_id, action2)[0], initY, 0)
            blf.color(font_id,rcolor[0], rcolor[1],rcolor[2], rcolor[3])
            blf.draw(font_id,action3)
        elif "[" in action:
            action1=action[:action.index("[")]
            blf.color(font_id, rcolor[0], rcolor[1],rcolor[2], rcolor[3])
            blf.draw(font_id, action1)
            action2=action[action.index("[")+1:action.index("]")]
            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id, ":")[0]+blf.dimensions(font_id, action1)[0], initY, 0)
            blf.color(font_id, scolor[0], scolor[1],scolor[2], scolor[3])
            blf.draw(font_id,action2)
            action3=action[action.index("]")+1:]
            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id, ":")[0]+blf.dimensions(font_id, action1)[0]+blf.dimensions(font_id, action2)[0], initY, 0)
            blf.color(font_id, rcolor[0], rcolor[1],rcolor[2], rcolor[3])
            blf.draw(font_id,action3)

        else:
            blf.color(font_id, rcolor[0], rcolor[1],rcolor[2], rcolor[3])
            blf.draw(font_id, action)
        initY += max(YWidths)
def roundedRectangle(x, y, width, height,radius,smooth=5,color_fill=(0, 0, 0, 0.8),color_border=(0.2, 0.2, 0.2, 0.9)):
    gpu.state.blend_set("ALPHA") 
    #bgl.glEnable(bgl.GL_LINE_SMOOTH)
    border_thickness=2
    gpu.state.line_width_set(border_thickness)
    radius=min([radius,width/2, height/2])
    corners=[(x,y),(x+width,y),(x+width,y+height),(x,y+height)]
    tl_Corner=[]
    for i in range(90,180,smooth):
        
        tl_Corner.append((x+radius + radius*math.cos(math.radians(i)),y+height-radius + radius*math.sin(math.radians(i))))
    tr_Corner=[]
    for i in range(0,90,smooth):
        tr_Corner.append((x+width-radius + radius*math.cos(math.radians(i)),y+height-radius + radius*math.sin(math.radians(i))))
    bl_Corner=[]
    for i in range(180,270,smooth):
        bl_Corner.append((x+radius + radius*math.cos(math.radians(i)),y+radius + radius*math.sin(math.radians(i))))
    br_Corner=[]
    for i in range(270,360,smooth):
        br_Corner.append((x+width-radius + radius*math.cos(math.radians(i)),y+radius + radius*math.sin(math.radians(i))))
    #points=[(x+radius,y+radius),]+bl_Corner+[(x+width-radius,y+radius),]+br_Corner+[(x+width-radius,y+height-radius),]+tr_Corner+[(x+radius,y+height-radius)]+tl_Corner
    points=bl_Corner+br_Corner+tr_Corner+tl_Corner
    shader = gpu.shader.from_builtin(get_correct_shader_name('2D_UNIFORM_COLOR'))
    batch = batch_for_shader(shader, 'TRIS', {"pos": points}, indices=[(0,x+1,x+2) for x in range(len(points)-2)])
    edge_batch=batch_for_shader(shader, 'LINES', {"pos": points}, indices=[(x,(x+1)%len(points)) for x in range(len(points))])
    #print(len(points))
    #print([(x,(x+1)%len(points)) for x in range(len(points))])
    shader.bind()
    shader.uniform_float("color", color_fill)
    batch.draw(shader)
    shader.uniform_float("color", color_border)
    edge_batch.draw(shader)
    gpu.state.blend_set("NONE") 
    #bgl.glDisable(bgl.GL_LINE_SMOOTH)
def draw_circles(context,points,size=20):
    for point in points:
        if point:
            roundedRectangle(point[0]-size/2,point[1]-size/2,size,size,size/2,color_fill=(0.0, 0.65, 0.8, 0.8),color_border=(0.0, 0.0, 0.0, 0.0))
def draw_dropdown_panel(layout: bpy.types.UILayout, data, prop):
    layout=layout.row(align=True)
    layout.alignment = "LEFT"
    layout.prop(
        data,
        prop,
        emboss=False,
        icon="DOWNARROW_HLT" if getattr(data, prop) else "RIGHTARROW",
    )
    return getattr(data, prop)