bl_info = {
    "name": "Align And Distribute",
    "author": "Amandeep",
    "description": "Aligning and Distributing utilities",
    "blender": (2, 90, 0),
    "version": (3, 0, 3),
    "location": "N-Panel > Item > Align and Distribute",
    "warning": "",
    "category": "Object",
}

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import bpy
import os
from mathutils import Vector,Matrix
import random
import math
import gpu
import bmesh
from gpu_extras.batch import batch_for_shader
from bpy_extras import view3d_utils
from .addon_update_checker import AddonUpdateChecker,draw_update_section_for_panel,draw_update_section_for_prefs
import textwrap
from .draw_utils import *
import rna_keymap_ui
from .utils import *
kmaps_object_mode = ["aad.swap","aad.call_popup","aad.distributealongaxis","aad.distributeonplane" ]
def draw_hotkeys(col,km_name):
    kc = bpy.context.window_manager.keyconfigs.user
    for kmi in kmaps_object_mode:
        km2=kc.keymaps[km_name]
        kmi2=[]
        for a,b in km2.keymap_items.items():
            if a==kmi:
                kmi2.append(b)
        if kmi2:
            for a in kmi2:
                col.context_pointer_set("keymap", km2)
                rna_keymap_ui.draw_kmi([], kc, km2, a, col, 0)
def raycast_till_target(context,depsgraph,obj,target,axis,grid=None,grid_normal=None):
    axis=-axis
    object_loc=None
    target_loc=None
    origin=obj.location_real
    hidden=[]
    
    # print("tag",target)
    target_already_found=False
    (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,axis)
    
    if object==target:
        target_loc=location
        target_already_found=True
        target.hide_set(True)
    while(object is not None and (object == obj or object in context.selected_objects or object!=target or target_already_found)):
        # print("Hit",object)
        if object==obj:
            object_loc=location
        origin=location+axis.normalized()*0.01
        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,axis)
        if object==target:
            target_loc=location
            break
    object_loc_first_raycast=object_loc
    if not target_loc :
        axis=-axis
        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,axis)
        if object==target:
            target_loc=location
            target.hide_set(True)
        while(object is not None and (object == obj or object in context.selected_objects or object!=target or target_already_found)):
            if object==obj:
                object_loc=location
            origin=Vector((location[0],location[1],location[2]))+axis.normalized()*0.01
            (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,axis)
            if object==target:
                target_loc=location
                break
    if not target_loc:
        object_loc=object_loc_first_raycast
    if target:
        target.hide_set(False)
    if grid:
        target_loc=raycast(origin, axis, grid, grid_normal)
    return object_loc,target_loc
def move_object_to_target(obj, obj_loc=None, target_loc=None):
    # Ensure the object has a valid world matrix
    if obj.parent:
        # Calculate the current world location from the object's matrix_world
        world_location = obj.matrix_world.translation
    else:
        # If no parent, obj.location is already the world location
        world_location = obj.location
    
    if obj_loc and target_loc:
        # Calculate the delta in world space
        delta = target_loc - obj_loc
        # Update the world location while preserving scale and rotation
        new_world_location = world_location + delta
        set_object_world_location(obj, new_world_location)
    elif target_loc:
        # Set the world location directly if there's only a target location
        set_object_world_location(obj, target_loc)

def set_object_world_location(obj, new_world_location):
    # Get the current matrix_world
    obj.matrix_world = Matrix.LocRotScale(new_world_location,obj.rotation_euler,obj.scale)
def preferences():
    return bpy.context.preferences.addons[__package__].preferences
def message_box(context,layout,msg,icon='NONE'):
    box=layout.box()
    icon_drawen=False
    lines = textwrap.wrap(msg,context.region.width/13 if context else 100, break_long_words=False)
    for l in lines:
        box.label(text=l,icon=icon if not icon_drawen else 'NONE')
        icon_drawen=True
def draw_align_ui(context,layout,mesh_type):
    
    aad_props=context.scene.aad_props
    
    layout.label(text="Align",icon='SNAP_GRID')
    # layout.row().prop(aad_props,'task',expand=True)
    
    # layout.row().prop(aad_props,"axis",expand=True)
    global icon_collection
    pcoll=icon_collection['icons']
    RtoR_Icon=pcoll['AlignRtoR'].icon_id
    LtoR_Icon=pcoll['AlignLtoR'].icon_id
    LtoL_Icon=pcoll['AlignLtoL'].icon_id
    RtoL_Icon=pcoll['AlignRtoL'].icon_id
    Center_Icon=pcoll['AlignCenter'].icon_id
    RtoRV_Icon=pcoll['AlignRtoRV'].icon_id
    LtoRV_Icon=pcoll['AlignLtoRV'].icon_id
    LtoLV_Icon=pcoll['AlignLtoLV'].icon_id
    RtoLV_Icon=pcoll['AlignRtoLV'].icon_id
    CenterV_Icon=pcoll['AlignCenterV'].icon_id
    simplified_ui=preferences().simplified_ui
    
    icon_dict={'R To L':RtoL_Icon,'L To L':LtoL_Icon,'Center':Center_Icon,'R To R':RtoR_Icon,'L To R':LtoR_Icon}
    icon_dictV={'R To L':LtoRV_Icon,'L To L':RtoRV_Icon,'Center':CenterV_Icon,'R To R':LtoLV_Icon,'L To R':RtoLV_Icon}
    dir_aliases={'R To L':'T To B','L To L':'B To B','Center':'Center','R To R':'T To T','L To R':'B To T'}
    show_text=context.region.width>800
    if simplified_ui:
        if mesh_type:
            layout.row().prop(aad_props,'method',expand=True)
        for a in ('X','Y','Z'):
            row=layout.row(align=True)
            row=row.split(factor=0.25)
            row.label(text=a)
            direction_options=("R To L","L To L","Center","R To R","L To R")
            if not mesh_type or aad_props.method=='Origin':
                direction_options=("Center",)
            for d in direction_options:
                icon=icon_dictV[d] if a=='Z' else icon_dict[d]
                text=d if a!='Z' else dir_aliases[d]
                if aad_props.method=='Origin':
                    text=""
                op=row.operator("aad.align",text=text if show_text else "",icon_value=icon)
                op.align=True
                setattr(op,'axis_'+a.lower(),True)
                # op.axis_x=True
                op.direction=d
    else:
        
        if mesh_type:
            layout.row().prop(aad_props,'method',expand=True)
            if aad_props.method=="Bounding Box":
                row=layout.row()
                row.alignment='CENTER'
                row.prop(aad_props,'direction',expand=True)
        row=layout.row(align=True)
        op=row.operator("aad.align",text="X")
        op.align=True
        op.axis_x=True
        op=row.operator("aad.align",text="Y")
        op.align=True
        op.axis_y=True
        op=row.operator("aad.align",text="Z")
        op.align=True
        op.axis_z=True
class AAD_PT_ALIGN_AND_DISTRIBUTE(bpy.types.Panel):
    bl_label = "Align And Distribute"
    bl_idname = "OBJECT_PT_ALIGN_AND_DISTRIBUTE"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Item"
    
    def draw(self, context):
        layout= self.layout
        draw_update_section_for_panel(layout,context)
        mesh_type=all([a.type=='MESH' for a in context.selected_objects])
        if len(context.selected_objects)<2:
            message_box(context,layout,"Select atleast 2 objects",icon='ERROR')
        if not mesh_type:
            message_box(context,layout,"Non-Mesh Objects selected. Some options will be disabled",icon='INFO')
        align_box=layout.box()
        draw_align_ui(context,align_box,mesh_type)
        aad_props=context.scene.aad_props
        #row.prop(aad_props,'axis_x',toggle=True)
        #row.prop(aad_props,'axis_y',toggle=True)
        #row.prop(aad_props,'axis_z',toggle=True)
        box=layout.box()
        box.label(text="Distribute",icon='IMGDISPLAY')
        box.row().prop(aad_props,'distribute_pattern',expand=True)
        if aad_props.distribute_pattern=="1D":
            if mesh_type:
                box.row().prop(aad_props,'dmethod',expand=True) 
        if aad_props.distribute_pattern=="1D":
            if mesh_type:
                if aad_props.dmethod=="Bounding Box":
                    box.row().prop(aad_props,'linear_method',expand=True)
            box.label(text="Distribution Axis")
            row=box.row(align=True)
            op=row.operator("aad.align",text="All")
            op.distribute=True
            op.daxis_a=True
            op=row.operator("aad.align",text="X")
            op.distribute=True
            op.daxis_x=True
            op=row.operator("aad.align",text="Y")
            op.distribute=True
            op.daxis_y=True
            op=row.operator("aad.align",text="Z")
            op.distribute=True
            op.daxis_z=True
            #row.prop(aad_props,'daxis_x',toggle=True)
            #row.prop(aad_props,'daxis_y',toggle=True)
            #row.prop(aad_props,'daxis_z',toggle=True)
        elif aad_props.distribute_pattern=="2D":
            
            #layout.row().prop(aad_props,'plane',expand=True)
            col=box.column()
            col.prop(aad_props,'grid_2d')
            #layout.prop(aad_props,'grid_y')
            row=box.row()
            row=row.split(factor=0.9,align=True)
            col=row.column()
            col.prop(aad_props,'size_2d')
            col=row.column()
            col.prop(aad_props,'flip_2d',toggle=True,icon='ARROW_LEFTRIGHT')
            #layout.prop(aad_props,'size_y')
            # layout.row().prop(aad_props,'h_dir',expand=True)
            # layout.row().prop(aad_props,'v_dir',expand=True)
            box.label(text="Distribution Plane")
            row=box.row(align=True)
            op=row.operator("aad.align",text="X")
            op.distribute=True
            op.plane="X"
            op=row.operator("aad.align",text="Y")
            op.distribute=True
            op.plane="Y"
            op=row.operator("aad.align",text="Z")
            op.distribute=True
            op.plane="Z"
        elif aad_props.distribute_pattern=="3D":
            col=box.column()
            col.prop(aad_props,'grid_3d')
            row=box.row()
            row=row.split(factor=0.9,align=True)
            col=row.column()
            col.prop(aad_props,'size_3d')
            col=row.column()
            col.prop(aad_props,'flip_3d',toggle=True,icon='ARROW_LEFTRIGHT')
            op=layout.operator("aad.align",text="Distribute")
            op.distribute=True
        row=box.row(align=True)
        row.scale_y=2
        row.operator("aad.distributealongaxis")
        row.operator("aad.distributeonplane")
        box.operator("aad.origintobottom")
        rearrange_box=layout.box()
        rearrange_box.label(text="Rearrange",icon='STICKY_UVS_DISABLE')
        rearrange_box.operator("aad.randomize")
        rearrange_box.operator("aad.swap")
        snap_box=layout.box()
        snap_box.label(text="Snap",icon='SNAP_NORMAL')
        global icon_collection
        pcoll=icon_collection['icons']
        snap_to_ground_icon=pcoll['SnapToGround'].icon_id
        snap_box.operator("aad.snapit",icon_value=snap_to_ground_icon)
        if context.active_object:
            row=snap_box.row(align=True)
            row=row.split(factor=0.3,align=True)
            row.label(text=context.active_object.name)
            row.prop(context.active_object.aad_objects_info,'isGround',expand=True)
        
        transforms_box=layout.box()
        if draw_dropdown_panel(transforms_box,aad_props,'show_bookmark_ui'):
            if context.active_object or context.selected_objects:
                transforms_box.operator("aad.save_transforms",icon='FILE_TICK',text='Save Transforms')
            if context.active_object:
                for i,a in enumerate(context.active_object.aad_objects_info.saved_transforms):
                    box=transforms_box.box()
                    row=box.row()
                    row=row.split(factor=0.5,align=True)
                    row.prop(a,'name')
                    op=row.operator("aad.save_transforms",text="Update",icon='EVENT_UP_ARROW')
                    op.update=True
                    op.index=i
                    row.operator("aad.remove_saved_transforms",text="",icon='PANEL_CLOSE').index=i
                    row=box.row(align=True)
                    location_text=f"({a['location'][0]:.2f},{a['location'][1]:.2f},{a['location'][2]:.2f})"
                    row=row.split(factor=0.8,align=True)
                    row.label(text=f"Location:{location_text}")
                    op=row.operator("aad.apply_transforms",text="",icon='CHECKMARK')
                    op.index=i
                    op.location=True
                    row=box.row(align=True)
                    rotation_text=f"({a['rotation'][0]:.2f},{a['rotation'][1]:.2f},{a['rotation'][2]:.2f})"
                    row=row.split(factor=0.8,align=True)
                    row.label(text=f"Rotation:{rotation_text}")
                    op=row.operator("aad.apply_transforms",text="",icon='CHECKMARK')
                    op.index=i
                    op.rotation=True
                    row=box.row(align=True)
                    row=row.split(factor=0.8,align=True)
                    scale_text=f"({a['scale'][0]:.2f},{a['scale'][1]:.2f},{a['scale'][2]:.2f})"
                    row.label(text=f"Scale:{scale_text}")
                    op=row.operator("aad.apply_transforms",text="",icon='CHECKMARK')
                    op.index=i
                    op.scale=True
                    op=box.operator("aad.apply_transforms",text="All",icon='CHECKMARK')
                    op.index=i
                    op.location=True
                    op.rotation=True
                    op.scale=True
class AAD_OT_Call_PopUp(bpy.types.Operator):
    bl_idname = "aad.call_popup"
    bl_label = "Align And Distribute"
    bl_description = "Call Popup Panels for quick Access"
    def draw(self,context):
        mesh_type=all([a.type=='MESH' for a in context.selected_objects])
        draw_align_ui(context,self.layout,mesh_type)
    def execute(self, context):
        return {'FINISHED'}
    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self)
class AAD_Temp(bpy.types.Operator):
    bl_idname = "aad.temp"
    bl_label = "Align And Distribute"
    bl_description = "Create Assets Panel"
    bl_options = {'REGISTER', 'UNDO'}
    def draw(self,context):
        layout= self.layout
        aad_props=context.scene.aad_props
        layout.label(text="Align And Distribute")
        #layout.row().prop(aad_props,'task',expand=True)
        
        #layout.row().prop(aad_props,"axis",expand=True)
        
        layout.row().prop(aad_props,'method',expand=True)    
        if aad_props.method=="Bounding Box":
            layout.row().prop(aad_props,'direction',expand=True)
        row=layout.row(align=True)
        op=row.operator("aad.align",text="X")
        op.align=True
        op.axis_x=True
        op=row.operator("aad.align",text="Y")
        op.align=True
        op.axis_y=True
        op=row.operator("aad.align",text="Z")
        op.align=True
        op.axis_z=True
        #row.prop(aad_props,'axis_x',toggle=True)
        #row.prop(aad_props,'axis_y',toggle=True)
        #row.prop(aad_props,'axis_z',toggle=True)
        layout.label(text="Distribute")
        layout.row().prop(aad_props,'distribute_pattern',expand=True)
        if aad_props.distribute_pattern=="1D":
                layout.row().prop(aad_props,'dmethod',expand=True) 
        
        if aad_props.distribute_pattern=="1D":
            if aad_props.dmethod=="Bounding Box":
                layout.row().prop(aad_props,'linear_method',expand=True)
            row=layout.row(align=True)
            op=row.operator("aad.align",text="X")
            op.distribute=True
            op.daxis_x=True
            op=row.operator("aad.align",text="Y")
            op.distribute=True
            op.daxis_y=True
            op=row.operator("aad.align",text="Z")
            op.distribute=True
            op.daxis_z=True
            #row.prop(aad_props,'daxis_x',toggle=True)
            #row.prop(aad_props,'daxis_y',toggle=True)
            #row.prop(aad_props,'daxis_z',toggle=True)
        elif aad_props.distribute_pattern=="2D":
            
            #layout.row().prop(aad_props,'plane',expand=True)
            layout.prop(aad_props,'grid_2d')
            #layout.prop(aad_props,'grid_y')
            layout.prop(aad_props,'size_2d')
            #layout.prop(aad_props,'size_y')
            layout.row().prop(aad_props,'h_dir',expand=True)
            layout.row().prop(aad_props,'v_dir',expand=True)
            row=layout.row(align=True)
            op=row.operator("aad.align",text="X")
            op.distribute=True
            op.plane="X"
            op=row.operator("aad.align",text="Y")
            op.distribute=True
            op.plane="Y"
            op=row.operator("aad.align",text="Z")
            op.distribute=True
            op.plane="Z"
        layout.label(text="Rearrange")
        layout.operator("aad.Randomize")
        layout.operator("aad.swap")
    def invoke(self, context,event):
        #bpy.ops.wm.call_panel(name='OBJECT_PT_Bake_Tools')
        #return {'FINISHED'}
        return context.window_manager.invoke_popup(self)
    def execute(self, context):

        #        bpy.ops.wm.call_panel(name="RT_PT_Append_Panel")
        return {'FINISHED'}
def calc_center(obj):
    corners=[(obj.matrix_world @Vector(corner)) for corner in obj.bound_box]
    total=Vector((0,0,0))
    for c in corners:
        total=total+c
    return total/8
def rightmost_obj(objs,axis):
    rightmost_obj=objs[0]
    for obj in objs:
        if obj.location[axis]>rightmost_obj.location[axis]:
            rightmost_obj=obj
    return rightmost_obj
def leftmost_obj2(objs,axis):
    leftmost_obj=objs[0]
    for obj in objs:
        if obj.location[axis]<leftmost_obj.location[axis]:
            leftmost_obj=obj
    return leftmost_obj
def corner_object(objs, axis):
    # Normalize the axis vector
    axis_length = math.sqrt(axis[0]**2 + axis[1]**2 + axis[2]**2)
    normalized_axis = (axis[0] / axis_length, axis[1] / axis_length, axis[2] / axis_length)
    
    # Initialize the leftmost object
    leftmost_obj = objs[0]
    min_dot_product = sum([leftmost_obj.location[i] * normalized_axis[i] for i in range(3)])
    
    # Iterate through all objects to find the leftmost one along the axis
    for obj in objs[1:]:
        dot_product = sum([obj.location[i] * normalized_axis[i] for i in range(3)])
        if dot_product < min_dot_product:
            leftmost_obj = obj
            min_dot_product = dot_product
    
    return leftmost_obj
def generate_points(point_a,point_b,count,gap=None):
    total_width=point_b-point_a
    if gap is None:
        gap=total_width/(count+1)

    points=[]
    for a in range(count):
        points.append(point_a+gap*(a+1))
    #print(points)
    return points
def generate_points(point_a, point_b, count, axis, gap=None):
    axis = axis.normalized()  # Normalize the axis vector
    total_width = (point_b - point_a).dot(axis)  # Calculate total width along the axis
    
    if gap is None:
        gap = total_width / (count + 1)
    
    points = []
    for i in range(count):
        # Calculate position along the axis
        position = point_a + axis * (gap * (i + 1))
        points.append(position)
    
    return points
def generate_points_for_grid(point_a,point_b,count):
    diff=point_b-point_a
    diff=diff/(count+1)
    points=[point_a]
    for a in range(count):
        points.append(point_a+diff*(a+1))
    #print(points)
    points.append(point_b)
    return points
def generate_points_bb2(left,right,objs,axis,context,gap=None):
    min_x=min([(left.matrix_world @Vector(corner.co))[axis] for corner in left.data.vertices])
    max_x=max(([(right.matrix_world @Vector(corner.co))[axis] for corner in right.data.vertices]))
    max_x_left=max([(left.matrix_world @Vector(corner.co))[axis] for corner in left.data.vertices])
    available_width=max_x-min_x
    combined_width=0
    for obj in [left,]+objs+[right,]:
        obj=obj.evaluated_get(context.evaluated_depsgraph_get())
       # print([(obj.matrix_world @Vector(corner.co)) for corner in obj.bound_box])
        min_obj=min([(obj.matrix_world @Vector(corner.co))[axis] for corner in obj.data.vertices])
        max_obj=max(([(obj.matrix_world @Vector(corner.co))[axis] for corner in obj.data.vertices]))
        #print(obj,max_obj,min_obj)
        combined_width+=max_obj-min_obj
    #print(combined_width,available_width)
    gap=(available_width-combined_width)/(len(objs)+1)
    generated_points=[]
    all_objs=[left,]+objs+[right,]
    last_pos=max_x_left
    print("last pos",last_pos)
    for i,obj in enumerate(objs):
        obj=obj.evaluated_get(context.evaluated_depsgraph_get())
        try:
            min_obj=min(([(obj.matrix_world @Vector(corner.co))[axis] for corner in obj.data.vertices]))
            max_obj=max(([(obj.matrix_world @Vector(corner.co))[axis] for corner in obj.data.vertices]))
            obj_width=max_obj-min_obj
            obj_center=(max_obj+min_obj)/2
            actual_center=obj.location[axis]
            diff_center=obj_center-actual_center
            #print(obj,obj_center,actual_center,diff_center)
            #next_min_obj=min(([(all_objs[i+1].matrix_world @Vector(corner))[axis] for corner in all_objs[i+1].bound_box]))
            #next_max_obj=max(([(all_objs[i+1].matrix_world @Vector(corner))[axis] for corner in all_objs[i+1].bound_box]))
            #next_width=next_max_obj-next_min_obj
            #print(obj_width,last_pos,gap,obj_width/2,diff_center)
            print(last_pos,gap,obj_width/2,diff_center,last_pos + gap + obj_width / 2 - diff_center)
            generated_points.append(last_pos+gap+obj_width/2-diff_center)
            #print(last_pos+gap+obj_width/2-diff_center)
            last_pos=last_pos+gap+obj_width
            #print(last_pos)
        except:
            pass
    return generated_points
def generate_points_bb(left, right, objs, axis, context, gap=None):
    def get_extremes(obj, axis):
        vertices = [obj.matrix_world @ Vector(corner.co) for corner in obj.data.vertices]
        return obj,min(v[axis] for v in vertices), max(v[axis] for v in vertices)

    def get_combined_width(objs):
        return sum(max_obj - min_obj for _,min_obj, max_obj in objs)
    
    _,left_min, left_max = get_extremes(left, axis)
    all_objs = [left] + objs + [right]
    obj_extremes = [get_extremes(obj.evaluated_get(context.evaluated_depsgraph_get()), axis) for obj in all_objs]
    
    combined_width = get_combined_width(obj_extremes)
    
    if gap is None:
        _,right_min, right_max = obj_extremes[-1]
        available_width = right_max - left_min
        gap = (available_width - combined_width) / (len(objs) + 1)
    else:
        pass
        # right = None  # Remove right object from objs list if gap is provided
        # all_objs = [left] + objs
    generated_points = []
    last_pos = left_max
    for obj,min_obj, max_obj in obj_extremes[1:]:
        obj_width = max_obj - min_obj
        obj_center = (max_obj + min_obj) / 2
        actual_center=obj.location[axis]
        diff_center = obj_center - actual_center
        generated_points.append(last_pos + gap + obj_width / 2 - diff_center)
        last_pos += gap + obj_width

    return generated_points
def generate_points_bb2(left, right, objs, axis, context, gap=None):
    def get_extremes(obj, axis_vector):
        vertices = [obj.matrix_world @ Vector(corner.co) for corner in obj.data.vertices]
        min_proj = min(v.dot(axis_vector) for v in vertices)
        max_proj = max(v.dot(axis_vector) for v in vertices)
        return obj, min_proj, max_proj

    def get_combined_width(obj_extremes):
        return sum(max_obj - min_obj for _, min_obj, max_obj in obj_extremes)

    # Normalize the axis vector
    axis_vector = axis.normalized()

    # Calculate extremes for all objects along the axis
    all_objs = [left] + objs + [right]
    obj_extremes = [get_extremes(obj.evaluated_get(context.evaluated_depsgraph_get()), axis_vector) for obj in all_objs]
    
    combined_width = get_combined_width(obj_extremes)

    # Calculate the gap if not provided
    if gap is None:
        _, left_min, _ = obj_extremes[0]
        _, _, right_max = obj_extremes[-1]
        available_width = right_max - left_min
        gap = (available_width - combined_width) / (len(objs) + 1)
    
    generated_points = []
    last_pos = obj_extremes[0][2]  # Start with the max projection of the left object

    # Generate points along the axis
    for obj, min_obj, max_obj in obj_extremes[1:]:
        obj_width = max_obj - min_obj
        obj_center = (max_obj + min_obj) / 2
        actual_center = obj.location.dot(axis_vector)
        diff_center = obj_center - actual_center
        generated_point = last_pos + gap + obj_width / 2 - diff_center
        generated_points.append(generated_point)
        last_pos += gap + obj_width

    return generated_points
def generate_points_bb(left, right, objs, axis, context, gap=None):
    def get_extremes2(obj, axis_vector):
        vertices = [obj.matrix_world @ Vector(corner.co) for corner in obj.data.vertices]
        min_proj = min(v.dot(axis_vector) for v in vertices)
        max_proj = max(v.dot(axis_vector) for v in vertices)
        return obj, min_proj, max_proj
    def get_extremes(obj, axis_vector):
        # Get the bounding box corners in world coordinates
        bbox_corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
        
        # Project the bounding box corners onto the axis vector
        min_proj = min(v.dot(axis_vector) for v in bbox_corners)
        max_proj = max(v.dot(axis_vector) for v in bbox_corners)
    
        return obj, min_proj, max_proj
    def get_combined_width(obj_extremes):
        return sum(max_obj - min_obj for _, min_obj, max_obj in obj_extremes)

    # Normalize the axis vector
    axis_vector = axis.normalized()

    # Calculate extremes for all objects along the axis
    all_objs = [left] + objs + [right]
    obj_extremes = [get_extremes(obj.evaluated_get(context.evaluated_depsgraph_get()), axis_vector) for obj in all_objs]
    
    combined_width = get_combined_width(obj_extremes)

    # Calculate the gap if not provided
    if gap is None:
        _, left_min, _ = obj_extremes[0]
        _, _, right_max = obj_extremes[-1]
        available_width = right_max - left_min
        gap = (available_width - combined_width) / (len(objs) + 1)
    
    generated_locations = []
    last_pos = obj_extremes[0][2]  # Start with the max projection of the left object

    # Generate location vectors along the axis
    for obj, min_obj, max_obj in obj_extremes[1:]:
        obj_width = max_obj - min_obj
        obj_center = (max_obj + min_obj) / 2
        actual_center = obj.matrix_world.translation.dot(axis_vector)
        diff_center = obj_center - actual_center
        # Calculate the new scalar position along the axis
        scalar_position = last_pos + gap + obj_width / 2 - diff_center
        # Convert the scalar position back to a full 3D vector
        new_location = axis_vector * scalar_position
        # new_location = left.location + axis_vector * (scalar_position - obj_extremes[0][2])#+ (obj.location - axis_vector * obj.location.dot(axis_vector))
        # print(new_location)
        generated_locations.append(new_location)
        last_pos += gap + obj_width

    return generated_locations

def distance_between_objects(obj1, obj2, axis='ALL'):
    """
    Calculate the distance between two objects along a specified axis.
    
    Parameters:
    obj1 (Object): The first object.
    obj2 (Object): The second object.
    axis (str): The axis along which to calculate the distance ('X', 'Y', 'Z', 'ALL').
                Defaults to 'ALL'.
    
    Returns:
    float: The distance between the two objects along the specified axis.
    """
    diff = obj1.location - obj2.location
    
    if axis == 'X':
        return abs(diff.x)
    elif axis == 'Y':
        return abs(diff.y)
    elif axis == 'Z':
        return abs(diff.z)
    else:  # axis == 'ALL'
        return diff.length

def find_furthest_objects(objects, axis='ALL'):
    """
    Find the two objects that are furthest apart along a specified axis.
    
    Parameters:
    objects (list): List of objects to evaluate.
    axis (str): The axis along which to calculate the distance ('X', 'Y', 'Z', 'ALL').
                Defaults to 'ALL'.
    
    Returns:
    tuple: The two objects that are furthest apart and the maximum distance.
    """
    furthest_pair = (None, None)
    max_distance = -1
    for i, obj1 in enumerate(objects):
        for obj2 in objects[i + 1:]:
            distance = distance_between_objects(obj1, obj2, axis)
            if distance > max_distance:
                max_distance = distance
                furthest_pair = (obj1, obj2)
    return furthest_pair, max_distance

def points_from_corners_2d(corners,size_x,size_y,flow):
    a,b,c,d=corners
    if flow==0:
        atob=generate_points_for_grid(a,b,size_x-2)
        ctod=generate_points_for_grid(c,d,size_x-2)
        #print("A",a,b,atob,"B",c,d,ctod)
        points=[]
        for i,point in enumerate(atob):
            points.extend(generate_points_for_grid(point,ctod[i],size_y-2))
    else:
        atob=generate_points_for_grid(a,c,size_x-2)
        ctod=generate_points_for_grid(b,d,size_x-2)
        #print("A",a,b,atob,"B",c,d,ctod)
        points=[]
        for i,point in enumerate(atob):
            points.extend(generate_points_for_grid(point,ctod[i],size_y-2))
    #print(points)
    return points
def generate_grid_points(grid_x,grid_y,size_x,size_y,active_location,plane,flow=0,base=0):
    if plane=="Z":
        # if direction=="LEFTDOWN":
        #     corners=[active_location,active_location-Vector((grid_x*size_x,0,base)),active_location-Vector((0,grid_y*size_y,base)),active_location-Vector((grid_x*size_x,grid_y*size_y,base))]
        # elif direction=="RIGHTDOWN":
        #     corners=[active_location,active_location+Vector((grid_x*size_x,0,base)),active_location-Vector((0,grid_y*size_y,base)),active_location-Vector((-grid_x*size_x,grid_y*size_y,base))]
        # elif direction=="LEFTUP":
        #     corners=[active_location,active_location-Vector((grid_x*size_x,0,base)),active_location+Vector((0,grid_y*size_y,base)),active_location-Vector((grid_x*size_x,-grid_y*size_y,base))]
        # elif direction=="RIGHTUP":
            corners=[active_location,active_location+Vector((grid_x*size_x,0,base)),active_location+Vector((0,grid_y*size_y,base)),active_location-Vector((-grid_x*size_x,-grid_y*size_y,base))]
    elif plane=="X":
        # if direction=="LEFTDOWN":
        #     corners=[active_location,active_location-Vector((base,0,grid_x*size_x)),active_location-Vector((base,grid_y*size_y,0)),active_location-Vector((base,grid_y*size_y,grid_x*size_x))]
        # elif direction=="RIGHTDOWN":
        #     corners=[active_location,active_location+Vector((base,0,grid_x*size_x)),active_location-Vector((base,grid_y*size_y,0)),active_location-Vector((base,grid_y*size_y,-grid_x*size_x))]
        # elif direction=="LEFTUP":
        #     corners=[active_location,active_location-Vector((base,0,grid_x*size_x)),active_location+Vector((base,grid_y*size_y,0)),active_location-Vector((base,-grid_y*size_y,grid_x*size_x))]
        # elif direction=="RIGHTUP":
            corners=[active_location,active_location+Vector((base,0,grid_x*size_x)),active_location+Vector((base,grid_y*size_y,0)),active_location-Vector((base,-grid_y*size_y,-grid_x*size_x))]
    elif plane=="Y":
        # if direction=="LEFTDOWN":
        #     corners=[active_location,active_location-Vector((grid_x*size_x,base,0)),active_location-Vector((0,base,grid_y*size_y)),active_location-Vector((grid_x*size_x,base,grid_y*size_y))]
        # elif direction=="RIGHTDOWN":
        #     corners=[active_location,active_location+Vector((grid_x*size_x,base,0)),active_location-Vector((0,base,grid_y*size_y)),active_location-Vector((-grid_x*size_x,base,grid_y*size_y))]
        # elif direction=="LEFTUP":
        #     corners=[active_location,active_location-Vector((grid_x*size_x,base,0)),active_location+Vector((0,base,grid_y*size_y)),active_location-Vector((grid_x*size_x,base,-grid_y*size_y))]
        # elif direction=="RIGHTUP":
            corners=[active_location,active_location+Vector((grid_x*size_x,base,0)),active_location+Vector((0,base,grid_y*size_y)),active_location-Vector((-grid_x*size_x,base,-grid_y*size_y))]
    #print(direction,corners)
    # print(corners)
    generated_points=points_from_corners_2d(corners,grid_x,grid_y,flow)
    return generated_points
def generate_grid_points_3d(grid_x,grid_y,grid_z,size_x,size_y,size_z,active,flow=0):
    points=[]
    for i in range(grid_z):
        new_points=generate_grid_points(grid_x,grid_y,size_x,size_y,active,'Z',flow,base=i*size_z)
        points.extend([Vector((p.x,p.y,i*size_z)) for p in new_points])

    return points
def find_middle(obj,axis,context):
    obj=obj.evaluated_get(context.evaluated_depsgraph_get())
    min_obj=min([(obj.matrix_world @Vector(corner.co))[axis] for corner in obj.data.vertices])
    max_obj=max([(obj.matrix_world @Vector(corner.co))[axis] for corner in obj.data.vertices])
    return (max_obj+min_obj)/2
def find_middle(obj, axis, context):
    obj = obj.evaluated_get(context.evaluated_depsgraph_get())
    
    # Normalize the axis vector to ensure accurate calculations
    axis_vector = axis.normalized()
    
    # Calculate the extreme values along the axis
    vertices = [obj.matrix_world @ Vector(corner.co) for corner in obj.data.vertices]
    min_proj = min(v.dot(axis_vector) for v in vertices)
    max_proj = max(v.dot(axis_vector) for v in vertices)
    
    # Calculate the midpoint scalar along the axis
    midpoint_scalar = (max_proj + min_proj) / 2
    
    # Calculate the midpoint vector by projecting the midpoint scalar onto the axis
    midpoint_vector = axis_vector * midpoint_scalar + (obj.matrix_world @ Vector((0, 0, 0))) - axis_vector * (obj.matrix_world @ Vector((0, 0, 0))).dot(axis_vector)
    
    return midpoint_vector
def get_direction_items(self,context):
    global icon_collection
    pcoll=icon_collection['icons']
    RtoR_Icon=pcoll['AlignRtoR'].icon_id
    LtoR_Icon=pcoll['AlignLtoR'].icon_id
    LtoL_Icon=pcoll['AlignLtoL'].icon_id
    RtoL_Icon=pcoll['AlignRtoL'].icon_id
    Center_Icon=pcoll['AlignCenter'].icon_id
    items=(("R To L","R To L","Align Right(+ve) edge of the selected objects to the Left(-ve) edge of the Active Object",RtoL_Icon,0),("L To L","L To L","Align Left(-ve) edge of the selected objects to the Left(-ve) edge of the Active Object",LtoL_Icon,1),("Center","Center","Align Centers of the selected objects to the Center of the Active Object",Center_Icon,2),("R To R","R To R","Align Right(+ve) edge of the selected objects to the Right(+ve) edge of the Active Object",RtoR_Icon,3),("L To R","L To R","Align Left(-ve) edge of the selected objects to the Right(+ve) edge of the Active Object",LtoR_Icon,4))
    # print()
    if '_OT_' in str(self.__class__):
        items=(("R To L","R To L","Align Right(+ve) edge of the selected objects to the Left(-ve) edge of the Active Object"),("L To L","L To L","Align Left(-ve) edge of the selected objects to the Left(-ve) edge of the Active Object"),("Center","Center","Align Centers of the selected objects to the Center of the Active Object"),("R To R","R To R","Align Right(+ve) edge of the selected objects to the Right(+ve) edge of the Active Object"),("L To R","L To R","Align Left(-ve) edge of the selected objects to the Right(+ve) edge of the Active Object"))
    # items=(("R To L","","Align Right(+ve) edge of the selected objects to the Left(-ve) edge of the Active Object",RtoL_Icon,0),("L To L","","Align Left(-ve) edge of the selected objects to the Left(-ve) edge of the Active Object",LtoL_Icon,1),("Center","","Align Centers of the selected objects to the Center of the Active Object",Center_Icon,2),("R To R","","Align Right(+ve) edge of the selected objects to the Right(+ve) edge of the Active Object",RtoR_Icon,3),("L To R","","Align Left(-ve) edge of the selected objects to the Right(+ve) edge of the Active Object",LtoR_Icon,4))
    return items
class AAD_OT_Align(bpy.types.Operator):
    bl_idname = "aad.align"
    bl_label = "Align"
    bl_description = "Align"
    bl_options = {"REGISTER","UNDO"}
    align:bpy.props.BoolProperty(name="Align",options={'SKIP_SAVE'})
    distribute:bpy.props.BoolProperty(name="Distribute",options={'SKIP_SAVE'})
    method:bpy.props.EnumProperty(items=(("Origin","Origin","Origin"),("Bounding Box","Bounding Box","Bounding Box")),default=1,name="Method")
    dmethod:bpy.props.EnumProperty(items=(("Origin","Origin","Origin"),("Bounding Box","Bounding Box","Bounding Box")),default=1,name="Method")
    #task:bpy.props.EnumProperty(items=(("Align","Align","Align"),("Distribute","Distribute","Distribute")))
    direction:bpy.props.EnumProperty(items=get_direction_items)
    axis:bpy.props.EnumProperty(items=(("0","X","X"),("1","Y","Y"),("2","Z","Z")))#,("-X","-X","-X"),("-Y","-Y","-Y"),("-Z","-Z","-Z")
    axis_x:bpy.props.BoolProperty(name="X",options={'SKIP_SAVE'})
    axis_y:bpy.props.BoolProperty(name="Y",options={'SKIP_SAVE'})
    axis_z:bpy.props.BoolProperty(name="Z",options={'SKIP_SAVE'})
    daxis_x:bpy.props.BoolProperty(name="X",options={'SKIP_SAVE'})
    daxis_y:bpy.props.BoolProperty(name="Y",options={'SKIP_SAVE'})
    daxis_z:bpy.props.BoolProperty(name="Z",options={'SKIP_SAVE'})
    daxis_a:bpy.props.BoolProperty(name="All",options={'SKIP_SAVE'})
    distribute_pattern:bpy.props.EnumProperty(items=(("1D","1D","1D"),("2D","2D","2D"),("3D","3D","3D")),options={'SKIP_SAVE'})#,("3D","3D","3D")
    daxis:bpy.props.EnumProperty(items=(("0","X","X"),("1","Y","Y"),("2","Z","Z")))
    plane:bpy.props.EnumProperty(items=(("X","X","X"),("Y","Y","Y"),("Z","Z","Z")),options={'SKIP_SAVE'})
    linear_method:bpy.props.EnumProperty(items=(("Equal Distance","Equal Distance","Equal Distance"),("Equal Gap","Equal Gap","Equal Gap")))
    grid_2d:bpy.props.IntVectorProperty(size=2,min=2,default=[2,2],name="Grid Size")
    grid_3d:bpy.props.IntVectorProperty(size=3,min=2,default=[2,2,2],name="Grid Size")
    #grid_y:bpy.props.IntProperty(default=3,min=2)
    #grid_z:bpy.props.IntProperty(default=3,min=2)
    size_2d:bpy.props.FloatVectorProperty(size=2,default=[1,1],name="Cell Size")
    size_3d:bpy.props.FloatVectorProperty(size=3,default=[1,1,1],name="Cell Size")
    flip_2d:bpy.props.BoolVectorProperty(default=(False,False),size=2,name="Flip")
    flip_3d:bpy.props.BoolVectorProperty(default=(False,False,False),size=3,name="Flip")
    #size_y:bpy.props.FloatProperty(default=1)
    #size_z:bpy.props.FloatProperty(default=1)
    h_dir:bpy.props.EnumProperty(items=(("RIGHT","RIGHT","RIGHT"),("LEFT","LEFT","LEFT")))
    v_dir:bpy.props.EnumProperty(items=(("DOWN","DOWN","DOWN"),("UP","UP","UP")))
    flow_switch:bpy.props.BoolProperty(default=False,name="Switch Flow",description="Switch between Row and Column flow")
    use_fixed_gap:bpy.props.BoolProperty(default=False,name="Use Fixed Gap",description="Use Fixed Gap")
    gap:bpy.props.FloatProperty(default=0.1,name="Gap")
    use_random_grid_assignment:bpy.props.BoolProperty(default=False,name="Random Grid Assignment",description="Random Grid Assignment")
    random_seed:bpy.props.IntProperty(default=0,name="Random Seed")
    corner_objects_given:bpy.props.BoolProperty(name="Corner Objects Given",default=False,options={'SKIP_SAVE'})
    given_obj1:bpy.props.StringProperty(name="Object 1",options={'SKIP_SAVE'})
    given_obj2:bpy.props.StringProperty(name="Object 2",options={'SKIP_SAVE'})
    use_same_objects_for_each_axis:bpy.props.BoolProperty(name="Use Same Corner Objects For Each Axis",default=False,options={'SKIP_SAVE'})
    @classmethod
    def poll(cls, context):
        if len(context.selected_objects)<2:
            cls.poll_message_set("Select at least 2 objects")
        return context.active_object and len(context.selected_objects)>=2
    def draw(self, context):
        layout= self.layout
        layout.prop(self,'align',toggle=True,icon="TRIA_DOWN")
        #layout.row().prop(self,'task',expand=True)
        
        #layout.row().prop(self,"axis",expand=True)
        
        if self.align:
            if not self.disable_non_mesh_options:
                layout.row().prop(self,'method',expand=True)    
            if self.method=="Bounding Box":
                layout.row().prop(self,'direction',expand=True)
            row=layout.row(align=True)

            row.prop(self,'axis_x',toggle=True)
            row.prop(self,'axis_y',toggle=True)
            row.prop(self,'axis_z',toggle=True)
        layout.prop(self,'distribute',toggle=True,icon="TRIA_DOWN")
        if self.distribute:
            layout.row().prop(self,'distribute_pattern',expand=True)
            if self.distribute_pattern=="1D":
                if not self.disable_non_mesh_options:
                    layout.row().prop(self,'dmethod',expand=True) 
            if self.distribute_pattern=="1D":

                if self.dmethod=="Bounding Box":
                    if not self.disable_non_mesh_options:
                        layout.row().prop(self,'linear_method',expand=True)
                layout.label(text="Distribution Axis")
                row=layout.row(align=True)
                row.prop(self,'daxis_a',toggle=True)
                if not self.daxis_a:
                    row.prop(self,'daxis_x',toggle=True)
                    row.prop(self,'daxis_y',toggle=True)
                    row.prop(self,'daxis_z',toggle=True)
                    if sum([self.daxis_x,self.daxis_y,self.daxis_z])>1:
                        layout.prop(self,'use_same_objects_for_each_axis',toggle=True)
                row=layout.row(align=True)
                row.prop(self,'use_fixed_gap',toggle=True)
                if self.use_fixed_gap:
                    row.prop(self,'gap')
            elif self.distribute_pattern=="2D":
                layout.label(text="Distribution Plane")
                layout.row().prop(self,'plane',expand=True)

                layout.prop(self,'grid_2d')
                #layout.prop(self,'grid_y')
                row=layout.row()
                row=row.split(factor=0.9,align=True)
                col=row.column()
                col.prop(self,'size_2d')
                col=row.column()
                col.prop(self,'flip_2d',toggle=True,icon='ARROW_LEFTRIGHT')
                # layout.prop(self,'size_2d')
                #layout.prop(self,'size_y')
                # layout.label(text='Distribution Plane')
                # layout.row().prop(self,'h_dir',expand=True)
                # layout.row().prop(self,'v_dir',expand=True)
                layout.prop(self,'flow_switch',toggle=True)
                layout.prop(self,'use_random_grid_assignment',toggle=True)
                if self.use_random_grid_assignment:
                    layout.prop(self,'random_seed')
            elif self.distribute_pattern=="3D":
                layout.prop(self,'grid_3d')
                #layout.prop(self,'grid_y')
                row=layout.row()
                row=row.split(factor=0.9,align=True)
                col=row.column()
                col.prop(self,'size_3d')
                col=row.column()
                col.prop(self,'flip_3d',toggle=True,icon='ARROW_LEFTRIGHT')
                layout.prop(self,'use_random_grid_assignment',toggle=True)
                if self.use_random_grid_assignment:
                    layout.prop(self,'random_seed')
                
    def execute(self,context):
        active=context.active_object
        #objs=[a for a in [a for a in context.selected_objects if a.type=='MESH'] if a !=active]
        objs=[a for a in context.selected_objects if a !=active]
        
        if self.align and (self.axis_x or self.axis_y or self.axis_z):
            if not self.disable_non_mesh_options:
                active_evaluated=active.evaluated_get(context.evaluated_depsgraph_get())
                min_x=min([(active.matrix_world @Vector(corner.co))[0] for corner in active_evaluated.data.vertices])
                min_y=min([(active.matrix_world @Vector(corner.co))[1] for corner in active_evaluated.data.vertices])
                min_z=min([(active.matrix_world @Vector(corner.co))[2] for corner in active_evaluated.data.vertices])
                max_x=max([(active.matrix_world @Vector(corner.co))[0] for corner in active_evaluated.data.vertices])
                max_y=max([(active.matrix_world @Vector(corner.co))[1] for corner in active_evaluated.data.vertices])
                max_z=max([(active.matrix_world @Vector(corner.co))[2] for corner in active_evaluated.data.vertices])
                active_center=Vector(((min_x+max_x)/2,(min_y+max_y)/2,(min_z+max_z)/2))
            distances=[]
            if self.method=="Origin":
                
                for obj in objs:
                    og_obj=obj
                    obj=obj.evaluated_get(context.evaluated_depsgraph_get())
                    if self.axis_x:
                        distances.append((og_obj,obj.location[0]+obj.delta_location[0]-active.location[0]-active.delta_location[0],"x"))
                    if self.axis_y:
                        distances.append((og_obj,obj.location[1]+obj.delta_location[1]-active.location[1]-active.delta_location[1],"y"))
                    if self.axis_z:
                        distances.append((og_obj,obj.location[2]+obj.delta_location[2]-active.location[2]-active.delta_location[2],"z"))
            elif self.direction=="Center":
                
                for obj in objs:
                    og_obj=obj
                    obj=obj.evaluated_get(context.evaluated_depsgraph_get())
                    if self.axis_x:
                        distances.append((og_obj,calc_center(obj)[0]-active_center[0],"x"))
                    if self.axis_y:
                        distances.append((og_obj,calc_center(obj)[1]-active_center[1],"y"))
                    if self.axis_z:
                        distances.append((og_obj,calc_center(obj)[2]-active_center[2],"z"))
            elif self.direction=="L To R":
                for obj in objs:
                    og_obj=obj
                    obj=obj.evaluated_get(context.evaluated_depsgraph_get())
                    if self.axis_x:
                        distances.append((og_obj,min([(obj.matrix_world @Vector(corner.co))[0] for corner in obj.data.vertices])-max_x,"x"))
                    if self.axis_y:
                        distances.append((og_obj,min([(obj.matrix_world @Vector(corner.co))[1] for corner in obj.data.vertices])-max_y,"y"))
                    if self.axis_z:
                        distances.append((og_obj,min([(obj.matrix_world @Vector(corner.co))[2] for corner in obj.data.vertices])-max_z,"z"))
            elif self.direction=="L To L":
                for obj in objs:
                    og_obj=obj
                    obj=obj.evaluated_get(context.evaluated_depsgraph_get())
                    if self.axis_x:
                        distances.append((og_obj,min([(obj.matrix_world @Vector(corner.co))[0] for corner in obj.data.vertices])-min_x,"x"))
                    if self.axis_y:
                        distances.append((og_obj,min([(obj.matrix_world @Vector(corner.co))[1] for corner in obj.data.vertices])-min_y,"y"))
                    if self.axis_z:
                        distances.append((og_obj,min([(obj.matrix_world @Vector(corner.co))[2] for corner in obj.data.vertices])-min_z,"z"))
            elif self.direction=="R To L":
                for obj in objs:
                    og_obj=obj
                    obj=obj.evaluated_get(context.evaluated_depsgraph_get())
                    if self.axis_x:
                        distances.append((og_obj,max([(obj.matrix_world @Vector(corner.co))[0] for corner in obj.data.vertices])-min_x,"x"))
                    if self.axis_y:
                        distances.append((og_obj,max([(obj.matrix_world @Vector(corner.co))[1] for corner in obj.data.vertices])-min_y,"y"))
                    if self.axis_z:
                        distances.append((og_obj,max([(obj.matrix_world @Vector(corner.co))[2] for corner in obj.data.vertices])-min_z,"z"))
            elif self.direction=="R To R":
                for obj in objs:
                    og_obj=obj
                    obj=obj.evaluated_get(context.evaluated_depsgraph_get())
                    if self.axis_x:
                        distances.append((og_obj,max([(obj.matrix_world @Vector(corner.co))[0] for corner in obj.data.vertices])-max_x,"x"))
                    if self.axis_y:
                        distances.append((og_obj,max([(obj.matrix_world @Vector(corner.co))[1] for corner in obj.data.vertices])-max_y,"y"))
                    if self.axis_z:
                        distances.append((og_obj,max([(obj.matrix_world @Vector(corner.co))[2] for corner in obj.data.vertices])-max_z,"z"))
            #print(distances)
            for obj,distance,axis in distances:
                #print(obj,distance,axis)
                distance_vector=Vector((distance if axis=="x" else 0,distance if axis=="y" else 0,distance if axis=="z" else 0))
                #print(distance_vector)
                obj.location-=distance_vector
        if self.distribute:
            self.corner_obj1,self.corner_obj2=bpy.data.objects.get(self.corner_obj1_name),bpy.data.objects.get(self.corner_obj2_name)
            #print(self.distribute_pattern,self.dmethod,self.daxis)
            if self.distribute_pattern=="1D":
                if self.dmethod == "Origin":
                    axes = [3,0, 1, 2]
                    self.fixed_object1=None
                    self.fixed_object2=None
                    self.middle_sorted=[]
                    for axis in axes:
                        if getattr(self, f'daxis_{"xyza"[axis]}'):
                            objs = context.selected_objects
                            axis_v=Vector((1 if axis==0 else 0,1 if axis==1 else 0,1 if axis==2 else 0))
                            if axis==3:
                                axis_v=self.corner_obj1.location-self.corner_obj2.location
                            if axis_v.length==0:
                                self.report({'WARNING'}, "No Space to distribute selected objects")
                                return {'FINISHED'}
                            self.left_obj = corner_object(objs, axis_v)
                            self.right_obj = corner_object(objs, (-axis_v[0],-axis_v[1],-axis_v[2]))
                            if axis==3:
                                self.left_obj=self.corner_obj1
                                self.right_obj=self.corner_obj2
                            if not self.fixed_object1:
                                self.fixed_object1=self.left_obj
                            if not self.fixed_object2:
                                self.fixed_object2=self.right_obj

                            if self.use_same_objects_for_each_axis:
                                if not self.fixed_object1==self.fixed_object2:
                                    self.left_obj=self.fixed_object1
                                    self.right_obj=self.fixed_object2
                            middle_objs = sorted([obj for obj in objs if obj not in [self.left_obj, self.right_obj]], key=lambda v: v.location.dot(axis_v))
                            if not self.middle_sorted:
                                self.middle_sorted=middle_objs
                            if self.use_same_objects_for_each_axis:
                                middle_objs=self.middle_sorted
                            objects_to_distribute = middle_objs + [self.right_obj] if self.use_fixed_gap else middle_objs
                            count = len(objects_to_distribute)
                            
                            locations_generated = generate_points(self.left_obj.location, self.right_obj.location, count, axis_v,self.gap if self.use_fixed_gap else None)

                            for i, obj in enumerate(objects_to_distribute):
                                if axis==3:
                                    obj.location = locations_generated[i]
                                else:
                                    obj.location[axis] = locations_generated[i][axis]
                            if axis==3:
                                break
                        
                elif self.dmethod=="Bounding Box":
                    axes = [3,0, 1, 2]
                    self.fixed_object1=None
                    self.fixed_object2=None
                    self.middle_sorted=[]
                    for axis in axes:
                        if getattr(self, f'daxis_{"xyza"[axis]}'):
                            objs = [obj for obj in context.selected_objects if obj.type == 'MESH']
                            
                            axis_v=Vector((1 if axis==0 else 0,1 if axis==1 else 0,1 if axis==2 else 0))
                            if axis == 3:
                                middle=(self.corner_obj1.location+self.corner_obj2.location)/2
                                axis_v = (self.corner_obj2.location - self.corner_obj1.location).normalized()
                                # print("axis_v",axis_v)
                                # axis_v = axis_v + self.corner_obj1.location
                                # print("after",axis_v)
                            if axis_v.length==0:
                                self.report({'WARNING'}, "No Space to distribute selected objects")
                                return {'FINISHED'}
                            self.left_obj = corner_object(objs, axis_v)
                            # print("First",left_obj)
                            self.right_obj = corner_object(objs, (-axis_v[0],-axis_v[1],-axis_v[2]))
                            if not self.fixed_object1:
                                self.fixed_object1=self.left_obj
                            if not self.fixed_object2:
                                self.fixed_object2=self.right_obj
                            if self.use_same_objects_for_each_axis:
                                self.left_obj=self.fixed_object1
                                self.right_obj=self.fixed_object2
                            # print("Last",right_obj)
                            if axis==3:
                                self.left_obj=self.corner_obj1
                                self.right_obj=self.corner_obj2
                                self.left_obj.location=self.left_obj.location-middle
                                self.right_obj.location=self.right_obj.location-middle
                            # print("LR",left_obj,right_obj,axis_v)
                            # print(objs)
                            middle_objs = sorted([obj for obj in objs if obj not in [self.left_obj, self.right_obj]], key=lambda v: v.location.dot(axis_v))
                            if not self.middle_sorted:
                                self.middle_sorted=middle_objs
                            middle_objs=self.middle_sorted
                            objects_to_distribute = middle_objs + [self.right_obj] if self.use_fixed_gap else middle_objs
                            count = len(objects_to_distribute)
                            if self.linear_method == "Equal Gap":
                                locations_generated = generate_points_bb(self.left_obj, self.right_obj, middle_objs,axis_v , context, self.gap if self.use_fixed_gap else None)
                                # print(locations_generated)
                                # axis_vector = axis.normalized()

                                # for i, obj in enumerate(objects_to_distribute):
                                #     # Calculate the new location by moving along the axis vector
                                #     current_location = obj.location
                                #     new_location = current_location + axis_vector * (locations_generated[i] - current_location.dot(axis_vector))
                                #     obj.location = new_location
                                # print(len(objects_to_distribute))
                                # print(left_obj.location,right_obj.location)
                                if axis==3:
                                    self.left_obj.location=self.left_obj.location+middle
                                    self.right_obj.location=self.right_obj.location+middle
                                for i, obj in enumerate(objects_to_distribute):
                                    if axis==3:
                                        obj.location = locations_generated[i]+middle
                                    else:
                                        obj.location[axis] = locations_generated[i][axis]
                            else:
                                if axis==3:
                                    self.left_obj.location=self.left_obj.location+middle
                                    self.right_obj.location=self.right_obj.location+middle
                                locations_generated = generate_points(self.left_obj.location, self.right_obj.location, count, axis_v,self.gap if self.use_fixed_gap else None)

                                for i, obj in enumerate(objects_to_distribute):
                                    middle = find_middle(obj, axis_v, context)
                                    if axis==3:
                                        obj.location = locations_generated[i]+ (obj.location-middle )
                                    else:
                                        obj.location[axis] = locations_generated[i][axis]+ (obj.location[axis]-middle[axis] )
                                    # print(obj,middle)
                                    # obj.location = locations_generated[i] + (obj.location-middle )
                            if axis==3:
                                break
            elif self.distribute_pattern=="2D":
                    objs=[a for a in context.selected_objects if a!=active]
                    objs=[active,]+objs
                    size_x=self.size_2d[0] if not self.flip_2d[0] else -self.size_2d[0]
                    size_y=self.size_2d[1] if not self.flip_2d[1] else -self.size_2d[1]
                    locations_generated=generate_grid_points(self.grid_2d[0],self.grid_2d[1],size_x,size_y,active.location,plane=self.plane,flow=1 if self.flow_switch else 0)
                    if self.use_random_grid_assignment:
                        random.seed(self.random_seed)
                        random.shuffle(locations_generated)
                    for i,obj in enumerate(objs):
                        if self.plane=="Z":
                            obj.location=(locations_generated[i%len(locations_generated)][0],locations_generated[i%len(locations_generated)][1],obj.location[2])
                        elif self.plane=="Y":
                            obj.location=(locations_generated[i%len(locations_generated)][0],obj.location[1],locations_generated[i%len(locations_generated)][2])
                        elif self.plane=="X":
                            obj.location=(obj.location[0],locations_generated[i%len(locations_generated)][1],locations_generated[i%len(locations_generated)][2])
            elif self.distribute_pattern=="3D":
                    objs=[a for a in context.selected_objects if a!=active]
                    objs=[active,]+objs
                    size_x=self.size_3d[0] if not self.flip_3d[0] else -self.size_3d[0]
                    size_y=self.size_3d[1] if not self.flip_3d[1] else -self.size_3d[1]
                    size_z=self.size_3d[2] if not self.flip_3d[2] else -self.size_3d[2] 
                    locations_generated=generate_grid_points_3d(self.grid_3d[0],self.grid_3d[1],self.grid_3d[2],size_x,size_y,size_z,active.location,flow=1 if self.flow_switch else 0)
                    if self.use_random_grid_assignment:
                        random.seed(self.random_seed)
                        random.shuffle(locations_generated)
                    for i,obj in enumerate(objs):
                        obj.location=locations_generated[i%len(locations_generated)]
        return {'FINISHED'}
    def invoke(self, context,event):
        aad_props=context.scene.aad_props
        self.method=aad_props.method
        self.dmethod=aad_props.dmethod
        self.distribute_pattern=aad_props.distribute_pattern
        self.linear_method=aad_props.linear_method
        self.v_dir=aad_props.v_dir
        self.h_dir=aad_props.h_dir
        if not preferences().simplified_ui:
            self.direction=aad_props.direction
        self.size_2d=aad_props.size_2d
        self.grid_2d=aad_props.grid_2d
        self.size_3d=aad_props.size_3d
        self.grid_3d=aad_props.grid_3d
        self.flip_2d=aad_props.flip_2d
        self.flip_3d=aad_props.flip_3d
        self.disable_non_mesh_options=False
        self.left_obj=None
        self.right_obj=None
        for a in context.selected_objects:
            if a.type!='MESH':
                self.disable_non_mesh_options=True
                self.method="Origin"
                self.dmethod="Origin"

        objs = [obj for obj in context.selected_objects]
        if self.corner_objects_given:
            self.corner_obj1_name,self.corner_obj2_name=self.given_obj1,self.given_obj2
            # self.corner_obj1,self.corner_obj2=bpy.data.objects[self.given_obj1],bpy.data.objects[self.given_obj2]
            # print("Given",self.corner_obj1_name,self.corner_obj2_name)
            
        else:
            axis='ALL'
            if self.daxis_a:
                axis='ALL'
            elif self.daxis_x:
                axis='X'
            elif self.daxis_y:
                axis='Y'
            elif self.daxis_z:
                axis='Z'
            if axis:
                self.corner_obj1,self.corner_obj2=find_furthest_objects(objs,axis)[0]
                self.corner_obj1_name,self.corner_obj2_name=self.corner_obj1.name,self.corner_obj2.name
                # print("Auto",self.corner_obj1,self.corner_obj2)
        return self.execute(context)
def get_objects_in_proximity(obj1,obj2, divisions, radius,smart_select=False):
    point1=obj1.location
    point2=obj2.location
    # Generate points along the line between point1 and point2
    points = [point1.lerp(point2, i / divisions) for i in range(divisions + 1)]
    
    # Set to hold unique objects within the given radius
    nearby_objects = set()
    
    for point in points:
        for obj in bpy.context.view_layer.objects:
            if obj.type == 'MESH':
                obj_location = obj.location
                distance = (obj_location - point).length
                if distance <= radius :
                    if max(obj.dimensions) <=max(obj1.dimensions)*3 or not smart_select:
                        nearby_objects.add(obj)
    
    return nearby_objects
def get_bottom_z(obj):
    # Get the object's bounding box and transform it to world coordinates
    bbox_corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    # Get the minimum Z value from the bounding box corners
    return min([corner.z for corner in bbox_corners])
POSSIBLE_AXIS_COMBO=[('Z', 'Y'),('Z', 'X'),('X', 'Y'),('X', 'Z'),('Y', 'X'),('Y', 'Z') ]

global_selected_object=[]
class AAD_OT_DistributeOnPlane(bpy.types.Operator):
    bl_idname = "aad.distributeonplane"
    bl_label = "Distribute on Plane"
    bl_options = {'REGISTER', 'UNDO'}
    first_click = None
    second_click = None
    snap_enabled = False
    method:bpy.props.EnumProperty(items=(("Origin","Origin","Origin"),("Bounding Box","Bounding Box","Bounding Box")),default=1,name="Method")
    dmethod:bpy.props.EnumProperty(items=(("Origin","Origin","Origin"),("Bounding Box","Bounding Box","Bounding Box")),default=1,name="Method")

    linear_method:bpy.props.EnumProperty(items=(("Equal Distance","Equal Distance","Equal Distance"),("Equal Gap","Equal Gap","Equal Gap")))
    
    axis_combo:bpy.props.IntProperty(default=0,options={'SKIP_SAVE'},max=5,min=0,name='AXIS(Try changing if orientation is not correct)')
    def draw(self, context):
        layout= self.layout
        layout.prop(self,'axis_combo')
        layout.row().prop(self,'linear_method',expand=True)
        return
        
    def execute(self,context):
        if self.dup_bm:
            self.dup_bm.free()
        active=context.active_object
        selected_objects=[]
        for i,a in enumerate(self.selected_objects):
            
            obj=bpy.data.objects.get(a)
            if i==0:
                obj.location=self.obj1_location
            elif i==len(self.selected_objects)-1:
                obj.location=self.obj2_location
            selected_objects.append(obj)
        #objs=[a for a in [a for a in context.selected_objects if a.type=='MESH'] if a !=active]
        objs=[a for a in selected_objects if a !=active]
        
        if self.distribute:
            self.corner_obj1,self.corner_obj2=bpy.data.objects.get(self.corner_obj1_name),bpy.data.objects.get(self.corner_obj2_name)
            #print(self.distribute_pattern,self.dmethod,self.daxis)
            if self.dmethod == "Origin":
                objs = objs
                axis_v=self.corner_obj1.location-self.corner_obj2.location
                if axis_v.length==0:
                    self.report({'WARNING'}, "No Space to distribute selected objects")
                    return {'FINISHED'}
                # self.left_obj = corner_object(objs, axis_v)
                # self.right_obj = corner_object(objs, (-axis_v[0],-axis_v[1],-axis_v[2]))
                self.left_obj=self.corner_obj1
                self.right_obj=self.corner_obj2
                # print(self.left_obj,self.right_obj)
                middle_objs = sorted([obj for obj in objs if obj not in [self.left_obj, self.right_obj]], key=lambda v: v.location.dot(axis_v))
                objects_to_distribute = middle_objs + [self.right_obj] if self.use_fixed_gap else middle_objs
                count = len(objects_to_distribute)
                
                locations_generated = generate_points(self.left_obj.location, self.right_obj.location, count, axis_v,self.gap if self.use_fixed_gap else None)

                for i, obj in enumerate(objects_to_distribute):
                    obj.location = locations_generated[i]
                    
            elif self.dmethod=="Bounding Box":
                self.fixed_object1=None
                self.fixed_object2=None
                self.middle_sorted=[]
                selected_objects=[]
                for a in self.selected_objects:
                    obj=bpy.data.objects.get(a)
                    primary_axis, secondary_axis = POSSIBLE_AXIS_COMBO[self.axis_combo]
                    rotation_matrix = self.first_normal.to_track_quat(primary_axis, secondary_axis).to_matrix().to_4x4()
                    location_matrix = Matrix.Translation(obj.location)
                    scale=obj.scale[:]
                    obj.matrix_world = location_matrix @ rotation_matrix
                    obj.scale=scale
                    selected_objects.append(obj)
                objs = [obj for obj in selected_objects if obj.type == 'MESH']
                middle=(self.corner_obj1.location_real+self.corner_obj2.location_real)/2
                axis_v = (self.corner_obj2.location_real - self.corner_obj1.location_real).normalized()
                if axis_v.length==0:
                    self.report({'WARNING'}, "No Space to distribute selected objects")
                    return {'FINISHED'}
                # self.left_obj = corner_object(objs, axis_v)
                # self.right_obj = corner_object(objs, (-axis_v[0],-axis_v[1],-axis_v[2]))
                self.left_obj=self.corner_obj1
                self.right_obj=self.corner_obj2
                move_object_to_target(self.left_obj,target_loc=self.left_obj.location_real-middle)
                move_object_to_target(self.right_obj,target_loc=self.right_obj.location_real-middle)
                # print("LR",left_obj,right_obj,axis_v)
                # print(objs)
                middle_objs = sorted([obj for obj in objs if obj not in [self.left_obj, self.right_obj]], key=lambda v: v.location_real.dot(axis_v))
                if not self.middle_sorted:
                    self.middle_sorted=middle_objs
                middle_objs=self.middle_sorted
                objects_to_distribute = middle_objs + [self.right_obj] if self.use_fixed_gap else middle_objs
                count = len(objects_to_distribute)
                if self.linear_method == "Equal Gap":
                    locations_generated = generate_points_bb(self.left_obj, self.right_obj, middle_objs,axis_v , context, self.gap if self.use_fixed_gap else None)

                    move_object_to_target(self.left_obj,target_loc=self.left_obj.location_real+middle)
                    move_object_to_target(self.right_obj,target_loc=self.right_obj.location_real+middle)
                    for i, obj in enumerate(objects_to_distribute):
                        move_object_to_target(obj,target_loc=locations_generated[i]+middle)
                else:
                    move_object_to_target(self.left_obj,target_loc=self.left_obj.location_real+middle)
                    move_object_to_target(self.right_obj,target_loc=self.right_obj.location_real+middle)
                    locations_generated = generate_points(self.left_obj.location_real, self.right_obj.location_real, count, axis_v,self.gap if self.use_fixed_gap else None)

                    for i, obj in enumerate(objects_to_distribute):
                        middle = find_middle(obj, axis_v, context)
                        move_object_to_target(obj,target_loc=locations_generated[i]+ (obj.location_real-middle ))
                        # print(obj,middle)
                        # obj.location = locations_generated[i] + (obj.location-middle )
                for obj in selected_objects:
                    # print(self.first_click_object)
                    
                    obj_loc,target_loc=raycast_till_target(context,bpy.context.evaluated_depsgraph_get(),obj,self.obj if self.obj else self.first_click_object,self.first_normal,self.plane_location if self.snap_to_grid else None,self.plane_normal)
                    move_object_to_target(obj, obj_loc, target_loc)
                    # bpy.ops.aad.snapit('INVOKE_DEFAULT',normal=self.first_normal)

               
        return {'FINISHED'}
    def generate_grid(self,hide=False):
        if self.grid_placed:
            bpy.context.scene.collection.objects.link(self.plane)
            #link_to_collection(self.plane,bpy.context.collection)
            plane_evaluated=self.plane.evaluated_get(bpy.context.evaluated_depsgraph_get())
            
            #self.normal=plane_evaluated.matrix_world@plane_evaluated.data.polygons[0].normal
            coords = [plane_evaluated.matrix_world@v.co for v in plane_evaluated.data.vertices]
            self.indices = [(e.vertices[0],e.vertices[1]) for e in plane_evaluated.data.edges] 
            # if not self.hide_cp_verts:
            #     self.yellow_coords,self.yellow_indices=self.find_yellow_coords()
            #     intersections=find_intersections(self.yellow_coords,self.yellow_indices)
            #     self.faceverts+=intersections
            
            middle_cross_coords=[]
            #print(plane_evaluated.location)
            if self.bigverts:
                try:
                    middle_cross_coords.extend(findrectanglecoords(self.bigverts[0],plane_evaluated.matrix_world@plane_evaluated.data.vertices[1].co,self.plane,center=False))
                    middle_cross_coords.extend(findrectanglecoords(self.bigverts[0],plane_evaluated.matrix_world@plane_evaluated.data.vertices[2].co,self.plane,center=False))
                except Exception:
                    pass
                
            indices_middle=[]
            for i in range(0,len(middle_cross_coords),4):
                indices_middle.extend([(i,i+1),(i,i+3)])
            self.coords=coords
            self.batch_points=batch_for_shader(self.shader, 'POINTS', {"pos": self.coords})
            self.batch_object_points=batch_for_shader(self.shader, 'POINTS', {"pos": self.faceverts})
            self.batch_big_points=batch_for_shader(self.shader, 'LINES', {"pos": middle_cross_coords},indices=indices_middle)
            bpy.context.scene.collection.objects.unlink(self.plane)
            if hide:
                self.batch_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_yellow_points=batch_for_shader(self.shader,'POINTS',{"pos":[]})
                self.batch_object_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_big_points=batch_for_shader(self.shader, 'LINES', {"pos": []},indices=[])
    def main(self, context):
        import time
        st=time.time()
        scene = context.scene
        region = context.region
        rv3d = context.region_data
        coord = self.X,self.Y
        context.space_data.region_3d.update()
        view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
        hidden_objs=[]
        while ( object and (not object.visible_get() or object.type!='MESH') ):
            
            hidden_objs.append((object,object.hide_get()))
            object.hide_set(True)
            (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
        for o,s in hidden_objs:
            o.hide_set(s)
        if object is None :
            return False
        if object is not None :
            self.bigverts=[]
            self.aligned_to_verts=[]
            self.faceverts=[]
            self.coords=[]
            self.edge_middles=[]
            self.obj=object
            if not self.plane:
                selected_objects = context.selected_objects
                bpy.ops.mesh.primitive_plane_add(size=2, enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
                self.plane=context.active_object
                for c in self.plane.users_collection:
                    c.objects.unlink(self.plane)
                bpy.context.scene.collection.objects.link(self.plane)
                self.subsurf=self.plane.modifiers.new(type='SUBSURF',name='subsurf')
                
                self.subsurf.subdivision_type='SIMPLE'
                for o in selected_objects:
                    o.select_set(True)
            else:
                bpy.context.scene.collection.objects.link(self.plane)
            self.subsurf.levels=self.subsurf_level
            depsgraph = bpy.context.evaluated_depsgraph_get()
            depsgraph.update()
            local_normal=normal
            bm=None
            dup_obj=duplicate_object(self.obj)
            mw=dup_obj.matrix_world.copy()
            dup_obj.parent=None
            dup_obj.matrix_world=mw
            
            obj_rotation=dup_obj.evaluated_get(context.evaluated_depsgraph_get()).rotation_euler.to_matrix()
            if self.obj.type=='MESH':
                object_evaluated=dup_obj.evaluated_get(context.evaluated_depsgraph_get())
                if not self.dup_bm or self.obj != self.last_obj:
                    bm= bmesh.new()
                    bm.from_mesh(object_evaluated.data)
                    bm.faces.ensure_lookup_table()
                    self.dup_bm=bm
                else:
                    bm=self.dup_bm
                if index is not None:
                    self.all_verts=[object_evaluated.matrix_world@a.co for a in bm.verts] if not self.obj==self.last_obj else self.all_verts
                    self.last_obj=self.obj
                    local_normal=bm.faces[index].normal
            self.normal=normal
            delete_object_with_data(dup_obj)
            z = Vector((0,0,1))

            if not (math.isclose(abs(local_normal.x), 0, abs_tol=0.003)and math.isclose(abs(local_normal.y), 0, abs_tol=0.003)):
                a1=Vector((0,-1)).angle_signed(Vector((local_normal.x,local_normal.y)))
                if local_normal!=Vector((0,0,0)):
                    rot = z.rotation_difference( local_normal ).to_euler()
                    self.plane.rotation_euler= rot
                    self.plane.rotation_euler = (self.plane.rotation_euler.to_matrix() @ Matrix.Rotation(-a1, 3, 'Z')).to_euler()
                    
            else:
                self.plane.rotation_euler=[0,0,0]
            self.plane.rotation_euler=(obj_rotation@self.plane.rotation_euler.to_matrix() ).to_euler()
            plane_evaluated=self.plane.evaluated_get(bpy.context.evaluated_depsgraph_get())
            
            
            
            
            faceverts=[]
            depsgraph.update()
            object_evaluated=self.obj.evaluated_get(depsgraph)
            #st=time.time()
            get_coplanar_faces=True
            if get_coplanar_faces and bm:
                cp_verts,cp_faces=coplanar_faces(bm,bm.faces[index])
            else:
                cp_verts,cp_faces=[],[]        
            self.bigverts=[]
            #print(cp_verts)
            center=None
            # print(time.time()-st)
            if len(cp_verts)>2:
                bm_for_center=bmesh.new()
                for  v in cp_verts:
                    bm_for_center.verts.new(object_evaluated.matrix_world@v.co+grid_offset*normal)
                bm_for_center.faces.new(bm_for_center.verts)
                bm_for_center.faces.ensure_lookup_table()
                
                mesh_data = bpy.data.meshes.new('Test')
                bm_for_center.to_mesh(mesh_data)
                mesh_obj = bpy.data.objects.new('Test', mesh_data)
                
                bm_for_center.clear()
                bpy.context.collection.objects.link(mesh_obj)
                # bpy.ops.object.select_all( action='DESELECT')
                # select(mesh_obj)
                rotation=self.plane.rotation_euler.copy()
                # mesh_obj.data.use_auto_smooth=True
                mesh_obj.rotation_mode='ZYX'
                mesh_obj.rotation_euler[0],mesh_obj.rotation_euler[1],mesh_obj.rotation_euler[2]=-rotation[0],-rotation[1],-rotation[2]
                with context.temp_override(active_object=mesh_obj,selected_objects=[mesh_obj,],selected_editable_objects=[mesh_obj,]):
                    bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
                mesh_obj.rotation_mode='XYZ'
                mesh_obj.rotation_euler=rotation
                #bm_for_center=bmesh.new()
                bm_for_center.from_mesh(mesh_obj.data)
                bm_for_center.faces.ensure_lookup_table()
                center=mesh_obj.evaluated_get(bpy.context.evaluated_depsgraph_get()).matrix_world@bm_for_center.faces[0].calc_center_bounds()
                bm_for_center.free()
                delete_object_with_data(mesh_obj)
                center=raycast(center,normal,object_evaluated.matrix_world@cp_verts[0].co+grid_offset*normal,normal)
                
                bm_for_center.free()
            if not self.hide_inset_verts and bm:
                faceverts+=[(object_evaluated.matrix_world@v.co)+grid_offset*normal for v in bm.faces[index].verts]
            all_verts=[]
            if bm:
                bm.faces.ensure_lookup_table()
                centroid=object_evaluated.matrix_world@bm.faces[index].calc_center_median()+grid_offset*normal

                self.centroid=(object_evaluated.matrix_world@bm.faces[index].calc_center_median_weighted()+grid_offset*normal).to_tuple()
                distances=[]
                for v in faceverts:
                    distances.append((v,(v-Vector(centroid)).length))
                distances=sorted(distances,key =lambda v:v[1])[-2:]
                scale_face=sum(v[1] for v in distances)
                if not self.hide_cp_verts:
                    faceverts.extend([(object_evaluated.matrix_world@v.co)+grid_offset*normal for v in cp_verts])
                all_verts=faceverts[:]
                if cp_faces:
                    faces=bmesh.ops.inset_region(bm,faces=cp_faces,thickness=scale_face*self.inset_amount,use_even_offset=True,use_boundary =True)
                    bm.faces.ensure_lookup_table()
                    fverts=set([])
                    
                    for f in faces['faces']:
                        fverts.update(f.verts)
                    if not self.hide_inset_verts:
                        faceverts+=[(object.matrix_world@v.co)+grid_offset*normal for v in fverts]
                    all_verts+=[(object.matrix_world@v.co)+grid_offset*normal for v in fverts]
            distances=[]
            if self.obj:
                center_1=center if center else centroid
                for v in all_verts:
                    distances.append((v,(v-Vector(center_1)).length))
                distances=sorted(distances,key =lambda v:v[1])[-2:]
                #print(distances)
                scale=sum(v[1] for v in distances)/1.8
                scale=myceil(scale,0.3)
                scale=max(0.05,scale)
                object_evaluated=self.obj.evaluated_get(depsgraph)
                self.plane.scale=Vector((scale,scale,scale))*self.plane_scale[0]
            if center:
                self.plane.location =Vector(center)
            else:
                self.plane.location =Vector(self.centroid)
            self.plane.rotation_euler = (self.plane.rotation_euler.to_matrix() @ Matrix.Rotation(math.radians(self.rotation_x), 3, 'X')).to_euler()
            self.plane.rotation_euler = (self.plane.rotation_euler.to_matrix() @ Matrix.Rotation(math.radians(self.rotation_y), 3, 'Y')).to_euler()
            self.plane.rotation_euler = (self.plane.rotation_euler.to_matrix() @ Matrix.Rotation(math.radians(self.rotation_z), 3, 'Z')).to_euler()
            
            
            
            
            # bpy.ops.object.select_all( action='DESELECT')
            plane_evaluated=self.plane.evaluated_get(bpy.context.evaluated_depsgraph_get())
            mesh = plane_evaluated.data
            mesh.calc_loop_triangles()
            bm = bmesh.new()
            bm.from_mesh(mesh)
            bm.faces.ensure_lookup_table() 
            coords = [plane_evaluated.matrix_world@v.co for v in bm.verts]
            
            self.indices = [(e.verts[0].index,e.verts[1].index) for e in bm.edges] 
            self.faceverts=faceverts+[Vector(self.centroid)]

            if center:
                self.bigverts.append(Vector(center))
            else:
                self.bigverts.append(Vector(self.centroid))

            self.plane_normal=self.normal
            mx_inv = self.plane.matrix_world.inverted()
            mx_norm = mx_inv.transposed().to_3x3()

            self.plane_normal = mx_norm @ self.plane.data.polygons[0].normal
            self.plane_location=self.plane.location.copy()
            # self.plane_normal = self.plane.matrix_world.to_3x3().transposed() @ self.plane.data.polygons[0].normal
            self.coords=coords
            # bm.free()
            
            self.centroid=self.plane.location.copy()
            self.rotated_by=self.plane.rotation_euler.copy()
            bpy.context.scene.collection.objects.unlink(self.plane)
            self.grid_placed=True
            self.normal=self.plane_normal.normalized()
            self.batch_big_points=batch_for_shader(self.shader, 'POINTS', {"pos": self.bigverts})
            # print(self.coords)
        return True
    def modal(self, context, event):
        context.area.tag_redraw()
        region = context.region
        rv3d = context.region_data
        coord = event.mouse_region_x,event.mouse_region_y
        view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        if event.type=='LEFT_CTRL' and event.value=='PRESS':
            
            #if preferences().industry_keymap or len(self.polycoords)<1 or self.draw_type!='POLYGON':
            if not self.first_click:
                self.event=event
                self.X=event.mouse_region_x
                self.Y=event.mouse_region_y
            #self.plane_scale=Vector((0,0,0))
            self.main(context)
            self.grid_hidden=False
                
            self.generate_grid()
            #self.activeKey="CTRL"
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='LEFT_CTRL' and event.value=='RELEASE':
            self.auto_hide_grid=True
            if self.auto_hide_grid:
                self.grid_hidden=True
                self.batch_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_object_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_green=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_big_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_yellow_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                #self.activeKey=None
                context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type == 'MOUSEMOVE':
            self.get_mouse_location(context, event)
            self.point_distance_threshold=0.2
            if self.grid_placed:
                self.location=self.get_snapped_location(event, view_vector, ray_origin)
                if self.first_click:
                    self.second_click=self.location
            else:
                if self.first_click:
                    self.second_click,self.second_click_object,self.second_normal,index = self.get_mouse_location(context, event)
            if self.second_click:
                if self.constraint_x:
                    self.second_click.y=self.first_click.y
                    self.second_click.z=self.first_click.z
                if self.constraint_y:
                    self.second_click.x=self.first_click.x
                    self.second_click.z=self.first_click.z
                if self.constraint_z:
                    self.second_click.x=self.first_click.x
                    self.second_click.y=self.first_click.y
                        
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if not self.first_click:
                if not self.grid_placed:
                    self.X=event.mouse_region_x
                    self.Y=event.mouse_region_y
                    self.main(context)
                    self.generate_grid(hide=not event.ctrl)
                if event.ctrl and self.grid_placed:
                    self.location=self.get_snapped_location(event, view_vector, ray_origin)
                    self.first_click=self.location
                    # print("Snapped",self.first_click)
                elif not self.grid_placed:
                    self.first_click,self.first_click_object,self.first_normal,index = self.get_mouse_location(context, event)
                    context.view_layer.objects.active = self.first_click_object
                else:
                    self.first_click=raycast(ray_origin,view_vector,self.plane.location,self.plane_normal)
                    # print("First",self.first_click)    
                return {'RUNNING_MODAL'}
            else:
                if event.ctrl and self.grid_placed:
                    self.location=self.get_snapped_location(event, view_vector, ray_origin)
                    self.second_click=self.location
                elif self.grid_placed:
                    self.second_click=raycast(ray_origin,view_vector,self.plane.location,self.plane_normal)
                else:
                    self.second_click,self.second_click_object,self.second_normal,index = self.get_mouse_location(context, event)
                
                if self.second_click:
                    if self.constraint_x:
                        self.second_click.y=self.first_click.y
                        self.second_click.z=self.first_click.z
                    if self.constraint_y:
                        self.second_click.x=self.first_click.x
                        self.second_click.z=self.first_click.z
                    if self.constraint_z:
                        self.second_click.x=self.first_click.x
                        self.second_click.y=self.first_click.y
                if not self.second_click:
                    return {'RUNNING_MODAL'}
                if self.plane_normal:
                    self.first_normal=self.plane_normal
                bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
                bpy.types.SpaceView3D.draw_handler_remove(self.drawHandlerUI,"WINDOW")
                self.obj1_location = Vector((self.first_click.x, self.first_click.y, self.first_click.z ))+(self.first_normal.normalized()*0.2)
                self.obj2_location = Vector((self.second_click.x, self.second_click.y, self.second_click.z))+(self.first_normal.normalized()*0.2)
                self.corner_obj1_name,self.corner_obj2_name=context.selected_objects[0].name,context.selected_objects[1].name
                self.distribute=True
                self.disable_non_mesh_options=False
                for a in context.selected_objects:
                    if a.type!='MESH':
                        self.disable_non_mesh_options=True
                        self.method="Origin"
                        self.dmethod="Origin"
                self.selected_objects=sorted([obj for obj in context.selected_objects ], key=lambda v: v.matrix_world.translation.dot(self.second_click-self.first_click))
                self.selected_objects=[a.name for a in self.selected_objects]
                self.corner_obj1_name,self.corner_obj2_name=self.selected_objects[0],self.selected_objects[len(self.selected_objects)-1]
                # with context.temp_override(override={'selected_objects': list(proximity_objects)+context.selected_objects}):
                # bpy.ops.aad.align('INVOKE_DEFAULT',distribute=True,corner_objects_given=True,given_obj1=self.first_click_object.name,given_obj2=self.second_click_object.name,daxis_a=self.distribute_along_all_axis,daxis_x=self.distribute_along_x_axis,daxis_y=self.distribute_along_y_axis,daxis_z=self.distribute_along_z_axis)
                return self.execute(context)
                return {'FINISHED'}
        if event.type == 'WHEELUPMOUSE':
            if event.ctrl:
                self.plane_scale.x = max(self.plane_scale.x + 0.2, 0.1)
                self.plane_scale.y = max(self.plane_scale.y + 0.2, 0.1)
                self.plane_scale.z = max(self.plane_scale.z + 0.2, 0.1)
                self.main(context)
                self.generate_grid()
            else:
                return {'PASS_THROUGH'}
            return {'RUNNING_MODAL'}    
        elif event.type == 'WHEELDOWNMOUSE':
            if event.ctrl:
                self.plane_scale.x = max(self.plane_scale.x - 0.2, 0.1)
                self.plane_scale.y = max(self.plane_scale.y - 0.2, 0.1)
                self.plane_scale.z = max(self.plane_scale.z - 0.2, 0.1)
                
                self.main(context)
                self.generate_grid()
            else:
                return {'PASS_THROUGH'}
            
            return {'RUNNING_MODAL'}    

        if event.type=='X' and event.value=='PRESS':
            self.constraint_x=not self.constraint_x
            self.constraint_z=False
            self.constraint_y=False
            return {'RUNNING_MODAL'}
        if event.type=='Y' and event.value=='PRESS':
            self.constraint_y=not self.constraint_y
            self.constraint_z=False
            self.constraint_x=False
            return {'RUNNING_MODAL'}
        if event.type=='Z' and event.value=='PRESS':
            self.constraint_z=not self.constraint_z
            self.constraint_x=False
            self.constraint_y=False
            return {'RUNNING_MODAL'}
        if event.type=='S' and event.value=='PRESS':
            self.snap_to_grid=not self.snap_to_grid
            return {'RUNNING_MODAL'}
        if event.type in {'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE','NUMPAD_1','NUMPAD_2','NUMPAD_3','NUMPAD_4','NUMPAD_5','NUMPAD_6','NUMPAD_7','NUMPAD_8','NUMPAD_9'} and event.value=='PRESS':
            number_dict={'ONE':1,'TWO':2,'THREE':3,'FOUR':4,'FIVE':5,'SIX':6,'SEVEN':7,'EIGHT':8,'NINE':9,'NUMPAD_1':1,'NUMPAD_2':2,'NUMPAD_3':3,'NUMPAD_4':4,'NUMPAD_5':5,'NUMPAD_6':6,'NUMPAD_7':7,'NUMPAD_8':8,'NUMPAD_9':9}
            self.subsurf_level=number_dict[event.type]
            if self.grid_placed:
                self.main(context)
                self.generate_grid()
            return {'RUNNING_MODAL'}
        if event.type == 'RIGHTMOUSE' or event.type == 'ESC':
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandlerUI,"WINDOW")
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
            return {'CANCELLED'}

        if event.type == 'LEFT_CTRL' and event.value == 'PRESS':
            self.snap_enabled = True

        if event.type == 'LEFT_CTRL' and event.value == 'RELEASE':
            self.snap_enabled = False

        return {'PASS_THROUGH'}

    def get_snapped_location(self, event, view_vector, ray_origin):
        location=raycast(ray_origin,view_vector,self.plane.location,self.plane_normal.normalized())
        if location is None:
            location=Vector((0,0,0))
        green_coords=[(v,(location-v).length) for v in self.coords if (location-v).length<self.point_distance_threshold]
        green_coords+=[(v,(location-v).length) for v in self.faceverts if (location-v).length<self.point_distance_threshold]
        green_coords+=[(v,(location-v).length) for v in self.bigverts if (location-v).length<self.point_distance_threshold]
        self.last_hit_location=location
                    
        closest=[]
        if len(green_coords)>0:
            closest=[sorted(green_coords,key=lambda v:v[1])[0][0]]
        if event.ctrl:
            self.batch_green=batch_for_shader(self.shader, 'POINTS', {"pos": closest})
            if len(closest)>0:
                location=closest[0]
        else:
            self.batch_green=batch_for_shader(self.shader, 'POINTS', {"pos": []})
        return location
    def update_proximity_objects(self):
        if self.second_click_object:
                proximity_objects=get_objects_in_proximity(self.first_click_object, self.second_click_object, 10, self.proximity_radius,self.smart_select)
                self.proximity_object_locations=[a.location for a in proximity_objects]

    def invoke(self, context, event):
        if len(context.selected_objects)<2:
            self.report({'WARNING'}, "Please select atleast two objects")
            return {'CANCELLED'}
        self.snap_to_grid=True
        self.dup_bm=None
        self.plane_normal=None
        self.obj=None
        self.shader = gpu.shader.from_builtin(get_correct_shader_name('3D_UNIFORM_COLOR'))
        self.grid_placed=False
        self.last_obj=None
        self.subsurf_level=5
        self.plane=None
        self.batch_green=None
        self.batch_points=None
        self.batch_object_points=None
        self.batch_big_points=None
        self.hide_inset_verts=True
        self.hide_cp_verts=True
        self.inset_amount=0.5
        self.plane_scale=Vector((1,1,1))
        self.rotation_axis='Z'
        self.rotation_z=0
        self.rotation_x=0
        self.rotation_y=0
        
        self.constraint_x=False
        self.constraint_y=False
        self.constraint_z=False
        self.use_fixed_gap=False
        self.proximity_object_locations=[]
        self.proximity_radius=context.scene.aad_props.last_proximity_radius
        self.smart_select=context.scene.aad_props.smart_select
        self.first_click_object=None
        self.second_click_object=None
        self.daxis_a=True
        self.daxis_x=False
        self.daxis_y=False
        self.daxis_z=False
        aad_props=context.scene.aad_props
        self.dmethod=aad_props.dmethod
        self.linear_method=aad_props.linear_method
        if context.area.type == 'VIEW_3D':
            self.drawHandlerUI=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
            self.drawHandle=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_pv, (context,), 'WINDOW', 'POST_VIEW')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "View3D not found, cannot run operator")
            return {'CANCELLED'}

    def get_mouse_location(self, context, event):
        region = context.region
        rv3d = context.region_data
        coord = event.mouse_region_x, event.mouse_region_y
        view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        self.view_vector=view_vector
        result, location, normal, index, object, matrix = context.scene.ray_cast(bpy.context.evaluated_depsgraph_get(), ray_origin, view_vector)
        return (location,object,normal,index) if result else (None,None,None,None)

    def draw_callback_pv(self, context):
        if self.grid_placed:
            self.draw_grid(context)
        if self.first_click and self.second_click:
            loc1 = self.first_click
            loc2 = self.second_click
            self.draw_line(context, loc1, loc2)
            # self.draw_plane_with_grid(self.first_click,  (self.second_click[0], self.second_click[1], self.first_click[2]),self.second_click, (self.first_click[0], self.first_click[1], self.second_click[2]), 3)
    def draw_grid(self,context):
        if self.shader is not None:
            
            gpu.state.point_size_set(3)
            gpu.state.blend_set("ALPHA") 
            self.shader.bind()
            self.shader.uniform_float("color", (0, 0.5, 1, 0.3))
            if self.batch_points:
                self.shader.uniform_float("color", (1,1,1,1))
                self.batch_points.draw(self.shader)
            if self.batch_object_points:
                gpu.state.point_size_set(5)
                self.shader.uniform_float("color", (1, 0, 0, 0.75))
                self.batch_object_points.draw(self.shader)
            if self.batch_big_points:
                gpu.state.point_size_set(5)
                self.shader.uniform_float("color", (1, 0, 1, 0.5))
                self.batch_big_points.draw(self.shader)
            if self.batch_green is not None:
                gpu.state.point_size_set(10)
                self.shader.uniform_float("color", (0, 1, 0.7, 1))
                self.batch_green.draw(self.shader)
            # if self.batch_yellow_points:
            #     self.shader.uniform_float("color", (1, 0, 0, 0.8 if self.line_type_grid else 0.4))
            #     self.batch_yellow_points.draw(self.shader)
            #bgl.glEnable(bgl.GL_LINE_SMOOTH)

            gpu.state.blend_set("NONE") 
            #bgl.glDisable(bgl.GL_LINE_SMOOTH)
    def generate_distribution_string(self):
        if self.daxis_a:
            return "All"
        
        axis_list = []
        if self.daxis_x:
            axis_list.append("X")
        if self.daxis_y:
            axis_list.append("Y")
        if self.daxis_z:
            axis_list.append("Z")

        return ", ".join(axis_list) if axis_list else "None"
    def draw_callback_px(self, context):
        constraint='NONE'
        if self.constraint_x:
            constraint='X'
        elif self.constraint_y:
            constraint='Y'
        elif self.constraint_z:
            constraint='Z'
        draw_Text(context,0,preferences().font_size,text=[f"X/Y/Z: Constraint ({constraint})","Hold [CTRL] : Show Grid","CTRL+Scroll: Resize Grid",f"[1-9]: Grid Divisions ({self.subsurf_level})",f"S: Snap to Grid/Object ({'Grid' if self.snap_to_grid else 'Object'})"],alignH="CENTER",alignV="BOTTOM",activeKey=None)
        draw_Text(context,0,preferences().font_size,text=["Align and Distribute Selected Objects along a Plane","Click on 2 surfaces to distribute",],alignH="CENTER",alignV="TOP",activeKey=None)
        
        region = context.region
        rv3d = context.region_data
        point1=None
        point2=None
        if self.first_click:
            point1=view3d_utils.location_3d_to_region_2d(region, rv3d, self.first_click)
        if self.second_click:
            point2=view3d_utils.location_3d_to_region_2d(region, rv3d, self.second_click)
        draw_circles(context,[point1,point2])
        
    def draw_line(self, context, start, end):
        gpu.state.line_width_set(5)
        gpu.state.blend_set("ALPHA") 
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'LINES', {"pos": [start, end]},indices=[(0,1)])

        shader.bind()
        shader.uniform_float("color", (0.0, 0.6, 0.8, 0.7))
        batch.draw(shader)
        
        
        gpu.state.line_width_set(1)
        gpu.state.blend_set("NONE") 
        

    def create_circle_vertices(self,center, radius, segments=32):
        vertices = []
        for i in range(segments):
            angle = 2 * math.pi * i / segments
            x = center.x + radius * math.cos(angle)
            y = center.y + radius * math.sin(angle)
            vertices.append(Vector((x, y, center.z)))
        return vertices

    
    def align_vertices_with_vector(self,origin,vertices, target_vector):
        """Align circle vertices with the specified 3D vector while keeping the center fixed."""
        # Ensure target_vector is normalized
        target_vector = target_vector.normalized()
        
        # Calculate the current normal (Z-axis in object space)
        current_normal = Vector((0, 0, 1))
        
        # Calculate the rotation needed to align current_normal with target_vector
        rotation_matrix = current_normal.rotation_difference(target_vector).to_matrix().to_4x4()
        
        # Translate vertices to origin, apply rotation, and translate back
        translated_vertices = [v - origin for v in vertices]  # Move to origin
        rotated_vertices = [rotation_matrix @ Vector(v) for v in translated_vertices]  # Rotate
        aligned_vertices = [v + origin for v in rotated_vertices]  # Move back
        
        return aligned_vertices
    def project_point_onto_plane(self,point, plane_normal, plane_point):
        # Project a point onto a plane
        vector_to_point = point - plane_point
        distance = vector_to_point.dot(plane_normal)
        projection = point - distance * plane_normal
        return projection
    def draw_plane_with_grid(self,corner1, corner2, corner3, corner4, divisions, point_radius=0.05):
        # Calculate plane normal
        corner1=Vector(corner1)
        corner2=Vector(corner2)
        corner3=Vector(corner3)
        corner4=Vector(corner4)
        edge1 = corner2 - corner1
        edge2 = corner4 - corner1
        plane_normal = edge1.cross(edge2).normalized()

        # Prepare shaders
        shader_plane = gpu.shader.from_builtin('UNIFORM_COLOR')
        shader_points = gpu.shader.from_builtin('UNIFORM_COLOR')

        # Plane vertices and indices for filling
        plane_vertices = [corner1, corner2, corner3, corner4]
        plane_indices = [(0, 1, 2), (0, 2, 3)]

        # Create batch for the plane (filled with teal color)
        batch_plane = batch_for_shader(shader_plane, 'TRIS', {"pos": plane_vertices}, indices=plane_indices)

        # Create batch for grid points (drawn as circles)
        circle_vertices = []
        circle_indices = []
        # Project circles onto the plane
        for i in range(divisions + 1):
            for j in range(divisions + 1):
                u = i / divisions
                v = j / divisions
                # Calculate grid point
                point = (corner1 * (1 - u) + corner2 * u) * (1 - v) + (corner4 * (1 - u) + corner3 * u) * v
                circle = self.create_circle_vertices(point, point_radius)
                circle_transformed = self.align_vertices_with_vector(point,circle, plane_normal)
                start_index = len(circle_vertices)
                circle_vertices.extend(circle_transformed)
                for k in range(1, len(circle) - 1):
                    circle_indices.append((start_index, start_index + k, start_index + k + 1))

        # Create batch for circles
        batch_circles = batch_for_shader(shader_points, 'TRIS', {"pos": circle_vertices}, indices=circle_indices)

        # Draw the filled plane
        shader_plane.bind()
        shader_plane.uniform_float("color", (0.0, 0.6, 0.8, 0.5))  # Teal color with transparency
        batch_plane.draw(shader_plane)

        # Draw the grid circles
        shader_points.bind()
        shader_points.uniform_float("color", (1.0, 1.0, 1.0, 0.5))  # White color with transparency
        gpu.state.point_size_set(5)  # Set the size of the circles (may not affect the final appearance)
        batch_circles.draw(shader_points)
class AAD_OT_DistributeAlongAxis(bpy.types.Operator):
    bl_idname = "aad.distributealongaxis"
    bl_label = "Quick Distribute"
    bl_options = {'REGISTER', 'UNDO'}
    first_click = None
    second_click = None
    snap_enabled = False
    align:bpy.props.BoolProperty(name="Align",options={'SKIP_SAVE'})
    distribute:bpy.props.BoolProperty(name="Distribute",options={'SKIP_SAVE'})
    method:bpy.props.EnumProperty(items=(("Origin","Origin","Origin"),("Bounding Box","Bounding Box","Bounding Box")),default=1,name="Method")
    dmethod:bpy.props.EnumProperty(items=(("Origin","Origin","Origin"),("Bounding Box","Bounding Box","Bounding Box")),default=1,name="Method")
    #task:bpy.props.EnumProperty(items=(("Align","Align","Align"),("Distribute","Distribute","Distribute")))
    direction:bpy.props.EnumProperty(items=get_direction_items)
    axis:bpy.props.EnumProperty(items=(("0","X","X"),("1","Y","Y"),("2","Z","Z")))#,("-X","-X","-X"),("-Y","-Y","-Y"),("-Z","-Z","-Z")
    axis_x:bpy.props.BoolProperty(name="X",options={'SKIP_SAVE'})
    axis_y:bpy.props.BoolProperty(name="Y",options={'SKIP_SAVE'})
    axis_z:bpy.props.BoolProperty(name="Z",options={'SKIP_SAVE'})
    daxis_x:bpy.props.BoolProperty(name="X",options={'SKIP_SAVE'})
    daxis_y:bpy.props.BoolProperty(name="Y",options={'SKIP_SAVE'})
    daxis_z:bpy.props.BoolProperty(name="Z",options={'SKIP_SAVE'})
    daxis_a:bpy.props.BoolProperty(name="All",options={'SKIP_SAVE'})
    distribute_pattern:bpy.props.EnumProperty(items=(("1D","1D","1D"),("2D","2D","2D"),("3D","3D","3D")),options={'SKIP_SAVE'})#,("3D","3D","3D")
    daxis:bpy.props.EnumProperty(items=(("0","X","X"),("1","Y","Y"),("2","Z","Z")))
    plane:bpy.props.EnumProperty(items=(("X","X","X"),("Y","Y","Y"),("Z","Z","Z")),options={'SKIP_SAVE'})
    linear_method:bpy.props.EnumProperty(items=(("Equal Distance","Equal Distance","Equal Distance"),("Equal Gap","Equal Gap","Equal Gap")))
    grid_2d:bpy.props.IntVectorProperty(size=2,min=2,default=[2,2],name="Grid Size")
    grid_3d:bpy.props.IntVectorProperty(size=3,min=2,default=[2,2,2],name="Grid Size")
    #grid_y:bpy.props.IntProperty(default=3,min=2)
    #grid_z:bpy.props.IntProperty(default=3,min=2)
    size_2d:bpy.props.FloatVectorProperty(size=2,default=[1,1],name="Cell Size")
    size_3d:bpy.props.FloatVectorProperty(size=3,default=[1,1,1],name="Cell Size")
    flip_2d:bpy.props.BoolVectorProperty(default=(False,False),size=2,name="Flip")
    flip_3d:bpy.props.BoolVectorProperty(default=(False,False,False),size=3,name="Flip")
    #size_y:bpy.props.FloatProperty(default=1)
    #size_z:bpy.props.FloatProperty(default=1)
    h_dir:bpy.props.EnumProperty(items=(("RIGHT","RIGHT","RIGHT"),("LEFT","LEFT","LEFT")))
    v_dir:bpy.props.EnumProperty(items=(("DOWN","DOWN","DOWN"),("UP","UP","UP")))
    flow_switch:bpy.props.BoolProperty(default=False,name="Switch Flow",description="Switch between Row and Column flow")
    use_fixed_gap:bpy.props.BoolProperty(default=False,name="Use Fixed Gap",description="Use Fixed Gap")
    gap:bpy.props.FloatProperty(default=0.1,name="Gap")
    use_random_grid_assignment:bpy.props.BoolProperty(default=False,name="Random Grid Assignment",description="Random Grid Assignment")
    random_seed:bpy.props.IntProperty(default=0,name="Random Seed")
    corner_objects_given:bpy.props.BoolProperty(name="Corner Objects Given",default=False,options={'SKIP_SAVE'})
    given_obj1:bpy.props.StringProperty(name="Object 1",options={'SKIP_SAVE'})
    given_obj2:bpy.props.StringProperty(name="Object 2",options={'SKIP_SAVE'})
    use_same_objects_for_each_axis:bpy.props.BoolProperty(name="Use Same Corner Objects For Each Axis",default=False,options={'SKIP_SAVE'})
    axis_combo:bpy.props.IntProperty(default=0,options={'SKIP_SAVE'},max=5,min=0,name='AXIS(Try changing if orientation is not correct)')
    def draw(self, context):
        layout= self.layout
        if self.distribute:
            layout.row().prop(self,'distribute_pattern',expand=True)
            if self.distribute_pattern=="1D":
                if not self.disable_non_mesh_options:
                    layout.row().prop(self,'dmethod',expand=True) 
            if self.distribute_pattern=="1D":

                if self.dmethod=="Bounding Box":
                    if not self.disable_non_mesh_options:
                        layout.row().prop(self,'linear_method',expand=True)
                layout.label(text="Distribution Axis")
                row=layout.row(align=True)
                row.prop(self,'daxis_a',toggle=True)
                if not self.daxis_a:
                    row.prop(self,'daxis_x',toggle=True)
                    row.prop(self,'daxis_y',toggle=True)
                    row.prop(self,'daxis_z',toggle=True)
                    if sum([self.daxis_x,self.daxis_y,self.daxis_z])>1:
                        layout.prop(self,'use_same_objects_for_each_axis',toggle=True)
                row=layout.row(align=True)
                row.prop(self,'use_fixed_gap',toggle=True)
                if self.use_fixed_gap:
                    row.prop(self,'gap')
            elif self.distribute_pattern=="2D":
                layout.label(text="Distribution Plane")
                layout.row().prop(self,'plane',expand=True)

                layout.prop(self,'grid_2d')
                #layout.prop(self,'grid_y')
                row=layout.row()
                row=row.split(factor=0.9,align=True)
                col=row.column()
                col.prop(self,'size_2d')
                col=row.column()
                col.prop(self,'flip_2d',toggle=True,icon='ARROW_LEFTRIGHT')
                # layout.prop(self,'size_2d')
                #layout.prop(self,'size_y')
                # layout.label(text='Distribution Plane')
                # layout.row().prop(self,'h_dir',expand=True)
                # layout.row().prop(self,'v_dir',expand=True)
                layout.prop(self,'flow_switch',toggle=True)
                layout.prop(self,'use_random_grid_assignment',toggle=True)
                if self.use_random_grid_assignment:
                    layout.prop(self,'random_seed')
            elif self.distribute_pattern=="3D":
                layout.prop(self,'grid_3d')
                #layout.prop(self,'grid_y')
                row=layout.row()
                row=row.split(factor=0.9,align=True)
                col=row.column()
                col.prop(self,'size_3d')
                col=row.column()
                col.prop(self,'flip_3d',toggle=True,icon='ARROW_LEFTRIGHT')
                layout.prop(self,'use_random_grid_assignment',toggle=True)
                if self.use_random_grid_assignment:
                    layout.prop(self,'random_seed')
                
    def execute(self,context):
        active=context.active_object
        selected_objects=[]
        for a in self.selected_objects:
            obj=bpy.data.objects.get(a)
            selected_objects.append(obj)
        #objs=[a for a in [a for a in context.selected_objects if a.type=='MESH'] if a !=active]
        objs=[a for a in selected_objects if a !=active]
        
        if self.distribute:
            self.corner_obj1,self.corner_obj2=bpy.data.objects.get(self.corner_obj1_name),bpy.data.objects.get(self.corner_obj2_name)
            #print(self.distribute_pattern,self.dmethod,self.daxis)
            if self.distribute_pattern=="1D":
                if self.dmethod == "Origin":
                    axes = [3,0, 1, 2]

                    for axis in axes:
                        if getattr(self, f'daxis_{"xyza"[axis]}'):
                            objs = objs
                            axis_v=Vector((1 if axis==0 else 0,1 if axis==1 else 0,1 if axis==2 else 0))
                            if axis==3:
                                axis_v=self.corner_obj1.location-self.corner_obj2.location
                            if axis_v.length==0:
                                self.report({'WARNING'}, "No Space to distribute selected objects")
                                return {'FINISHED'}
                            self.left_obj = corner_object(objs, axis_v)
                            self.right_obj = corner_object(objs, (-axis_v[0],-axis_v[1],-axis_v[2]))


                            middle_objs = sorted([obj for obj in objs if obj not in [self.left_obj, self.right_obj]], key=lambda v: v.location.dot(axis_v))

                            objects_to_distribute = middle_objs + [self.right_obj] if self.use_fixed_gap else middle_objs
                            count = len(objects_to_distribute)
                            
                            locations_generated = generate_points(self.left_obj.location, self.right_obj.location, count, axis_v,self.gap if self.use_fixed_gap else None)

                            for i, obj in enumerate(objects_to_distribute):
                                if axis==3:
                                    obj.location = locations_generated[i]
                                else:
                                    obj.location[axis] = locations_generated[i][axis]
                            if axis==3:
                                break
                        
                elif self.dmethod=="Bounding Box":
                    axes = [3,0, 1, 2]
                    self.fixed_object1=None
                    self.fixed_object2=None
                    self.middle_sorted=[]
                    for axis in axes:
                        if getattr(self, f'daxis_{"xyza"[axis]}'):
                            selected_objects=[]
                            for a in self.selected_objects:
                                obj=bpy.data.objects.get(a)
                                selected_objects.append(obj)
                            objs = [obj for obj in selected_objects if obj.type == 'MESH']
                            
                            axis_v=Vector((1 if axis==0 else 0,1 if axis==1 else 0,1 if axis==2 else 0))
                            if axis == 3:
                                middle=(self.corner_obj1.location+self.corner_obj2.location)/2
                                axis_v = (self.corner_obj2.location - self.corner_obj1.location).normalized()
                                # print("axis_v",axis_v)
                                # axis_v = axis_v + self.corner_obj1.location
                                # print("after",axis_v)
                            if axis_v.length==0:
                                self.report({'WARNING'}, "No Space to distribute selected objects")
                                return {'FINISHED'}
                            self.left_obj = corner_object(objs, axis_v)
                            # print("First",left_obj)
                            self.right_obj = corner_object(objs, (-axis_v[0],-axis_v[1],-axis_v[2]))
                            if not self.fixed_object1:
                                self.fixed_object1=self.left_obj
                            if not self.fixed_object2:
                                self.fixed_object2=self.right_obj
                            if self.use_same_objects_for_each_axis:
                                self.left_obj=self.fixed_object1
                                self.right_obj=self.fixed_object2
                            # print("Last",right_obj)
                            if axis==3:
                                self.left_obj=self.corner_obj1
                                self.right_obj=self.corner_obj2
                                self.left_obj.location=self.left_obj.location-middle
                                self.right_obj.location=self.right_obj.location-middle
                            # print("LR",left_obj,right_obj,axis_v)
                            # print(objs)
                            middle_objs = sorted([obj for obj in objs if obj not in [self.left_obj, self.right_obj]], key=lambda v: v.location.dot(axis_v))
                            if not self.middle_sorted:
                                self.middle_sorted=middle_objs
                            if self.use_same_objects_for_each_axis:
                                middle_objs=self.middle_sorted
                            objects_to_distribute = middle_objs + [self.right_obj] if self.use_fixed_gap else middle_objs
                            count = len(objects_to_distribute)
                            if self.linear_method == "Equal Gap":
                                locations_generated = generate_points_bb(self.left_obj, self.right_obj, middle_objs,axis_v , context, self.gap if self.use_fixed_gap else None)
                                # print(locations_generated)
                                # axis_vector = axis.normalized()

                                # for i, obj in enumerate(objects_to_distribute):
                                #     # Calculate the new location by moving along the axis vector
                                #     current_location = obj.location
                                #     new_location = current_location + axis_vector * (locations_generated[i] - current_location.dot(axis_vector))
                                #     obj.location = new_location
                                # print(len(objects_to_distribute))
                                # print(left_obj.location,right_obj.location)
                                if axis==3:
                                    self.left_obj.location=self.left_obj.location+middle
                                    self.right_obj.location=self.right_obj.location+middle
                                for i, obj in enumerate(objects_to_distribute):
                                    if axis==3:
                                        obj.location = locations_generated[i]+middle
                                    else:
                                        obj.location[axis] = locations_generated[i][axis]
                            else:
                                if axis==3:
                                    self.left_obj.location=self.left_obj.location+middle
                                    self.right_obj.location=self.right_obj.location+middle
                                locations_generated = generate_points(self.left_obj.location, self.right_obj.location, count, axis_v,self.gap if self.use_fixed_gap else None)

                                for i, obj in enumerate(objects_to_distribute):
                                    middle = find_middle(obj, axis_v, context)
                                    if axis==3:
                                        obj.location = locations_generated[i]+ (obj.location-middle )
                                    else:
                                        obj.location[axis] = locations_generated[i][axis]+ (obj.location[axis]-middle[axis] )
                                    # print(obj,middle)
                                    # obj.location = locations_generated[i] + (obj.location-middle )
                            
                            if axis==3:
                                break
                            
            elif self.distribute_pattern=="2D":
                    objs=[active,]+objs
                    size_x=self.size_2d[0] if not self.flip_2d[0] else -self.size_2d[0]
                    size_y=self.size_2d[1] if not self.flip_2d[1] else -self.size_2d[1]
                    locations_generated=generate_grid_points(self.grid_2d[0],self.grid_2d[1],size_x,size_y,active.location,plane=self.plane,flow=1 if self.flow_switch else 0)
                    if self.use_random_grid_assignment:
                        random.seed(self.random_seed)
                        random.shuffle(locations_generated)
                    for i,obj in enumerate(objs):
                        if self.plane=="Z":
                            obj.location=(locations_generated[i%len(locations_generated)][0],locations_generated[i%len(locations_generated)][1],obj.location[2])
                        elif self.plane=="Y":
                            obj.location=(locations_generated[i%len(locations_generated)][0],obj.location[1],locations_generated[i%len(locations_generated)][2])
                        elif self.plane=="X":
                            obj.location=(obj.location[0],locations_generated[i%len(locations_generated)][1],locations_generated[i%len(locations_generated)][2])
            elif self.distribute_pattern=="3D":
                    objs=[active,]+objs
                    size_x=self.size_3d[0] if not self.flip_3d[0] else -self.size_3d[0]
                    size_y=self.size_3d[1] if not self.flip_3d[1] else -self.size_3d[1]
                    size_z=self.size_3d[2] if not self.flip_3d[2] else -self.size_3d[2] 
                    locations_generated=generate_grid_points_3d(self.grid_3d[0],self.grid_3d[1],self.grid_3d[2],size_x,size_y,size_z,active.location,flow=1 if self.flow_switch else 0)
                    if self.use_random_grid_assignment:
                        random.seed(self.random_seed)
                        random.shuffle(locations_generated)
                    for i,obj in enumerate(objs):
                        obj.location=locations_generated[i%len(locations_generated)]
        return {'FINISHED'}
    def modal(self, context, event):
        context.area.tag_redraw()
        if event.type == 'MOUSEMOVE':
            if self.first_click:
                self.second_click,self.second_click_object,self.second_normal,index = self.get_mouse_location(context, event)
            if len(context.selected_objects)<3 and self.second_click_object:
                self.update_proximity_objects()
            else:
                self.proximity_object_locations=[]
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if not self.first_click:
                self.first_click,self.first_click_object,self.first_normal,index = self.get_mouse_location(context, event)
                context.view_layer.objects.active = self.first_click_object
                return {'RUNNING_MODAL'}
            else:
                self.second_click,self.second_click_object,self.second_normal,index = self.get_mouse_location(context, event)
                if not self.second_click_object:
                    return {'RUNNING_MODAL'}
                bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
                bpy.types.SpaceView3D.draw_handler_remove(self.drawHandlerUI,"WINDOW")
                if len(context.selected_objects)<3 :
                    proximity_objects=get_objects_in_proximity(self.first_click_object, self.second_click_object, 10, self.proximity_radius,self.smart_select)
                    if not proximity_objects:
                        self.report({'WARNING'}, "Less than 3 Objects to distribute")
                        return {'CANCELLED'}
                    for a in proximity_objects:
                        try:
                            a.select_set(True)
                        except Exception:
                            pass
                self.corner_obj1_name,self.corner_obj2_name=self.first_click_object.name,self.second_click_object.name
                self.distribute=True
                self.disable_non_mesh_options=False
                for a in context.selected_objects:
                    if a.type!='MESH':
                        self.disable_non_mesh_options=True
                        self.method="Origin"
                        self.dmethod="Origin"
                self.selected_objects=sorted([obj for obj in context.selected_objects ], key=lambda v: v.location.dot(self.second_click-self.first_click))
                self.selected_objects=[a.name for a in self.selected_objects]
                # with context.temp_override(override={'selected_objects': list(proximity_objects)+context.selected_objects}):
                # bpy.ops.aad.align('INVOKE_DEFAULT',distribute=True,corner_objects_given=True,given_obj1=self.first_click_object.name,given_obj2=self.second_click_object.name,daxis_a=self.distribute_along_all_axis,daxis_x=self.distribute_along_x_axis,daxis_y=self.distribute_along_y_axis,daxis_z=self.distribute_along_z_axis)
                return self.execute(context)
                return {'FINISHED'}
        if event.type == 'WHEELUPMOUSE':
            if not self.first_click_object:
                return {'PASS_THROUGH'}
            self.proximity_radius+=1
            context.scene.aad_props.last_proximity_radius=self.proximity_radius
            self.update_proximity_objects()
            return {'RUNNING_MODAL'}    
        elif event.type == 'WHEELDOWNMOUSE':
            if not self.first_click_object:
                return {'PASS_THROUGH'}
            self.proximity_radius=max(0,self.proximity_radius-1)
            context.scene.aad_props.last_proximity_radius=self.proximity_radius
            self.update_proximity_objects()
            return {'RUNNING_MODAL'}    
        if event.type=='A' and event.value=='PRESS':
            self.daxis_a=True
            self.daxis_x=False
            self.daxis_y=False
            self.daxis_z=False
            self.update_proximity_objects()
            return {'RUNNING_MODAL'}
        if event.type=='X' and event.value=='PRESS':
            self.daxis_a=False
            self.daxis_x=not self.daxis_x
            return {'RUNNING_MODAL'}
        if event.type=='Y' and event.value=='PRESS':
            self.daxis_a=False
            self.daxis_y=not self.daxis_y
            return {'RUNNING_MODAL'}
        if event.type=='Z' and event.value=='PRESS':
            self.daxis_a=False
            self.daxis_z=not self.daxis_z
            return {'RUNNING_MODAL'}
        if event.type=='S' and event.value=='PRESS':
            self.smart_select=not self.smart_select
            context.scene.aad_props.smart_select=self.smart_select
            self.update_proximity_objects()
            return {'RUNNING_MODAL'}
        if event.type == 'RIGHTMOUSE' or event.type == 'ESC':
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandlerUI,"WINDOW")
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
            return {'CANCELLED'}

        if event.type == 'LEFT_CTRL' and event.value == 'PRESS':
            self.snap_enabled = True

        if event.type == 'LEFT_CTRL' and event.value == 'RELEASE':
            self.snap_enabled = False

        return {'PASS_THROUGH'}

    
    def update_proximity_objects(self):
        if self.second_click_object:
            proximity_objects=get_objects_in_proximity(self.first_click_object, self.second_click_object, 10, self.proximity_radius,self.smart_select)
            self.proximity_object_locations=[a.location for a in proximity_objects]

    def invoke(self, context, event):

        self.use_fixed_gap=False
        self.proximity_object_locations=[]
        self.proximity_radius=context.scene.aad_props.last_proximity_radius
        self.smart_select=context.scene.aad_props.smart_select
        self.first_click_object=None
        self.second_click_object=None
        self.daxis_a=True
        self.daxis_x=False
        self.daxis_y=False
        self.daxis_z=False
        aad_props=context.scene.aad_props
        self.dmethod=aad_props.dmethod
        self.linear_method=aad_props.linear_method
        if context.area.type == 'VIEW_3D':
            self.drawHandlerUI=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
            self.drawHandle=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_pv, (context,), 'WINDOW', 'POST_VIEW')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "View3D not found, cannot run operator")
            return {'CANCELLED'}

    def get_mouse_location(self, context, event):
        region = context.region
        rv3d = context.region_data
        coord = event.mouse_region_x, event.mouse_region_y
        view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        ray_target = ray_origin + view_vector
        self.view_vector=view_vector
        result, location, normal, index, object, matrix = context.scene.ray_cast(bpy.context.evaluated_depsgraph_get(), ray_origin, view_vector)
        # if result and self.snap_enabled and object.type == 'MESH':
        #     bm= bmesh.new()
        #     bm.from_mesh(object.evaluated_get(bpy.context.evaluated_depsgraph_get()).data)
        #     bm.faces.ensure_lookup_table()
        #     # location=object.matrix_world@bm.faces[index].calc_center_bounds()
        #     bm.free()
        return (location,object,normal,index) if result else (None,None,None,None)

    def draw_callback_pv(self, context):
        if self.first_click_object and self.second_click_object:
            loc1=self.first_click_object.location 
            loc2=self.second_click_object.location 
            self.draw_line(context, loc1, loc2)
            # self.draw_plane_with_grid(self.first_click,  (self.second_click[0], self.second_click[1], self.first_click[2]),self.second_click, (self.first_click[0], self.first_click[1], self.second_click[2]), 3)
    
    def generate_distribution_string(self):
        if self.daxis_a:
            return "All"
        
        axis_list = []
        if self.daxis_x:
            axis_list.append("X")
        if self.daxis_y:
            axis_list.append("Y")
        if self.daxis_z:
            axis_list.append("Z")

        # Join the axis list with commas, or return "None" if no axis is selected
        return ", ".join(axis_list) if axis_list else "None"
    def draw_callback_px(self, context):
        distrbution_axis_text=self.generate_distribution_string()
        if len(context.selected_objects)<3:
            # draw_Text(context,0,16,text=["Select at least 3 objects"],alignH="CENTER",alignV="TOP",activeKey=None)
            draw_Text(context,0,preferences().font_size,text=[f"Disribution Axis (A/X/Y/Z): {distrbution_axis_text}",f"Proximity Radius (Scroll): {self.proximity_radius}",f"Smart Select (S): {self.smart_select}",f"{'First Object: '+self.first_click_object.name if self.first_click_object else ''}" ,f"{'Second Object: '+self.second_click_object.name if self.second_click_object else ''}"],alignH="CENTER",alignV="BOTTOM",activeKey=None)
            draw_Text(context,0,preferences().font_size,text=["Less than 3 objects selected, Using Proximity Select Mode!","Use Smart Select to avoid relatively larger objects"],alignH="LEFT",alignV="BOTTOM",activeKey=None)
        else:
            draw_Text(context,0,preferences().font_size,text=[f"Disribution Axis (A/X/Y/Z): {distrbution_axis_text}","Click on 2 objects to distribute between",f"{'First Object: '+self.first_click_object.name if self.first_click_object else ''}" ,f"{'Second Object: '+self.second_click_object.name if self.second_click_object else ''}"],alignH="CENTER",alignV="TOP",activeKey=None)
        region = context.region
        rv3d = context.region_data
        point1=None
        point2=None
        if self.first_click_object:
            point1=view3d_utils.location_3d_to_region_2d(region, rv3d, self.first_click_object.location)
        if self.second_click_object:
            point2=view3d_utils.location_3d_to_region_2d(region, rv3d, self.second_click_object.location)
        draw_circles(context,[point1,point2])
        if len(context.selected_objects)<3 : 
            draw_circles(context,[view3d_utils.location_3d_to_region_2d(region, rv3d, obj_location) for obj_location in self.proximity_object_locations])
    def draw_line(self, context, start, end):
        gpu.state.line_width_set(5)
        gpu.state.blend_set("ALPHA") 
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        
        batch = batch_for_shader(shader, 'LINES', {"pos": [start, end]},indices=[(0,1)])
        shader.bind()
        shader.uniform_float("color", (0.0, 0.6, 0.8, 0.7))
        batch.draw(shader)
        
        gpu.state.line_width_set(1)
        gpu.state.blend_set("NONE") 
        

    def create_circle_vertices(self,center, radius, segments=32):
        vertices = []
        for i in range(segments):
            angle = 2 * math.pi * i / segments
            x = center.x + radius * math.cos(angle)
            y = center.y + radius * math.sin(angle)
            vertices.append(Vector((x, y, center.z)))
        return vertices

    
    def align_vertices_with_vector(self,origin,vertices, target_vector):
        """Align circle vertices with the specified 3D vector while keeping the center fixed."""
        # Ensure target_vector is normalized
        target_vector = target_vector.normalized()
        
        # Calculate the current normal (Z-axis in object space)
        current_normal = Vector((0, 0, 1))
        
        # Calculate the rotation needed to align current_normal with target_vector
        rotation_matrix = current_normal.rotation_difference(target_vector).to_matrix().to_4x4()
        
        # Translate vertices to origin, apply rotation, and translate back
        translated_vertices = [v - origin for v in vertices]  # Move to origin
        rotated_vertices = [rotation_matrix @ Vector(v) for v in translated_vertices]  # Rotate
        aligned_vertices = [v + origin for v in rotated_vertices]  # Move back
        
        return aligned_vertices

    

class AAD_OT_Randomize(bpy.types.Operator):
    bl_idname = "aad.randomize"
    bl_label = "Randomize"
    bl_description = "Randomize location of selected objects"
    bl_options = {"REGISTER","UNDO"}
    axis_x:bpy.props.BoolProperty(name="X")
    axis_y:bpy.props.BoolProperty(name="Y")
    axis_z:bpy.props.BoolProperty(name="Z")
    rotation_axis_x:bpy.props.BoolProperty(name="X")
    rotation_axis_y:bpy.props.BoolProperty(name="Y")
    rotation_axis_z:bpy.props.BoolProperty(name="Z")
    
    range_start:bpy.props.FloatProperty(default=0,name="Minimun Value")
    range_end:bpy.props.FloatProperty(default=10,name="Maximum Value")
    seed:bpy.props.IntProperty(default=1,name="Seed")
    randomize_existing_locations: bpy.props.BoolProperty(
        default=False, 
        name="Randomize Existing Locations", 
        description="Randomize the existing locations of selected objects"
    )
    rotation:bpy.props.BoolProperty(default=False,name="Rotation")
    location:bpy.props.BoolProperty(default=False,name="Location")
    scale:bpy.props.BoolProperty(default=False,name="Scale")
    @classmethod
    def poll(cls, context):
        return context.active_object 
    def draw(self, context):
        layout= self.layout
        layout.prop(self,"seed")
        
        layout.prop(self, "randomize_existing_locations",toggle=True)
        
        if not self.randomize_existing_locations:
            layout.prop(self,"range_start")
            layout.prop(self,"range_end")
            row=layout.row(align=True)
            row.prop(self,'axis_x',toggle=True)
            row.prop(self,'axis_y',toggle=True)
            row.prop(self,'axis_z',toggle=True)
            layout.prop(self,"rotation",toggle=True)
            if self.rotation:
                row=layout.row(align=True)
                row.prop(self,'rotation_axis_x',toggle=True)
                row.prop(self,'rotation_axis_y',toggle=True)
                row.prop(self,'rotation_axis_z',toggle=True)
        else:
            row=layout.row(align=True)
            row.prop(self,"rotation",toggle=True)
            row.prop(self,"scale",toggle=True)
            
    def calculate_average_center(self,objects):
        total_location = [0.0, 0.0, 0.0]
        
        for obj in objects:
            total_location[0] += obj.location[0]
            total_location[1] += obj.location[1]
            total_location[2] += obj.location[2]
        
        avg_location = [
            total_location[0] / len(objects),
            total_location[1] / len(objects),
            total_location[2] / len(objects)
        ]
        
        return avg_location
    def execute(self,context):
        random.seed(self.seed)

        selected_objects = [a for a in context.selected_objects if a.type=='MESH']
        if not selected_objects:
            return {'CANCELLED'}
        if self.randomize_existing_locations:
            original_transforms = [(obj.location.copy(), obj.rotation_euler.copy(), obj.scale[:]) for obj in selected_objects]
            # Shuffle the locations randomly
            random.shuffle(original_transforms)
            
            # Assign the shuffled locations to the selected objects
            for obj, new_transforms in zip(selected_objects, original_transforms):
                    # if self.location:
                    obj.location = new_transforms[0]
                    if self.rotation:
                        obj.rotation_euler = new_transforms[1]
                    if self.scale:
                        obj.scale = new_transforms[2]
        else:
            # Randomize around the average center
            avg_center = self.calculate_average_center(selected_objects)

            if self.axis_x:
                for obj in selected_objects:
                    random_offset_x = random.uniform(self.range_start, self.range_end)
                    obj.location[0] = round(avg_center[0] + random_offset_x, 2)

            if self.axis_y:
                for obj in selected_objects:
                    random_offset_y = random.uniform(self.range_start, self.range_end)
                    obj.location[1] = round(avg_center[1] + random_offset_y, 2)

            if self.axis_z:
                for obj in selected_objects:
                    random_offset_z = random.uniform(self.range_start, self.range_end)
                    obj.location[2] = round(avg_center[2] + random_offset_z, 2)
            if self.rotation:
                for obj in selected_objects:
                    if self.rotation_axis_x:
                        random_rotation_x = random.uniform(-360, 360)
                        obj.rotation_euler[0] += round(random_rotation_x, 2)

                    if self.rotation_axis_y:
                        random_rotation_y = random.uniform(-360, 360)
                        obj.rotation_euler[1] += round(random_rotation_y, 2)

                    if self.rotation_axis_z:
                        random_rotation_z = random.uniform(-360, 360)
                        obj.rotation_euler[2] += round(random_rotation_z, 2)
        return {'FINISHED'}
class AAD_OT_Swap(bpy.types.Operator):
    bl_idname = "aad.swap"
    bl_label = "Swap Location"
    bl_description = "Swap location of 2 objects"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects)==2
    def execute(self,context):
        a,b=context.selected_objects
        a_loc=a.location.copy()
        a.location=b.location.copy()
        b.location=a_loc.copy()
        return {'FINISHED'}
def get_bounding_box_center(obj):
    # Ensure the object has mesh data
    if obj.type != 'MESH':
        return None
    
    # Get the world matrix of the object
    world_matrix = obj.matrix_world
    
    # Get the object's bounding box corners (local coordinates)
    local_bbox_corners = [Vector(corner) for corner in obj.bound_box]
    
    # Transform the bounding box corners to world coordinates
    world_bbox_corners = [world_matrix @ corner for corner in local_bbox_corners]
    
    # Calculate the center of the bounding box
    min_corner = Vector(min(corner[i] for corner in world_bbox_corners) for i in range(3))
    max_corner = Vector(max(corner[i] for corner in world_bbox_corners) for i in range(3))
    bbox_center = (min_corner + max_corner) / 2
    
    return bbox_center
def find_point_below_bounding_box_center(obj):
    # Ensure the object has a mesh and is in the correct mode
    if obj.type != 'MESH':
        return None
    
    # Get the world matrix and its inverse
    world_matrix = obj.matrix_world

    # Calculate the bounding box center in local coordinates
    bbox_center_world = 0.125 * sum((world_matrix@Vector(corner) for corner in obj.bound_box), Vector())
    # Use ray casting in local space
    result, location, normal, index, object, matrix = bpy.context.scene.ray_cast(bpy.context.evaluated_depsgraph_get(), bbox_center_world, (0,0,-1))
    # success, location_local, normal_local, face_index = bpy.context.scene.ray_cast(bbox_center_local_for_ray, direction_local, distance=max_distance)
    
    if result:
        return location
    
    return None
class AAD_OT_SnapIt(bpy.types.Operator):
    bl_idname = "aad.snapit"
    bl_label = "Snap Objects To Ground "
    bl_description="Snap Selected Objects To Ground"
    bl_options = {'REGISTER', 'UNDO'}
    onlyGround:bpy.props.BoolProperty(default=False,name="Snap only to objects marked as ground")
    flip:bpy.props.BoolProperty(default=False,name="Flip")
    location:bpy.props.FloatProperty(default=0,name='Location Randomise')
    ctrl:bpy.props.BoolProperty(default=False,name="Move Followed By Rotation")
    alt:bpy.props.BoolProperty(default=False,name="Only Location")
    shift:bpy.props.BoolProperty(default=False,name="Rotate Followed By Move")
    offset:bpy.props.FloatProperty(default=0,name="Z Offset")
    seed:bpy.props.IntProperty(default=0,name="Random Seed")
    normal:bpy.props.FloatVectorProperty(default=(0,0,1),name="Normal")
    @classmethod
    def description(cls,context,properties):
        if properties.onlyGround:
            return "Snap Selected Objects To Objects Marked as Ground"
        else:
            return "Snap Selected Objects To First Object Below"
    def draw(self,context):
        layout=self.layout
        layout.prop(self,'seed')
        layout.prop(self,'offset')
        layout.prop(self,'location')
        layout.prop(self,'onlyGround')
        # layout.prop(self,'alt')
        # layout.prop(self,'ctrl')
        # layout.prop(self,'shift')
    def execute(self, context):
        depsgraph = bpy.context.evaluated_depsgraph_get()
        depsgraph.update()
        random.seed(self.seed)
        for obj in context.selected_objects:
            obj.location=[obj.location[0]+random.uniform(-self.location,self.location) ,obj.location[1]+random.uniform(-self.location,self.location) ,obj.location[2]]
            if obj.type in {'MESH',}:
                evaluated_obj=obj.evaluated_get(depsgraph)
                mx = obj.matrix_world
                
                if self.ctrl:
                    
                    minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                    origin=(obj.location[0],obj.location[1],minz)
                    obj.hide_viewport=True
                    (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                    while((object is not None and not object.aad_objects_info.isGround and self.onlyGround) or object == obj):
                        origin=(location[0],location[1],location[2]-0.001)
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                    obj.hide_viewport=False
                    obj.location.z-=minz-location[2]
                    depsgraph.update()
                    evaluated_obj=obj.evaluated_get(depsgraph)
                    mx = obj.matrix_world
                    minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                    origin=(obj.location[0],obj.location[1],minz)
                    obj.hide_viewport=True
                    (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                    while((object is not None and not object.aad_objects_info.isGround and self.onlyGround) or object == obj):
                        origin=(location[0],location[1],location[2]-0.001)
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                    obj.hide_viewport=False
                    z = Vector((0,0,1))
                    if self.flip:
                        normal=-1*normal
                    if normal!=Vector((0,0,0)):
                        rot = z.rotation_difference( normal ).to_euler()
                        obj.rotation_euler= rot
                        depsgraph.update()
                
                elif self.alt:
                    minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                    origin=(obj.location[0],obj.location[1],minz)
                    obj.hide_viewport=True
                    (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                    while((object is not None and not object.aad_objects_info.isGround and self.onlyGround) or object == obj):
                        origin=(location[0],location[1],location[2]-0.001)
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                    obj.hide_viewport=False
                    obj.location.z-=minz-location[2]
                elif self.shift:
                    minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                    origin=(obj.location[0],obj.location[1],minz)
                    obj.hide_viewport=True
                    (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                    while((object is not None and not object.aad_objects_info.isGround and self.onlyGround) or object == obj):
                        origin=(location[0],location[1],location[2]-0.001)
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                    obj.hide_viewport=False
                    z = Vector((0,0,1))
                    if self.flip:
                        normal=-1*normal
                    if normal!=Vector((0,0,0)):
                        rot = z.rotation_difference( normal ).to_euler()
                        obj.rotation_euler= rot
                        depsgraph.update()
                    minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                    origin=(obj.location[0],obj.location[1],minz)
                    obj.hide_viewport=True
                    (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                    while((object is not None and not object.aad_objects_info.isGround and self.onlyGround) or object == obj):
                        origin=(location[0],location[1],location[2]-0.001)
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                    obj.hide_viewport=False
                    obj.location.z-=minz-location[2]
                else:
                    obj.rotation_euler.x=0
                    obj.rotation_euler.y=0
                    minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                    origin=(obj.location[0],obj.location[1],minz)
                    obj.hide_viewport=True
                    (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                    while((object is not None and not object.aad_objects_info.isGround and self.onlyGround) or object == obj or object in context.selected_objects):
                        origin=(location[0],location[1],location[2]-0.01)
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        
                    obj.hide_viewport=False
                    z = Vector(self.normal) 
                    if self.flip:
                        normal=-1*normal
                    
                    depsgraph.update()
                    mx = obj.matrix_world 
                    
                    mini=find_point_below_bounding_box_center(obj)
                    if normal!=Vector((0,0,0)):
                        rot = z.rotation_difference( normal ).to_euler()
                        obj.rotation_euler= rot
                        depsgraph.update()
                    if obj.type in {'MESH'}:
                        if not mini:
                            mini=Vector((1,1,1000000))
                            for v in evaluated_obj.data.vertices:
                                    a=mx@v.co
                                    if a[2]<mini[2]:
                                        mini=a
                    else:
                        mini=(obj.location[0],obj.location[1],min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box]))
                    #x,y=obj.location[0]-mini[0],obj.location[1]-mini[1]
                    #print(x,y)
                    obj.hide_viewport=True
                    (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,mini,-z)
                    while((object is not None and not object.aad_objects_info.isGround and self.onlyGround) or object == obj or object in context.selected_objects):
                        origin=(location[0],location[1],location[2]-0.001)
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,-z)
                    obj.hide_viewport=False
                    if object:
                        obj_loc,target_loc=raycast_till_target(context,bpy.context.evaluated_depsgraph_get(),obj,object,Vector((0,0,1)))
                        move_object_to_target(obj,obj_loc,target_loc)
                    # obj.location.z-=mini[2]-location[2]
                        
                    obj.select_set(True)
                    
            # Move the object along its local Z-axis by the offset
            local_z = obj.matrix_world.to_quaternion() @ Vector((0, 0, 1))
            obj.location += local_z * self.offset
        return{'FINISHED'}
    def invoke(self, context,event):
        return self.execute(context)
class AAD_OT_Save_Transforms(bpy.types.Operator):
    bl_idname="aad.save_transforms"
    bl_label="Save/Update Transforms"
    bl_options={'REGISTER','UNDO'}
    update:bpy.props.BoolProperty(default=False,options={'SKIP_SAVE'})
    index:bpy.props.IntProperty(options={'SKIP_SAVE'})
    @classmethod
    def description(cls, context, properties):
        if properties.update:
            return "Update Transforms"
        else:
            return "Save Transforms"
    def execute(self,context):
        if self.update:
            obj=context.active_object
            obj.aad_objects_info.saved_transforms[self.index].update()
        else:
            for obj in context.selected_objects:
                obj.aad_objects_info.save_transforms()
        return{'FINISHED'}
class AAD_OT_Remove_Saved_Transforms(bpy.types.Operator):
    bl_idname="aad.remove_saved_transforms"
    bl_label="Delete"
    bl_options={'REGISTER','UNDO'}
    index:bpy.props.IntProperty(options={'SKIP_SAVE'})

    def execute(self,context):
        obj=context.active_object
        if self.index<len(obj.aad_objects_info.saved_transforms):
            obj.aad_objects_info.saved_transforms.remove(self.index)
        return{'FINISHED'}
class AAD_OT_Apply_Transforms(bpy.types.Operator):
    bl_idname="aad.apply_transforms"
    bl_label="Apply Transforms"
    bl_options={'REGISTER','UNDO'}
    index:bpy.props.IntProperty(options={'SKIP_SAVE','HIDDEN'})
    location:bpy.props.BoolProperty(options={'SKIP_SAVE'},name="Location")
    rotation:bpy.props.BoolProperty(options={'SKIP_SAVE'},name="Rotation")
    scale:bpy.props.BoolProperty(options={'SKIP_SAVE'},name="Scale")
    
    def execute(self,context):
        obj=context.active_object
        obj.aad_objects_info.apply_transforms(obj.aad_objects_info.saved_transforms[self.index],self.location,self.rotation,self.scale)
        return{'FINISHED'}
class AAD_OT_Origin_To_Bottom(bpy.types.Operator):
    bl_idname = "aad.origintobottom"
    bl_label = "Origin to Bottom"
    bl_description = "Move origin to the bottom of the object"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.selected_objects
    def execute(self,context):
        active=context.active_object
        for obj in context.selected_objects:
            dup=duplicate_object(obj)
            mw=dup.matrix_world.copy()
            dup.parent=None
            dup.matrix_world=mw
            #bbverts = 
            lowest_pt = min([(dup.matrix_world @
                   Vector(corner)).z for corner in dup.bound_box])
            
            cursorLocBackUp=bpy.context.scene.cursor.location.copy()
            bpy.context.scene.cursor.location=(dup.location[0],dup.location[1],lowest_pt)
            delete_object_with_data(dup)
            override=context.copy()
            override.update({'selected_objects':[obj,],'acitve_object':obj,'object':obj,'selected_editable_objects':[obj,]})
            with bpy.context.temp_override(**override):
                bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
            bpy.context.scene.cursor.location=cursorLocBackUp
        return {'FINISHED'}
class aad_props(bpy.types.PropertyGroup):
    align:bpy.props.BoolProperty(name="Align")
    distribute:bpy.props.BoolProperty(name="Distribute")
    method:bpy.props.EnumProperty(items=(("Origin","Origin","Origin"),("Bounding Box","Bounding Box","Bounding Box")),default=1,name="Method")
    dmethod:bpy.props.EnumProperty(items=(("Origin","Origin","Origin"),("Bounding Box","Bounding Box","Bounding Box")),default=1,name="Method")
    direction:bpy.props.EnumProperty(items=get_direction_items,default=2,name="Direction")
    axis:bpy.props.EnumProperty(items=(("0","X","X"),("1","Y","Y"),("2","Z","Z")))#,("-X","-X","-X"),("-Y","-Y","-Y"),("-Z","-Z","-Z")
    axis_x:bpy.props.BoolProperty(name="X")
    axis_y:bpy.props.BoolProperty(name="Y")
    axis_z:bpy.props.BoolProperty(name="Z")
    daxis_x:bpy.props.BoolProperty(name="X")
    daxis_y:bpy.props.BoolProperty(name="Y")
    daxis_z:bpy.props.BoolProperty(name="Z")
    daxis_a:bpy.props.BoolProperty(name="All",options={'SKIP_SAVE'})
    distribute_pattern:bpy.props.EnumProperty(items=(("1D","1D","1D"),("2D","2D","2D"),("3D","3D","3D")))#,
    daxis:bpy.props.EnumProperty(items=(("0","X","X"),("1","Y","Y"),("2","Z","Z")))
    plane:bpy.props.EnumProperty(items=(("X","X","X"),("Y","Y","Y"),("Z","Z","Z")))
    linear_method:bpy.props.EnumProperty(items=(("Equal Distance","Equal Distance","Equal Distance"),("Equal Gap","Equal Gap","Equal Gap")),default='Equal Gap')
    grid_2d:bpy.props.IntVectorProperty(size=2,min=2,default=[2,2],name="Grid Size")
    grid_3d:bpy.props.IntVectorProperty(size=3,min=2,default=[2,2,2],name="Grid Size")
    size_2d:bpy.props.FloatVectorProperty(size=2,default=[1,1],name="Cell Size")
    size_3d:bpy.props.FloatVectorProperty(size=3,default=[1,1,1],name="Cell Size")
    flip_2d:bpy.props.BoolVectorProperty(default=(False,False),size=2,name="Flip")
    flip_3d:bpy.props.BoolVectorProperty(default=(False,False,False),size=3,name="Flip")
    h_dir:bpy.props.EnumProperty(items=(("RIGHT","RIGHT","RIGHT"),("LEFT","LEFT","LEFT")))
    v_dir:bpy.props.EnumProperty(items=(("DOWN","DOWN","DOWN"),("UP","UP","UP")))
    last_proximity_radius:bpy.props.FloatProperty(name="Last Proximity Radius",default=5.0)
    smart_select:bpy.props.BoolProperty(name="Smart Select",default=False)
    show_bookmark_ui:bpy.props.BoolProperty(default=False,name='Transform Bookmarks')
class AAD_Prefs(bpy.types.AddonPreferences,AddonUpdateChecker):
    bl_idname=__package__
    simplified_ui:bpy.props.BoolProperty(default=True,name="Use Simplified UI")
    font_size:bpy.props.IntProperty(default=20,name="Font Size",max=64,min=4)
    def draw(self,context):
        layout = self.layout
        draw_update_section_for_prefs(layout,context)
        draw_hotkeys(layout, "3D View")
        layout.prop(self,"simplified_ui")
        layout.prop(self,'font_size')
class AAD_Transform_Bookmark(bpy.types.PropertyGroup):
    location:bpy.props.FloatVectorProperty(default=(0,0,0),size=3)
    rotation:bpy.props.FloatVectorProperty(default=(0,0,0),size=3)
    scale:bpy.props.FloatVectorProperty(default=(1,1,1),size=3)
    name:bpy.props.StringProperty(name='Name')
    def update(self):
        obj=self.id_data
        self.location=obj.location
        self.rotation=obj.rotation_euler
        self.scale=obj.scale
    def apply(self,location=True,rotation=True,scale=True):
        obj=self.id_data
        if location:
            obj.location=self.location
        if rotation:
            obj.rotation_euler=self.rotation
        if scale:
            obj.scale=self.scale
class AAD_Objects_Info(bpy.types.PropertyGroup):
    isGround:bpy.props.BoolProperty(default=False,name="Mark as Ground Object")
    saved_transforms:bpy.props.CollectionProperty(type=AAD_Transform_Bookmark)
    def save_transforms(self):
        transforms=self.saved_transforms.add()
        transforms.update()
    def apply_transforms(self,transforms:AAD_Transform_Bookmark,location=True,rotation=True,scale=True):
        transforms.apply(location=location,rotation=rotation,scale=scale)
classes = (AAD_Prefs,AAD_PT_ALIGN_AND_DISTRIBUTE,AAD_OT_Align,aad_props,AAD_OT_Randomize,AAD_OT_Swap,AAD_OT_Call_PopUp,AAD_OT_DistributeAlongAxis,AAD_OT_SnapIt,
           AAD_Transform_Bookmark,
           AAD_Objects_Info,
           AAD_OT_Save_Transforms,
           AAD_OT_Apply_Transforms,
           AAD_OT_Remove_Saved_Transforms,
           AAD_OT_DistributeOnPlane,
           AAD_OT_Origin_To_Bottom
           #,AAD_Temp
)

icon_collection={}
addon_keymaps = []
def load_icons():
    icon_dir=os.path.join(os.path.dirname(__file__),'icons')
    global icon_collection
    if "icons" in icon_collection.keys():
        pcoll=icon_collection["icons"]
    else:
        pcoll = bpy.utils.previews.new()
    icon_collection['icons']=pcoll
    if os.path.isdir(icon_dir):
        for file in os.listdir(icon_dir):
            if file.endswith('.png'):
                icon_name=os.path.splitext(file)[0]
                if icon_name not in pcoll.keys():
                    pcoll.load(icon_name, os.path.join(icon_dir, file), 'IMAGE')
def get_real_location(self):
    return self.id_data.matrix_world.translation
def set_real_location(self,value):
    self.id_data.matrix_world.translation=value
def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
    
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    kmaps = [("aad.call_popup",'Q','alt',{}),("aad.distributealongaxis",'X','alt',{}),("aad.distributeonplane",'X','alt+shift',{}),("aad.swap",'S','alt+shift',{})]
    
    load_icons()
    km = kc.keymaps.new(name="3D View", space_type="VIEW_3D")
    if kc:
        for (op, k, sp,props) in kmaps:

            kmi = km.keymap_items.new(
                op,
                type=k,
                value="PRESS",
                alt="alt" in sp,
                shift="shift" in sp,
                ctrl="ctrl" in sp,
            )
            for p,v in props.items():
                setattr(kmi.properties,p,v)
            addon_keymaps.append((km, kmi))
    bpy.types.Scene.aad_props=bpy.props.PointerProperty(type=aad_props)
    bpy.types.Object.aad_objects_info=bpy.props.PointerProperty(type=AAD_Objects_Info)
    bpy.types.Object.location_real=bpy.props.FloatVectorProperty(name="Location",size=3,get=get_real_location,set=set_real_location,subtype="XYZ")
    addon_update_checker.register("3da4d766586af23e7222a4bd07ec10ab")
def unregister():

    from bpy.utils import unregister_class

    for cls in reversed(classes):
        unregister_class(cls)
    for (km, kmi) in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.aad_props
    addon_update_checker.unregister()
if __name__ == "__main__":
    register()

