import bpy
import bmesh
from mathutils import Matrix,Vector,geometry
import bpy
import bmesh
from mathutils import Matrix, Vector
import math
grid_offset=0.003
def generate_plane_grid_points(obj, face_index,face_normal, subdivisions=1):
    # Ensure we are in object mode
    # bpy.ops.object.mode_set(mode='OBJECT')
    
    # Create an evaluated copy of the object
    depsgraph = bpy.context.evaluated_depsgraph_get()
    obj_eval = obj.evaluated_get(depsgraph)
    
    # Get the mesh data from the evaluated object
    mesh = obj_eval.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.faces.ensure_lookup_table()
    
    # Find the face using the index
    face = bm.faces[face_index]
    
    # Get the bounding center of the face
    face_center = obj.matrix_world @ face.calc_center_median()
    
    # Calculate face normal and tangent for orientation
    face_normal = face.normal
    
    # Calculate the face bounding box size to scale the plane
    face_bbox = [obj.matrix_world @ v.co for v in face.verts]
    face_bbox_min = Vector(map(min, zip(*face_bbox)))
    face_bbox_max = Vector(map(max, zip(*face_bbox)))
    face_size = face_bbox_max - face_bbox_min
    
    # Create a subdivided plane
    bpy.ops.mesh.primitive_plane_add(size=1, enter_editmode=False)
    plane = bpy.context.active_object
    mod=plane.modifiers.new(type='SUBSURF', name='Subdivision')
    mod.subdivision_type='SIMPLE'
    mod.levels = subdivisions
    depsgraph.update()
    # Subdivide the plane
    # if subdivisions > 0:
    #     bpy.ops.object.mode_set(mode='EDIT')
    #     bpy.ops.mesh.subdivide(number_cuts=subdivisions)
    #     bpy.ops.object.mode_set(mode='OBJECT')
    
    # Calculate the object scale
    object_scale = obj.matrix_world.to_scale()
    
    # Create scale matrix from face size and object scale
    scale_matrix = Matrix.Diagonal(Vector((face_size.y / 2 * object_scale.y/2,
                                           face_size.y / 2 * object_scale.y/2,
                                           face_size.y / 2 * object_scale.y/2))).to_4x4()

    # Align the plane to the face
    rotation_matrix = face_normal.to_track_quat('Z', 'Y').to_matrix().to_4x4()
    location_matrix = Matrix.Translation(face_center)
    
    # Apply transformations (location, rotation, scale) to the plane
    plane.matrix_world = location_matrix @ rotation_matrix @ scale_matrix
    
    # Clean up bmesh
    bm.free()
    evaluated_plane=plane.evaluated_get(depsgraph)
    # Collect the grid points
    points = [plane.matrix_world @ v.co for v in evaluated_plane.data.vertices]
    
    # Clean up the plane and its mesh data
    plane_data = plane.data
    bpy.data.objects.remove(plane, do_unlink=True)
    if plane_data in bpy.data.meshes[:]:
        bpy.data.meshes.remove(plane_data)
    
    return points, face_center,face_normal
def get_collection(name):
    if not [c.name for c in bpy.data.collections if bpy.context.scene.user_of_id(c) and name in c.name]:
        col = bpy.data.collections.new(name)
        #col = bpy.data.collections[name]
        bpy.context.scene.collection.children.link(col)
        return col.name
    return [c.name for c in bpy.data.collections if bpy.context.scene.user_of_id(c) and name in c.name][0]

def duplicate_object(obj, col=None):
    new_obj = None
    to_copy = bpy.data.objects[obj.name]
    if not col:
        col = bpy.context.view_layer.active_layer_collection.collection
    else:
        col = get_collection(col)
        col = bpy.data.collections[col]
    new_obj = to_copy.copy()
    if new_obj.data is not None:
        new_obj.data = to_copy.data.copy()
    new_obj.animation_data_clear()
    if col:
        col.objects.link(new_obj)
    return new_obj

def raycast(origin, direction, plane_point, normal):
    return geometry.intersect_line_plane(origin, origin+direction, plane_point, normal)
def get_dimensions(obj):

    return max([Vector((v.co.x*obj.scale.x, v.co.y*obj.scale.y, v.co.z*obj.scale.z)).length for v in obj.data.vertices])
def myceil(num, base):
    return base*math.ceil(num/base)
def delete_object_with_data(obj):
    if obj and obj.name in bpy.data.objects:
        data = obj.data
        isMesh = obj.type == 'MESH'
        bpy.data.objects.remove(obj, do_unlink=True)
        if isMesh:
            bpy.data.meshes.remove(data)
def select(obj, active=True):

    if obj:
        obj.select_set(True)
        if active:
            bpy.context.view_layer.objects.active = obj
def equation_plane(v1, v2, v3):
    a1 = v2.x - v1.x
    b1 = v2.y - v1.y
    c1 = v2.z - v1.z
    a2 = v3.x - v1.x
    b2 = v3.y - v1.y
    c2 = v3.z - v1.z
    a = b1 * c2 - b2 * c1
    b = a2 * c1 - a1 * c2
    c = a1 * b2 - b1 * a2
    d = (- a * v1.x - b * v1.y - c * v1.z)
    return a, b, c, d

def Diff(li1, li2):
    return (list(list(set(li1)-set(li2)) + list(set(li2)-set(li1))))

def coplanar_faces(bm, face, normal_difference_threshold=0.001,planar_threshold=0.003):

    linked_faces = set([])
    used_edges = []
    edges = set([e for e in face.edges])
    while len(Diff(used_edges, edges)) > 0:
        for edge in Diff(used_edges, edges):
            used_edges.append(edge)
            linked = edge.link_faces
            for f in linked:
                if f.normal.length > 0 and f.normal.angle(face.normal) < normal_difference_threshold:
                    edges.update([e for e in f.edges])
                    linked_faces.add(f)
    bm.faces.ensure_lookup_table()
    if len(linked_faces) > 0:
        faces = [f for f in linked_faces if f.normal.length >
                 0 and f.normal.angle(face.normal) < normal_difference_threshold]
    else:
        faces = [f for f in bm.faces if f.normal.length > 0 and f.normal.angle(
            face.normal) < normal_difference_threshold]
    # print(faces)
    cp_verts = set([])
    cp_faces = set([])
    verts = []
    a, b, c, d = equation_plane(
        face.verts[0].co, face.verts[1].co, face.verts[2].co)
    for f in faces:
        if any([math.isclose(a * v.co.x + b * v.co.y + c * v.co.z + d, 0, abs_tol=planar_threshold) for v in f.verts]):
            cp_faces.add(f)
            cp_verts.update([v for v in f.verts])
    return list(cp_verts), list(cp_faces)
def findrectanglecoords(startPoint, endPoint, grid, center=False):
    # startTime=time.time()

    grid_corners = [grid.matrix_world@v.co for v in grid.data.vertices]
    v1, v2, v3, v4 = grid_corners
    B1 = v2-v1
    B1 = B1.normalized()
    B2 = v4-v2
    B2 = B2.normalized()
    A1 = startPoint
    A2 = endPoint
    diagonal_length = (A2-A1).length
   # print(v2,v1,B1)
    if center:
        A1 = A2+diagonal_length*2*(A1-A2).normalized()
        # print(A1)
    # if (B1.z*B2.y-B2.z*B1.y)!=0:

    #    t=(B1.y*A2.z - B1.y*A1.z -B1.z*A2.y+B1.z*A1.y)/(B1.z*B2.y-B2.z*B1.y)
    # else:
     #   if (B1.z*B2.x-B2.z*B1.x)!=0:
    #        t=(B1.x*A2.z - B1.x*A1.z -B1.z*A2.x+B1.z*A1.x)/(B1.z*B2.x-B2.z*B1.x)
    #    else:
    #        t=(B1.y*A2.x - B1.y*A1.x -B1.x*A2.y+B1.x*A1.y)/(B1.x*B2.y-B2.x*B1.y)
    # A3=A2+t*B2
    # A4=A1-t*B2
    A3 = geometry.intersect_line_line(A1, A1+B1, A2, A2+B2)[0]
    A4 = geometry.intersect_line_line(A1, A1+B2, A2, A2+B1)[0]
    # print(time.time()-startTime)
    return [A1, A3, A2, A4]
def deselect_all():
    if bpy.context.mode == 'OBJECT':
        bpy.ops.object.select_all(action='DESELECT')
    elif 'EDIT' in bpy.context.mode:
        bpy.ops.mesh.select_all(action='DESELECT')
