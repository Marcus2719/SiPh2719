import bpy
from .lib import *
def get_node_by_type(nodes,node_type):
        return next(iter(node for node in nodes if node.type == node_type), None)
def get_node_by_name(nodes,node_name):
        return next(iter(node for node in nodes if node.name == node_name), None)
def get_curve_data(ob):
    return [
        ob.data.bevel_depth,
        ob.data.bevel_resolution,
        ob.data.resolution_u,
        ob.data.bevel_mode,
        ob.data.bevel_object,
        ob.data.use_fill_caps
        ]
def get_node_group(group_name):
    cbl_group = next(iter([group for group in bpy.data.node_groups if group.name.startswith(group_name)]),None)
    nodes_blend = None
    if not cbl_group:
        nodes_blend = get_path_to_nodes()
        if not nodes_blend.exists():
            raise RuntimeError(f"Nodes .blend doesn't exist at {nodes_blend}, aborting")
        bpy.ops.wm.append(directory=f"{nodes_blend}/NodeTree/",filename=group_name)
        cbl_group = next(iter([group for group in bpy.data.node_groups if group.name.startswith(group_name)]),None)
    if not cbl_group:
        raise RuntimeError(f"Cable group {group_name} can't be found in {nodes_blend}, aborting")
    return cbl_group
def create_gn_mod(ob,group, name):
    mod = ob.modifiers.new(name=f"{name} Modifier",type='NODES')
    mod.node_group = group
    mod.show_group_selector = False
    return mod
def remove_curve_profile(curve, bevel_mode):
    if bevel_mode == 'OBJECT':
        curve.data.bevel_object = None
    curve.data.bevel_depth = 0
def find_group_by_basename(mod):
    old_group = mod.node_group
    new_name = get_base_name(old_group.name)
    existing = bpy.data.node_groups.get(new_name)
    if existing:
        mod.node_group = existing
        if old_group.users == 0:
            bpy.data.node_groups.remove(old_group)
def import_rope(context, ob):
    imported_names = import_data(str(get_path_to_nodes()), 'objects', prefix='rope')
    rope_name = imported_names[0]
    context.scene.collection.objects.link(bpy.data.objects[rope_name])
    rope = bpy.data.objects[rope_name]
    super_select(rope, context)
    rope.matrix_world = ob.matrix_world
    base_mod = rope.modifiers["CBL GN Rope Base Modifier"]
    remap_mod = rope.modifiers["CBL GN Length Remap Modifier"]
    rope_mod = rope.modifiers["CBL GN Rope Modifier"]
    curve_mod = rope.modifiers["Curve"]
    curve_mod.object = ob
    find_group_by_basename(base_mod)
    find_group_by_basename(remap_mod)
    find_group_by_basename(rope_mod)
    return rope_mod
class CBL_OT_ConvertCurveToGN(bpy.types.Operator):
    """"""
    bl_idname = "cbl.convert_curve_to_gn"
    bl_label = "Cablerator: Convert a Curve to a Geometry Node Object"
    bl_options = {"REGISTER", "UNDO"}
    @classmethod
    def poll(cls, context):
        return context.object
    def execute(self, context):
        cbl_group_name = "CBL GN Curve"
        objs = context.selected_objects
        try: cbl_group = get_node_group(cbl_group_name)
        except RuntimeError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        for ob in objs:
            if ob.type not in {'CURVE', 'MESH'}:
                self.report({'WARNING'}, f"{ob.name} isn't a curve or a mesh, ignoring")
                continue
            if ob.type == 'CURVE':
                bevel_depth, bevel_resolution, resolution_u, bevel_mode, bevel_object, use_fill_caps = get_curve_data(ob)
                remove_curve_profile(ob, bevel_mode)
            else:
                bevel_depth = 0
                bevel_resolution = 16
                bevel_mode = 'ROUND'
                bevel_object = None
                use_fill_caps = False
            mod = create_gn_mod(ob, cbl_group, cbl_group_name)
            input_name = "Socket" if GV.after4 else "Input"
            if bevel_mode == 'OBJECT':
                mod[f"{input_name}_4"] = True
                mod[f"{input_name}_3"] = bevel_object
                bevel_object["cbl_profile"] = True
            elif bevel_mode == 'ROUND':
                mod[f"{input_name}_4"] = False
                mod[f"{input_name}_2"] = math.ceil(linear(bevel_resolution, 0, 6, 4, 16))
                mod[f"{input_name}_1"] = bevel_depth
                context.scene["cbl_last_width"] = bevel_depth
            mod[f"{input_name}_5"] = use_fill_caps
            ob.update_tag()
            ob.select_set(True)
        self.report({'INFO'}, 'Converted to GN Cables')
        return {'FINISHED'}
class CBL_OT_ConvertToMultiCableGN(bpy.types.Operator):
    """"""
    bl_idname = "cbl.convert_to_multicable"
    bl_label = "Cablerator: Convert To Geo Nodes Multicable"
    bl_options = {"REGISTER", "UNDO"}
    @classmethod
    def poll(cls, context):
        return context.object
    def execute(self, context):
        cbl_group_name = "CBL GN MultiCurve"
        objs = context.selected_objects
        try: cbl_group = get_node_group(cbl_group_name)
        except RuntimeError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        for ob in objs:
            if ob.type != 'CURVE':
                self.report({'WARNING'}, f"{ob.name} isn't a curve, ignoring")
                continue
            bevel_depth, bevel_resolution, resolution_u, bevel_mode, bevel_object, use_fill_caps = get_curve_data(ob)
            remove_curve_profile(ob, bevel_mode)
            mod = create_gn_mod(ob, cbl_group, cbl_group_name)
            input_name = "Socket" if GV.after4 else "Input"
            mod[f"{input_name}_1"] = 3
            v = bevel_depth if bevel_depth > 0 else 0.35
            mod[f"{input_name}_2"] = [v,v,0]
            mod[f"{input_name}_3"] = 7
            mod[f"{input_name}_4"] = [v,v,v]
            mod[f"{input_name}_5"] = 13
            if bevel_mode == 'OBJECT':
                mod[f"{input_name}_9"] = True
                mod[f"{input_name}_8"] = bevel_object
                bevel_object["cbl_profile"] = True
            elif bevel_mode == 'ROUND':
                mod[f"{input_name}_9"] = False
                mod[f"{input_name}_7"] = math.ceil(linear(bevel_resolution, 0, 6, 4, 16))
                mod[f"{input_name}_6"] = bevel_depth
                context.scene["cbl_last_width"] = bevel_depth
            mod[f"{input_name}_10"] = use_fill_caps
            ob.update_tag()
            ob.select_set(True)
        self.report({'INFO'}, 'Converted to GN MulltiCables')
        return {'FINISHED'}
class CBL_OT_AddConnectorGN(bpy.types.Operator):
    """"""
    bl_idname = "cbl.add_connector_gn"
    bl_label = "Cablerator: Add GN Connectors"
    bl_options = {"REGISTER", "UNDO"}
    @classmethod
    def poll(cls, context):
        return context.object
    def execute(self, context):
        cbl_group_name = "CBL GN Connector"
        objs = context.selected_objects
        meshes = []
        curves = []
        for ob in objs:
            if ob.type == 'CURVE': curves.append(ob)
            elif ob.type == 'MESH': meshes.append(ob)
        if len(meshes) != 1:
            self.report({'ERROR'}, f"Expected to see exactly 1 mesh selected, found {len(meshes)}, aborting")
            return {'CANCELLED'}
        if not curves:
            self.report({'ERROR'}, f"No curve-type objects selected, aborting")
            return {'CANCELLED'}
        try: cbl_group = get_node_group(cbl_group_name)
        except RuntimeError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        mesh = meshes[0]
        for ob in curves:
            if ob.type != 'CURVE':
                self.report({'WARNING'}, f"{ob.name} isn't a curve, ignoring")
                continue
            mod = create_gn_mod(ob, cbl_group, cbl_group_name)
            mod_attrs = get_gn_attributes(mod)
            mod[mod_attrs["Connector Mesh"][1]] = mesh
            ob.update_tag()
            ob.select_set(True)
        self.report({'INFO'}, 'Instance Added')
        return {'FINISHED'}
class CBL_OT_AddInstancerGN(bpy.types.Operator):
    """"""
    bl_idname = "cbl.add_instance_gn"
    bl_label = "Cablerator: Add Rigid Instances Along Curve"
    bl_options = {"REGISTER", "UNDO"}
    @classmethod
    def poll(cls, context):
        return context.object
    def execute(self, context):
        cbl_group_name = "CBL GN Rigid Instances"
        objs = context.selected_objects
        try: cbl_group = get_node_group(cbl_group_name)
        except RuntimeError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        for ob in objs:
            if ob.type != 'CURVE':
                self.report({'WARNING'}, f"{ob.name} isn't a curve, ignoring")
                continue
            mod = create_gn_mod(ob, cbl_group, cbl_group_name)
            ob.update_tag()
            ob.select_set(True)
        self.report({'INFO'}, 'Instance Added')
        return {'FINISHED'}
class CBL_OT_AddRope(bpy.types.Operator):
    """"""
    bl_idname = "cbl.add_rope"
    bl_label = "Cablerator: Add Rope"
    bl_options = {"REGISTER", "UNDO"}
    @classmethod
    def poll(cls, context):
        return context.object and context.object.type == 'CURVE'
    def execute(self, context):
        selection = context.selected_objects[:]
        for ob in selection:
            ob_spline_length = ob.data.splines[0].calc_length()
            bpy.ops.object.select_all(action='DESELECT')
            rope_mod = import_rope(context, ob)
            rope_mod_attrs = get_gn_attributes(rope_mod)
            segment_length = 0.45
            rope_mod[rope_mod_attrs["Thread Count"][1]] = 3
            rope_mod[rope_mod_attrs["Segment Length"][1]] = segment_length
            rope_mod[rope_mod_attrs["Thread Radius"][1]] = 0.125
            segment_count = int(ob_spline_length / segment_length)
            rope_mod[rope_mod_attrs["Segment Count"][1]] = segment_count
        return {'FINISHED'}
class CBL_OT_AddSpiral(bpy.types.Operator):
    """"""
    bl_idname = "cbl.add_spiral"
    bl_label = "Cablerator: Add Spiral Cable"
    bl_options = {"REGISTER", "UNDO"}
    @classmethod
    def poll(cls, context):
        return context.object and context.object.type == 'CURVE'
    def execute(self, context):
        selection = context.selected_objects[:]
        for ob in selection:
            ob_spline_length = ob.data.splines[0].calc_length()
            bpy.ops.object.select_all(action='DESELECT')
            rope_mod = import_rope(context, ob)
            rope_mod_attrs = get_gn_attributes(rope_mod)
            segment_count = int(ob_spline_length / rope_mod_attrs['Segment Length'][0])
            rope_mod[rope_mod_attrs["Segment Count"][1]] = segment_count
            rope_mod[rope_mod_attrs["Thread Count"][1]] = 1
        return {'FINISHED'}
class CBL_OT_AddChain(bpy.types.Operator):
    """Select a Curve or a Mesh Line"""
    bl_idname = "cbl.add_chain"
    bl_label = "Cablerator: Add Rope"
    bl_options = {"REGISTER", "UNDO"}
    @classmethod
    def poll(cls, context):
        return context.object
    def execute(self, context):
        cbl_group_name = "CBLChainGroup"
        objs = context.selected_objects
        try: cbl_group = get_node_group(cbl_group_name)
        except RuntimeError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        for ob in objs:
            mod = create_gn_mod(ob, cbl_group, "CBL GN Chain")
        return {'FINISHED'}
class CBL_OT_AddHanginCables(bpy.types.Operator):
    """Select a Mesh object consisting of Edges only. For each edge a hanging cable will be made"""
    bl_idname = "cbl.add_hanging_cables"
    bl_label = "Cablerator: Add Hanging Cables"
    bl_options = {"REGISTER", "UNDO"}
    @classmethod
    def poll(cls, context):
        return context.object
    def execute(self, context):
        cbl_group_name = "CBL GN Hanging Cables Group"
        objs = context.selected_objects
        for ob in objs:
            if ob.type != 'MESH':
                self.report({'ERROR'}, f"This function requires Mesh objects selected and {ob.name} is a {ob.type}, aborting")
                return {'CANCELLED'}
            if len(ob.data.polygons) > 0:
                self.report({'ERROR'}, f"Selected object {ob.name} should be a line of edges not containing polygons, aborting")
                return {'CANCELLED'}
        try: cbl_group = get_node_group(cbl_group_name)
        except RuntimeError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        for ob in objs:
            mod = create_gn_mod(ob, cbl_group, "CBL GN Hanging Cables")
        return {'FINISHED'}
def register():
    bpy.utils.register_class(CBL_OT_ConvertCurveToGN)
    bpy.utils.register_class(CBL_OT_ConvertToMultiCableGN)
    bpy.utils.register_class(CBL_OT_AddInstancerGN)
    bpy.utils.register_class(CBL_OT_AddRope)
    bpy.utils.register_class(CBL_OT_AddSpiral)
    bpy.utils.register_class(CBL_OT_AddConnectorGN)
    bpy.utils.register_class(CBL_OT_AddChain)
    bpy.utils.register_class(CBL_OT_AddHanginCables)
def unregister():
    bpy.utils.unregister_class(CBL_OT_ConvertCurveToGN)
    bpy.utils.unregister_class(CBL_OT_ConvertToMultiCableGN)
    bpy.utils.unregister_class(CBL_OT_AddInstancerGN)
    bpy.utils.unregister_class(CBL_OT_AddRope)
    bpy.utils.unregister_class(CBL_OT_AddSpiral)
    bpy.utils.unregister_class(CBL_OT_AddConnectorGN)
    bpy.utils.unregister_class(CBL_OT_AddChain)
    bpy.utils.unregister_class(CBL_OT_AddHanginCables)