import bpy
from .lib import *
def sample_bezier_segment(p0, p1, p2, p3, steps):
    pts = []
    for i in range(steps + 1):
        t = i / steps
        it = 1.0 - t
        pts.append(
            (it**3) * p0 +
            3.0 * (it**2) * t * p1 +
            3.0 * it * (t**2) * p2 +
            (t**3) * p3
        )
    return pts
def normalize(v: Vector) -> Vector:
    if v.length == 0.0:
        return Vector((1.0, 0.0, 0.0))
    return v.normalized()
def get_all_lines(obj):
    if obj.type == 'MESH':
        return get_all_polylines(obj)
    elif obj.type == 'CURVE':
        return get_all_polycurve(obj)
def get_all_polylines(obj):
    me = obj.data
    verts = me.vertices
    edges = me.edges
    edges_by_vert = {v.index: [] for v in verts}
    for e in edges:
        v1, v2 = e.vertices
        edges_by_vert[v1].append(v2)
        edges_by_vert[v2].append(v1)
    visited = set()
    polylines = []
    for v_idx in range(len(verts)):
        if v_idx in visited:
            continue
        stack = [v_idx]
        comp = []
        while stack:
            vi = stack.pop()
            if vi in visited:
                continue
            visited.add(vi)
            comp.append(vi)
            for nb in edges_by_vert[vi]:
                if nb not in visited:
                    stack.append(nb)
        if len(comp) < 2:
            continue
        degrees = {i: len(edges_by_vert[i]) for i in comp}
        if any(d > 2 for d in degrees.values()):
            continue
        endpoints = [i for i, d in degrees.items() if d == 1]
        start = endpoints[0] if endpoints else comp[0]
        ordered = []
        prev = None
        current = start
        while True:
            ordered.append(current)
            nbrs = [n for n in edges_by_vert[current] if n != prev]
            if not nbrs:
                break
            prev, current = current, nbrs[0]
            if not endpoints and current == start:
                break
        polyline_coords = [verts[i].co.copy() for i in ordered]
        polylines.append(polyline_coords)
    return polylines
def get_all_polycurve(obj, bezier_steps=32):
    curvelines = []
    for spline in obj.data.splines:
        if spline.type == "BEZIER":
            bp = spline.bezier_points
            if len(bp) < 2:
                continue
            points = []
            seg_count = len(bp) if spline.use_cyclic_u else (len(bp) - 1)
            for i in range(seg_count):
                a = bp[i]
                b = bp[(i + 1) % len(bp)]
                p0 = a.co
                p1 = a.handle_right
                p2 = b.handle_left
                p3 = b.co
                seg_pts = sample_bezier_segment(p0, p1, p2, p3, bezier_steps)
                points.extend(seg_pts[1:] if points else seg_pts)
            if len(points) >= 2:
                curvelines.append(points)
        elif spline.type in {"POLY", "NURBS"}:
            points = [p.co.to_3d() for p in spline.points]
            if spline.use_cyclic_u and len(points) >= 2:
                points.append(points[0])
            if len(points) >= 2:
                curvelines.append(points)
    return curvelines
def chord_length_param(points):
    u = [0.0]
    total = 0.0
    for i in range(1, len(points)):
        d = (points[i] - points[i - 1]).length
        total += d
        u.append(total)
    if total > 0.0:
        inv_total = 1.0 / total
        u = [x * inv_total for x in u]
    return u
def bezier_eval(ctrl, u):
    one_minus = 1.0 - u
    b0 = one_minus * one_minus * one_minus
    b1 = 3.0 * u * one_minus * one_minus
    b2 = 3.0 * u * u * one_minus
    b3 = u * u * u
    return (ctrl[0] * b0 +
            ctrl[1] * b1 +
            ctrl[2] * b2 +
            ctrl[3] * b3)
def generate_bezier(points, u, tan1, tan2):
    P0 = points[0]
    P3 = points[-1]
    n = len(points)
    C = [[0.0, 0.0],
         [0.0, 0.0]]
    X = [0.0, 0.0]
    for i in range(n):
        ui = u[i]
        one_minus = 1.0 - ui
        b0 = one_minus * one_minus * one_minus
        b1 = 3.0 * ui * one_minus * one_minus
        b2 = 3.0 * ui * ui * one_minus
        b3 = ui * ui * ui
        a1 = tan1 * b1
        a2 = tan2 * b2
        C[0][0] += a1.dot(a1)
        C[0][1] += a1.dot(a2)
        C[1][0] = C[0][1]
        C[1][1] += a2.dot(a2)
        tmp = points[i] - (P0 * (b0 + b1) + P3 * (b2 + b3))
        X[0] += a1.dot(tmp)
        X[1] += a2.dot(tmp)
    det = C[0][0] * C[1][1] - C[0][1] * C[1][0]
    if abs(det) > 1e-8:
        inv_det = 1.0 / det
        alpha_l = (X[0] * C[1][1] - X[1] * C[0][1]) * inv_det
        alpha_r = (C[0][0] * X[1] - C[1][0] * X[0]) * inv_det
    else:
        alpha_l = alpha_r = (P3 - P0).length / 3.0
    seg_vec = P3 - P0
    seg_len = seg_vec.length
    eps = seg_len * 1e-3 if seg_len > 0.0 else 1e-3
    if alpha_l < eps or alpha_r < eps:
        dist = seg_len / 3.0 if seg_len > 0.0 else 1.0
        C1 = P0 + tan1 * dist
        C2 = P3 + tan2 * dist
    else:
        C1 = P0 + tan1 * alpha_l
        C2 = P3 + tan2 * alpha_r
    return [P0, C1, C2, P3]
def compute_max_error(points, bezier, u):
    max_dist_sq = 0.0
    split_idx = len(points) // 2
    for i in range(1, len(points) - 1):
        p = points[i]
        c = bezier_eval(bezier, u[i])
        d_sq = (p - c).length_squared
        if d_sq > max_dist_sq:
            max_dist_sq = d_sq
            split_idx = i
    return max_dist_sq, split_idx
def fit_curve(points, max_error):
    segments = []
    max_error_sq = max_error * max_error
    if len(points) < 2:
        return segments
    tan1 = normalize(points[1] - points[0])
    tan2 = normalize(points[-2] - points[-1])
    def fit_section(pts, tan_l, tan_r):
        n = len(pts)
        if n == 2:
            P0 = pts[0]
            P3 = pts[-1]
            seg_vec = P3 - P0
            dist = seg_vec.length / 3.0 if seg_vec.length > 0.0 else 1.0
            C1 = P0 + tan_l * dist
            C2 = P3 + tan_r * dist
            segments.append([P0, C1, C2, P3])
            return
        u = chord_length_param(pts)
        bez = generate_bezier(pts, u, tan_l, tan_r)
        err_sq, split_idx = compute_max_error(pts, bez, u)
        if err_sq <= max_error_sq:
            segments.append(bez)
            return
        if split_idx <= 0 or split_idx >= n - 1:
            P0 = pts[0]
            P3 = pts[-1]
            seg_vec = P3 - P0
            dist = seg_vec.length / 3.0 if seg_vec.length > 0.0 else 1.0
            C1 = P0 + tan_l * dist
            C2 = P3 + tan_r * dist
            segments.append([P0, C1, C2, P3])
            return
        tan_center = normalize(pts[split_idx + 1] - pts[split_idx - 1])
        fit_section(pts[:split_idx + 1], tan_l, -tan_center)
        fit_section(pts[split_idx:],      tan_center, tan_r)
    fit_section(points, tan1, tan2)
    return segments
def create_curve_from_multiple(polylines, max_error, name):
    curve_data = bpy.data.curves.new(name, 'CURVE')
    curve_data.dimensions = '3D'
    for pts in polylines:
        if len(pts) < 2:
            continue
        segments = fit_curve(pts, max_error)
        if not segments:
            continue
        spline = curve_data.splines.new('BEZIER')
        num_points = len(segments) + 1
        spline.bezier_points.add(num_points - 1)
        for bp in spline.bezier_points:
            bp.handle_left_type = 'FREE'
            bp.handle_right_type = 'FREE'
        first_seg = segments[0]
        P0, C1, _, _ = first_seg
        bp0 = spline.bezier_points[0]
        bp0.co = P0
        bp0.handle_right = C1
        bp0.handle_left = 2 * P0 - C1
        for i, seg in enumerate(segments):
            P0, C1, C2, P3 = seg
            idx = i + 1
            bp = spline.bezier_points[idx]
            bp.co = P3
            bp.handle_left = C2
            spline.bezier_points[idx - 1].handle_right = C1
            if idx == len(segments):
                bp.handle_right = 2 * P3 - C2
        for bp in spline.bezier_points:
            bp.handle_left_type = 'ALIGNED'
            bp.handle_right_type = 'ALIGNED'
    obj = bpy.data.objects.new(name, curve_data)
    bpy.context.collection.objects.link(obj)
    return obj
class CBL_OT_CurveFit(bpy.types.Operator):
    bl_idname = "cbl.curve_fit"
    bl_label = "Cablerator: Curve Fit (Op)"
    bl_options = {'REGISTER', 'UNDO'}
    max_error: bpy.props.FloatProperty(
        name="Max Error",
        description="Maximum allowed distance between polyline and fitted curve",
        default=0.01,
        min=1e-6,
        soft_max=1.0,
    )
    remove_original: bpy.props.BoolProperty(
        name="Remove Original Object",
        default=False
    )
    @classmethod
    def poll(cls, context):
        return context.object
    def invoke(self, context, event):
        ob = context.object
        self.remove_original = False
        self.selected_names = [ob.name for ob in context.selected_objects[:]]
        for ob in context.selected_objects:
            if ob.type == 'MESH' and len(ob.data.polygons) > 0:
                self.report({'ERROR'}, "Selected object should be a line of edges not containing polygons, aborting")
                return {'CANCELLED'}
        self.obmw = {ob.name: ob.matrix_world.copy() for ob in context.selected_objects}
        try:
            self.polylines = {ob.name: get_all_lines(ob) for ob in context.selected_objects}
        except Exception as e:
            self.report({'ERROR'}, e)
            return {'CANCELLED'}
        return self.execute(context)
    def execute(self, context):
        for el in self.polylines.items():
            ob_name, polylines = el
            curve_ob = create_curve_from_multiple(polylines, self.max_error, ob_name + "_fit")
            if curve_ob:
                curve_ob.matrix_world = self.obmw[ob_name]
        if self.remove_original:
            for ob_name in self.selected_names:
                ob = bpy.data.objects.get(ob_name)
                if ob:
                    bpy.data.objects.remove(ob, do_unlink=True)
        return {'FINISHED'}
