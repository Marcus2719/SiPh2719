import bpy
from .lib import *
from .ui import *
from .inits import *
from .typing import *
from .curve_fit import get_all_lines, get_all_polycurve, fit_curve
import copy
def get_spline_props(ob):
    spline_props = []
    if ob.type == "CURVE":
        for sindex, spline in enumerate(ob.data.splines):
            if spline.type == 'BEZIER':
                spline_props.append({
                    "tilt": sum([point.tilt for point in spline.bezier_points])/len(spline.bezier_points),
                    "radius": sum([point.radius for point in spline.bezier_points])/len(spline.bezier_points)
                })
            else:
                spline_props.append({
                    "tilt": sum([point.tilt for point in spline.points])/len(spline.points),
                    "radius": sum([point.radius for point in spline.points])/len(spline.points)
                })
    return spline_props
def set_spline_props(ob, props):
    for sindex, spline in enumerate(ob.data.splines):
        for point in spline.bezier_points:
            point.tilt = props[sindex]["tilt"]
            point.radius = props[sindex]["radius"]
class CBL_OT_CableratorCurveFitModal(bpy.types.Operator):
    bl_idname = "cbl.curve_fit_modal"
    bl_label = "Cablerator: Curve Refit"
    bl_options = {"REGISTER", "UNDO"}
    remove_originals: bpy.props.BoolProperty(name="Remove Originals", default=False)
    @classmethod
    def poll(cls, context):
        return context.area.type == "VIEW_3D" and context.object and context.view_layer.objects.active and len(context.selected_objects)
    def resolve_S_key(self, item):
        if self.cur_value < 0.001:
            self.cur_value = 0.001
            item['cur_value'] = 0.001
        elif self.cur_value > .999:
            self.cur_value = .999
            item['cur_value'] = .999
        self.create_splines()
    def resolve_Q_key(self, item):
        if self.cur_value < 0:
            self.cur_value = 0
            item['cur_value'] = 0
        elif self.cur_value > 1:
            self.cur_value = 1
            item['cur_value'] = 1
    def resolve_W_key(self, item):
        if self.cur_value < 0:
            self.cur_value = 0
            item['cur_value'] = 0
        elif self.cur_value > 1:
            self.cur_value = 1
            item['cur_value'] = 1
    def bool_r(self):
        key = 'R'
    def local_to_global_coords(self, polylines):
        polylines_copy = copy.deepcopy(polylines)
        for oname, line in polylines_copy.items():
            for lindex, coords in enumerate(line):
                for cindex, coord in enumerate(coords):
                    polylines_copy[oname][lindex][cindex] = self.obmw[oname] @ coord
        return polylines_copy
    def cancel_modal(self):
        if self.new_curves:
            for curve in self.new_curves.values():
                super_remove(curve, self.context)
        for oname in self.selected_names:
            ob = bpy.data.objects.get(oname)
            if ob: ob.select_set(True)
        if self.aob: self.context.view_layer.objects.active = self.aob
        self.finish()
    def finish(self):
        if self._draw_handler:
            self._draw_handler = bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
        if self.preview_draw_handle:
            self.preview_draw_handle = bpy.types.SpaceView3D.draw_handler_remove(self.preview_draw_handle, 'WINDOW')
        if self._timer:
            self.context.window_manager.event_timer_remove(self._timer)
        self.context.area.tag_redraw()
    def finish_modal(self):
        if self.new_curves:
            for oname, curve in self.new_curves.items():
                original_ob = bpy.data.objects.get(oname)
                if original_ob:
                    if original_ob.type == 'CURVE':
                        copy_curve_settings(original_ob, curve)
                        set_spline_props(curve, self.curve_spline_props[oname])
                    copy_gn(original_ob, curve, start_name='CBL')
                super_select(curve, self.context, active=curve, deselect=False)
        if self.bools['R']['status']:
            for oname in self.selected_names:
                ob = bpy.data.objects.get(oname)
                if ob: super_remove(ob, self.context)
    def _draw(self, context):
        if not self._base_batches:
            return
        gpu.state.blend_set("ALPHA")
        gpu.state.depth_test_set("NONE")
        gpu.state.depth_mask_set(False)
        self._shader.bind()
        self._shader.uniform_float("color", (1, 1, 1, self.events['Q']['cur_value']))
        self._shader.uniform_float("lineWidth", 1.0)
        self._shader.uniform_float("viewportSize", (context.region.width, context.region.height))
        for batch in self._base_batches:
            batch.draw(self._shader)
        self._shader.uniform_float("color", (.1, 1, 0.1, self.events['W']['cur_value']))
        self._shader.uniform_float("lineWidth", 2.0)
        self._shader.uniform_float("viewportSize", (context.region.width, context.region.height))
        for b in self._preview_batches:
            b.draw(self._shader)
        gpu.state.depth_mask_set(True)
        gpu.state.depth_test_set("LESS_EQUAL")
        gpu.state.blend_set("NONE")
    def create_bezier_objects(self):
        new_curves = {}
        for oname in self.selected_names:
            ob = bpy.data.objects.get(oname)
            curve_data = bpy.data.curves.new(f"{ob.data.name} fit", 'CURVE')
            curve_data.dimensions = '3D'
            curve = bpy.data.objects.new(f"{oname} fit", curve_data)
            ob.users_collection[0].objects.link(curve)
            new_curves[oname] = curve
            curve.matrix_world = self.obmw[oname]
        return new_curves
    def create_splines(self):
        max_error = self.events['S']['cur_value']
        preview_points = []
        for oname, polylines in self.polylines.items():
            ob = self.new_curves[oname]
            curve_data = ob.data
            for spline in ob.data.splines:
                ob.data.splines.remove(spline)
            for pts in polylines:
                if len(pts) < 2:
                    continue
                segments = fit_curve(pts, max_error)
                if not segments:
                    continue
                spline = curve_data.splines.new('BEZIER')
                num_points = len(segments) + 1
                spline.bezier_points.add(num_points - 1)
                for bp in spline.bezier_points:
                    bp.handle_left_type = 'FREE'
                    bp.handle_right_type = 'FREE'
                first_seg = segments[0]
                P0, C1, _, _ = first_seg
                bp0 = spline.bezier_points[0]
                bp0.co = P0
                bp0.handle_right = C1
                bp0.handle_left = 2 * P0 - C1
                for i, seg in enumerate(segments):
                    P0, C1, C2, P3 = seg
                    idx = i + 1
                    bp = spline.bezier_points[idx]
                    bp.co = P3
                    bp.handle_left = C2
                    spline.bezier_points[idx - 1].handle_right = C1
                    if idx == len(segments):
                        bp.handle_right = 2 * P3 - C2
                for bp in spline.bezier_points:
                    bp.handle_left_type = 'ALIGNED'
                    bp.handle_right_type = 'ALIGNED'
            curve_lines = get_all_polycurve(ob)
            for line in curve_lines:
                line_mw = []
                for point in line:
                    line_mw.append(ob.matrix_world @ point)
                preview_points.append(line_mw)
        self._preview_batches = [
            batch_for_shader(self._shader, "LINE_STRIP", {"pos": pts})
            for pts in preview_points
        ]
    def modal(self, context, event):
        context.area.tag_redraw()
        if event.type in {'LEFT_SHIFT', 'RIGHT_SHIFT'}:
            if event.value == 'PRESS':
                self.is_shift = True
                self.first_value = self.cur_value
                self.first_mouse_x = event.mouse_x
            elif event.value == 'RELEASE':
                self.is_shift = False
                self.first_value = self.cur_value
                self.first_mouse_x = event.mouse_x
        if event.type in {'LEFT_CTRL', 'RIGHT_CTRL', 'OSKEY'}:
            if event.value == 'PRESS':
                self.is_ctrl = True
                self.first_value = self.cur_value
                self.first_mouse_x = event.mouse_x
            elif event.value == 'RELEASE':
                self.is_ctrl = False
                self.first_value = self.cur_value
                self.first_mouse_x = event.mouse_x
        if event.type in self.events.keys() and event.value == "PRESS":
            self.first_mouse_x = event.mouse_x
            for key in self.events.keys():
                if event.type == key:
                    if self.events[key]['status']:
                        self.events[key]['status'] = False
                        self.can_type = False
                    else:
                        self.events[key]['status'] = True
                        self.can_type = True
                        self.first_value = self.events[key]['cur_value']
                        self.first_unchanged_value = self.events[key]['cur_value']
                        self.cur_value = self.events[key]['cur_value']
                else:
                    self.events[key]['status'] = False
            return {'RUNNING_MODAL'}
        if 'NDOF' in event.type or event.type in self.navigation or event.alt:
            return {'PASS_THROUGH'}
        elif event.type in SIGNES.keys() and event.value == "PRESS":
            resolve_typing_signes(self, event)
        elif event.type in NUMBERS.keys() and event.value == "PRESS":
            resolve_typing_numbers(self, event)
        elif event.type == "BACK_SPACE" and event.value == "PRESS":
            resolve_typing_backspace(self, event)
        elif event.type in {"NUMPAD_PERIOD","PERIOD"} and event.value == "PRESS":
            resolve_typing_dot(self, event)
        elif event.type in {"RET","NUMPAD_ENTER"} and event.value == "PRESS":
            if self.typing:
                self.typing = False
                self.first_mouse_x = event.mouse_x
                resolve_typing_enter(self, event)
                for key in self.events.keys():
                    item = self.events[key]
                    if item['status']:
                        try:
                            if item['type'] != 'int':
                                self.cur_value = float(self.my_num_str)
                                item['cur_value'] = self.cur_value
                            else:
                                self.cur_value = int(self.my_num_str)
                                item['cur_value'] = self.cur_value
                        except:
                            pass
                        if key == 'S':
                            self.resolve_S_key(item)
                        if key == 'Q':
                            self.resolve_Q_key(item)
                        if key == 'W':
                            self.resolve_W_key(item)
            else:
                self.can_type = False
                clean_events(self)
        if event.type in self.bools.keys() and event.value == "PRESS":
            for key in self.events.keys():
                self.events[key]['status'] = False
            for key in self.bools.keys():
                if event.type == key:
                    self.bools[key]['status'] = not self.bools[key]['status']
            return {'RUNNING_MODAL'}
        if event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            wheel_val = 0.1 if event.type == 'WHEELUPMOUSE' else -0.1
            if self.events['S']['status']:
                self.events['S']['cur_value'] = normal_round((self.events['S']['cur_value'] + wheel_val)*10)/10
                if self.events['S']['cur_value'] < 0.001:
                    self.events['S']['cur_value'] = 0.001
                elif self.events['S']['cur_value'] > .999:
                    self.events['S']['cur_value'] = 0.999
                self.first_value = self.events['S']['cur_value']
                self.first_unchanged_value = self.events['S']['cur_value']
                self.cur_value = self.events['S']['cur_value']
                self.first_mouse_x = event.mouse_x
                self.resolve_S_key(self.events['S'])
            elif self.events['Q']['status']:
                self.events['Q']['cur_value'] = normal_round((self.events['Q']['cur_value'] + wheel_val)*10)/10
                if self.events['Q']['cur_value'] < 0:
                    self.events['Q']['cur_value'] = 0
                elif self.events['Q']['cur_value'] > 1:
                    self.events['Q']['cur_value'] = 1
                self.first_value = self.events['Q']['cur_value']
                self.first_unchanged_value = self.events['Q']['cur_value']
                self.cur_value = self.events['Q']['cur_value']
                self.first_mouse_x = event.mouse_x
                self.resolve_S_key(self.events['Q'])
            elif self.events['W']['status']:
                self.events['W']['cur_value'] = normal_round((self.events['W']['cur_value'] + wheel_val)*10)/10
                if self.events['W']['cur_value'] < 0:
                    self.events['W']['cur_value'] = 0
                elif self.events['W']['cur_value'] > 1:
                    self.events['W']['cur_value'] = 1
                self.first_value = self.events['W']['cur_value']
                self.first_unchanged_value = self.events['W']['cur_value']
                self.cur_value = self.events['W']['cur_value']
                self.first_mouse_x = event.mouse_x
                self.resolve_S_key(self.events['W'])
            else:
                return {'PASS_THROUGH'}
        elif event.type == 'MOUSEMOVE':
            handle_hover(self, event)
            if self.typing: return {'RUNNING_MODAL'}
            for key in self.events.keys():
                item = self.events[key]
                if item['status']:
                    if self.is_shift:
                        delta = 1200 if key != 'S' else 1800
                    else:
                        delta = 60 if key != 'S' else 300
                    if item['type'] != 'int':
                        delta /= calc_mousemove_delta(item['cur_value'])
                    if event.mouse_x != self.first_mouse_x:
                        self.delta_offset = (event.mouse_x - self.first_mouse_x) / delta
                        self.first_mouse_x = event.mouse_x
                        self.cur_value += self.delta_offset
                        if not event.is_tablet:
                            if self.region.x + self.warp_delta > event.mouse_x:
                                left_coord = self.region.x + self.region.width - self.warp_delta
                                context.window.cursor_warp(left_coord, event.mouse_y)
                                self.first_mouse_x = left_coord
                            elif self.region.x + self.region.width - self.warp_delta < event.mouse_x:
                                right_coord = self.region.x + self.warp_delta
                                context.window.cursor_warp(right_coord, event.mouse_y)
                                self.first_mouse_x = right_coord
                        if self.is_ctrl:
                            item['cur_value'] = normal_round((self.cur_value)*20)/20
                        else:
                            item['cur_value'] = self.cur_value
                        if item['type'] == 'int':
                            item['cur_value'] = normal_round(item['cur_value'])
                        if key == 'S':
                            self.resolve_S_key(item)
                        if key == 'Q':
                            self.resolve_Q_key(item)
                        if key == 'W':
                            self.resolve_W_key(item)
        if event.type == 'LEFTMOUSE' and event.value == "PRESS":
            if self.text_ui_rect_batch["key"]: return handle_hover_press(self)
            for ev in self.events:
                if self.events[ev]['status']:
                    self.events[ev]['status'] = not self.events[ev]['status']
                    self.can_type = False
                    return {'RUNNING_MODAL'}
            self.finish_modal()
            self.finish()
            return {'FINISHED'}
        if event.type in self.cancel_buttons and event.value == "PRESS":
            for key in self.events:
                if self.events[key]['status']:
                    self.events[key]['cur_value'] = self.first_unchanged_value
                    if key == 'S':
                        self.resolve_S_key(self.events['S'])
                    if key == 'W':
                        self.resolve_W_key(self.events['W'])
                    if key == 'Q':
                        self.resolve_Q_key(self.events['Q'])
                    self.events[key]['status'] = not self.events[key]['status']
                    return {'RUNNING_MODAL'}
            self.cancel_modal()
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        self.preview_draw_handle = None
        self._shader = None
        self.context = context
        self._base_polylines = None
        self._base_batches = None
        self._preview_polylines = None
        self._preview_batches = None
        self._timer = None
        self.selected_names = [ob.name for ob in context.selected_objects[:]]
        self.aob = context.view_layer.objects.active
        for ob in context.selected_objects:
            if ob.type not in {'MESH', 'CURVE'}:
                self.report({'ERROR'}, f"Object {ob.name} isn't a Curve or Mesh, aborting")
                return {'CANCELLED'}
            if ob.type == 'MESH' and len(ob.data.polygons) > 0:
                self.report({'ERROR'}, f"Selected object {ob.name} should be a line of edges not containing polygons, aborting")
                return {'CANCELLED'}
        self.obmw = {ob.name: ob.matrix_world.copy() for ob in context.selected_objects}
        self.polylines = {ob.name: get_all_lines(ob) for ob in context.selected_objects}
        self.curve_spline_props = {ob.name: get_spline_props(ob) for ob in context.selected_objects}
        self._shader = gpu.shader.from_builtin("POLYLINE_UNIFORM_COLOR")
        self._base_polylines = self.local_to_global_coords(self.polylines)
        self._base_batches = [
                batch_for_shader(self._shader, "LINE_STRIP", {"pos": pts})
                for points in self._base_polylines.values() for pts in points
            ]
        for ob in context.selected_objects: ob.select_set(False)
        context.view_layer.objects.active = None
        self.new_curves = self.create_bezier_objects()
        self.text_ui_rect_batch = {
            "ui_rect": [],
            "items": {},
            "key": None,
            "inside_ui_rect": False,
        }
        self.typing = False
        self.can_type = False
        self.my_num_str = ""
        self.title = 'Curve Fit'
        get_prefs(self, context)
        self.show_curve_length = False
        self.first_mouse_x = event.mouse_x
        self.cur_value = -1
        self.first_value = -1
        self.first_unchanged_value = -1
        self.is_shift = False
        self.is_ctrl = False
        self.events = {
            'W': {
                'name': 'Fit Preview Opacity (W)',
                'status': False,
                'cur_value': 1,
                'type': 'float',
                'show': True
            },
            'Q': {
                'name': 'Original Preview Opacity (Q)',
                'status': False,
                'cur_value': 1,
                'type': 'float',
                'show': True
            },
            'S': {
                'name': 'Error Threshold (S)',
                'status': False,
                'cur_value': 0.15,
                'type': 'float',
                'show': True
            },
        }
        self.bools = {
                'R': {
                    'name': 'Remove Original (R)',
                    'status': self.remove_originals,
                    'usable': True,
                    'show': True
                },
        }
        self.bool_functions = {
            'R': self.bool_r,
        }
        self.create_splines()
        self.reg = get_view(context, event.mouse_x, event.mouse_y)
        init_font_settings(self)
        if context.space_data.type == 'VIEW_3D':
            self.init_area = context.area
            self._draw_handler = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, (self, context), 'WINDOW', 'POST_PIXEL')
            self.preview_draw_handle = bpy.types.SpaceView3D.draw_handler_add(
                self._draw, (context,), "WINDOW", "POST_VIEW"
            )
            self._timer = context.window_manager.event_timer_add(0.05, window=context.window)
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Active space must be a View3d")
            bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
            return {'CANCELLED'}
def register():
    bpy.utils.register_class(CBL_OT_CableratorCurveFitModal)
def unregister():
    bpy.utils.unregister_class(CBL_OT_CableratorCurveFitModal)
